<?php

declare(strict_types=1);

namespace Joomla\Plugin\Finder\JetLanding\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Event\Finder as FinderEvent;
use Joomla\CMS\Factory;
use Joomla\Component\Finder\Administrator\Indexer\Adapter;
use Joomla\Component\Finder\Administrator\Indexer\Indexer;
use Joomla\Component\Finder\Administrator\Indexer\Result;
use Joomla\Component\JetLanding\Site\Helper\RouteHelper;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;
use Joomla\Event\SubscriberInterface;
use Joomla\Registry\Registry;

final class JetLanding extends Adapter implements SubscriberInterface
{
    use DatabaseAwareTrait;

    protected $context = 'JET Landing';

    protected $extension = 'com_jet_landing';

    protected $layout = 'landing';

    protected $type_title = 'Landing';

    protected $table = '#__jet_landings';

    protected $state_field = 'state';

    protected $autoloadLanguage = true;

    public static function getSubscribedEvents(): array
    {
        return array_merge(parent::getSubscribedEvents(), [
            'onFinderAfterDelete' => 'onFinderAfterDelete',
            'onFinderAfterSave'   => 'onFinderAfterSave',
            'onFinderBeforeSave'  => 'onFinderBeforeSave',
            'onFinderChangeState' => 'onFinderChangeState',
        ]);
    }

    public function onFinderAfterDelete(FinderEvent\AfterDeleteEvent $event): void
    {
        $context = $event->getContext();
        $item    = $event->getItem();

        if ($context === 'com_jet_landing.landing') {
            $this->remove((int) $item->id);
        } elseif ($context === 'com_jet_landing.section' && !empty($item->landing_id)) {
            $this->reindex((int) $item->landing_id);
        } elseif ($context === 'com_content.article') {
            foreach ($this->getLandingIdsForArticles([(int) $item->id]) as $landingId) {
                $this->reindex($landingId);
            }
        } elseif ($context === 'com_finder.index') {
            $this->remove((int) $item->link_id);
        }
    }

    public function onFinderAfterSave(FinderEvent\AfterSaveEvent $event): void
    {
        $context = $event->getContext();
        $item    = $event->getItem();

        if ($context === 'com_jet_landing.landing') {
            $this->reindex((int) $item->id);
        } elseif ($context === 'com_jet_landing.section') {
            $this->reindex((int) $item->landing_id);
        } elseif ($context === 'com_content.article') {
            foreach ($this->getLandingIdsForArticles([(int) $item->id]) as $landingId) {
                $this->reindex($landingId);
            }
        }
    }

    public function onFinderBeforeSave(FinderEvent\BeforeSaveEvent $event): void
    {
        if ($event->getContext() === 'com_jet_landing.landing' && !$event->getIsNew()) {
            $this->checkItemAccess($event->getItem());
        }
    }

    public function onFinderChangeState(FinderEvent\AfterChangeStateEvent $event): void
    {
        $context = $event->getContext();

        if ($context === 'com_jet_landing.landing') {
            $this->itemStateChange($event->getPks(), $event->getValue());
        } elseif ($context === 'com_jet_landing.section') {
            foreach ($this->getLandingIdsForSections($event->getPks()) as $landingId) {
                $this->reindex($landingId);
            }
        } elseif ($context === 'com_content.article') {
            foreach ($this->getLandingIdsForArticles($event->getPks()) as $landingId) {
                $this->reindex($landingId);
            }
        } elseif ($context === 'com_plugins.plugin' && $event->getValue() === 0) {
            $this->pluginDisable($event->getPks());
        }
    }

    protected function index(Result $item): void
    {
        if (!ComponentHelper::isEnabled($this->extension)) {
            return;
        }

        $item->setLanguage();
        $item->params   = new Registry($item->params);
        $item->metadata = new Registry($item->metadata);
        $item->url      = $this->getUrl($item->id, $this->extension, $this->layout);
        $item->route    = RouteHelper::getLandingRoute((int) $item->id, (string) $item->language);
        $item->summary  = trim($item->summary . ' ' . $this->getSectionContent((int) $item->id));
        $item->metakey  = (string) $item->metadata->get('metakey');
        $item->metadesc = (string) $item->metadata->get('metadesc');

        $item->addInstruction(Indexer::META_CONTEXT, 'metakey');
        $item->addInstruction(Indexer::META_CONTEXT, 'metadesc');
        $item->addTaxonomy('Type', 'Landing');
        $item->addTaxonomy('Language', $item->language);

        $this->indexer->index($item);
    }

    protected function setup(): bool
    {
        return true;
    }

    protected function getListQuery($query = null): QueryInterface
    {
        $db = $this->getDatabase();

        return ($query instanceof QueryInterface ? $query : $db->createQuery())
            ->select('a.id, a.title, a.alias, a.description AS summary')
            ->select('a.state, a.access, a.ordering, a.created AS start_date')
            ->select('a.publish_up AS publish_start_date, a.publish_down AS publish_end_date')
            ->select('a.created_by, a.modified, a.modified_by, a.params, a.metadata, a.language')
            ->from($db->quoteName('#__jet_landings', 'a'));
    }

    private function getSectionContent(int $landingId): string
    {
        $db    = $this->getDatabase();
        $now   = (string) Factory::getDate()->toSql();
        $query = $db->createQuery()
            ->select([
                $db->quoteName('s.title'),
                $db->quoteName('s.content'),
                $db->quoteName('s.source_type'),
                $db->quoteName('s.seo_mode'),
                $db->quoteName('content.title', 'article_title'),
                $db->quoteName('content.introtext'),
                $db->quoteName('content.fulltext'),
                $db->quoteName('content.state', 'article_state'),
                $db->quoteName('content.access', 'article_access'),
                $db->quoteName('content.publish_up', 'article_publish_up'),
                $db->quoteName('content.publish_down', 'article_publish_down'),
                $db->quoteName('category.published', 'category_state'),
                $db->quoteName('category.access', 'category_access'),
                $db->quoteName('landing.access', 'landing_access'),
            ])
            ->from($db->quoteName('#__jet_landing_sections', 's'))
            ->join('LEFT', $db->quoteName('#__content', 'content'), $db->quoteName('content.id') . ' = ' . $db->quoteName('s.source_id'))
            ->join('LEFT', $db->quoteName('#__categories', 'category'), $db->quoteName('category.id') . ' = ' . $db->quoteName('content.catid'))
            ->join('INNER', $db->quoteName('#__jet_landings', 'landing'), $db->quoteName('landing.id') . ' = ' . $db->quoteName('s.landing_id'))
            ->where($db->quoteName('s.landing_id') . ' = :landingId')
            ->where($db->quoteName('s.state') . ' = 1')
            ->order($db->quoteName('s.ordering') . ' ASC')
            ->bind(':landingId', $landingId, ParameterType::INTEGER);
        $sections = $db->setQuery($query)->loadObjectList();

        return implode(' ', array_map(
            static function (object $section) use ($now): string {
                if ($section->source_type !== 'article') {
                    return $section->title . ' ' . strip_tags($section->content);
                }

                $allowedAccess = [1, (int) $section->landing_access];

                if (
                    (int) $section->article_state !== 1
                    || (int) $section->category_state < 1
                    || !in_array((int) $section->article_access, $allowedAccess, true)
                    || !in_array((int) $section->category_access, $allowedAccess, true)
                    || ($section->article_publish_up !== null && $section->article_publish_up > $now)
                    || ($section->article_publish_down !== null && $section->article_publish_down < $now)
                ) {
                    return $section->title;
                }

                $title = $section->article_title ?: $section->title;
                $text  = $section->seo_mode === 'independent'
                    ? ($section->introtext ?: $section->fulltext)
                    : trim((string) $section->introtext . ' ' . (string) $section->fulltext);

                return $title . ' ' . strip_tags((string) $text);
            },
            $sections
        ));
    }

    private function getLandingIdsForSections(array $sectionIds): array
    {
        $ids = array_values(array_filter(array_map('intval', $sectionIds)));

        if (!$ids) {
            return [];
        }

        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select('DISTINCT ' . $db->quoteName('landing_id'))
            ->from($db->quoteName('#__jet_landing_sections'))
            ->whereIn($db->quoteName('id'), $ids);

        return array_map('intval', $db->setQuery($query)->loadColumn());
    }

    private function getLandingIdsForArticles(array $articleIds): array
    {
        $ids = array_values(array_filter(array_map('intval', $articleIds)));

        if (!$ids) {
            return [];
        }

        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select('DISTINCT ' . $db->quoteName('landing_id'))
            ->from($db->quoteName('#__jet_landing_sections'))
            ->where($db->quoteName('source_type') . ' = ' . $db->quote('article'))
            ->whereIn($db->quoteName('source_id'), $ids);

        return array_map('intval', $db->setQuery($query)->loadColumn());
    }
}
