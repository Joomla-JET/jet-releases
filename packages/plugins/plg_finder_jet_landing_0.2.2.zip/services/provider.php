<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Plugin\Finder\JetLanding\Extension\JetLanding;

return new class () implements ServiceProviderInterface {
    /** Register extension services in Joomla's dependency injection container. */
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            $container->lazy(JetLanding::class, static function (Container $container): JetLanding {
                $plugin = new JetLanding((array) PluginHelper::getPlugin('finder', 'jet_landing'));
                $plugin->setApplication(Factory::getApplication());
                $plugin->setDatabase($container->get(DatabaseInterface::class));

                return $plugin;
            })
        );
    }
};
