<?php

/** Enable a newly installed JET Landing system plugin through Joomla's installer services. */

declare(strict_types=1);

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

defined('_JEXEC') or die;

return new class () implements ServiceProviderInterface {
    /** Register a fresh installer with the database service from its container. */
    public function register(Container $container): void
    {
        $container->set(InstallerScriptInterface::class, static fn (Container $container): InstallerScriptInterface =>
            new class ($container->get(DatabaseInterface::class)) implements InstallerScriptInterface {
                /** Receive the Joomla database service without global factories. */
                public function __construct(private readonly DatabaseInterface $db)
                {
                }

                /** Delegate initial installation to Joomla. */
                public function install(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Preserve the administrator's enabled state during updates. */
                public function update(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Delegate removal to Joomla. */
                public function uninstall(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Allow Joomla to validate extension installation requirements. */
                public function preflight(string $type, InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Enable only a newly installed plugin; never re-enable an existing disabled plugin. */
                public function postflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type === 'install') {
                        $query = $this->db->createQuery()
                            ->update($this->db->quoteName('#__extensions'))
                            ->set($this->db->quoteName('enabled') . ' = 1')
                            ->where($this->db->quoteName('type') . ' = ' . $this->db->quote('plugin'))
                            ->where($this->db->quoteName('folder') . ' = ' . $this->db->quote('system'))
                            ->where($this->db->quoteName('element') . ' = ' . $this->db->quote('jet_landing'));
                        $this->db->setQuery($query)->execute();
                    }
                    return true;
                }
            }
        );
    }
};
