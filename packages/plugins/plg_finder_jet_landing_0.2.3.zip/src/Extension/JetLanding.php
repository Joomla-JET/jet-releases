<?php

declare(strict_types=1);

namespace Joomla\Plugin\Finder\JetLanding\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Event\Finder as FinderEvent;
use Joomla\CMS\Date\Date;
use Joomla\Component\Finder\Administrator\Indexer\Adapter;
use Joomla\Component\Finder\Administrator\Indexer\Indexer;
use Joomla\Component\Finder\Administrator\Indexer\Result;
use Joomla\Component\JetLanding\Site\Helper\RouteHelper;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;
use Joomla\Event\SubscriberInterface;
use Joomla\Registry\Registry;

/** Synchronize JET Landing with Joomla Smart Search indexing. */
final class JetLanding extends Adapter implements SubscriberInterface
{
    use DatabaseAwareTrait;

    protected $context = 'JET Landing';

    protected $extension = 'com_jet_landing';

    protected $layout = 'landing';

    protected $type_title = 'Landing';

    protected $table = '#__jet_landings';

    protected $state_field = 'state';

    protected $autoloadLanguage = true;

    /** @var array<int, int> Remember the previous landing when a section moves. */
    private array $previousLandings = [];

    /** Declare typed Joomla events handled by this extension. */
    public static function getSubscribedEvents(): array
    {
        return array_merge(parent::getSubscribedEvents(), [
            'onFinderAfterDelete' => 'onFinderAfterDelete',
            'onFinderAfterSave'   => 'onFinderAfterSave',
            'onFinderBeforeSave'  => 'onFinderBeforeSave',
            'onFinderChangeState' => 'onFinderChangeState',
            'onFinderCategoryChangeState' => 'onFinderCategoryChangeState',
        ]);
    }

    /** Remove or refresh landing search entries after related content is deleted. */
    public function onFinderAfterDelete(FinderEvent\AfterDeleteEvent $event): void
    {
        $context = $event->getContext();
        $item    = $event->getItem();

        if ($context === 'com_jet_landing.landing') {
            $this->remove((int) $item->id);
        } elseif ($context === 'com_jet_landing.section' && !empty($item->landing_id)) {
            $this->reindex((int) $item->landing_id);
        } elseif ($context === 'com_content.article') {
            foreach ($this->getLandingIdsForArticles([(int) $item->id]) as $landingId) {
                $this->reindex($landingId);
            }
        } elseif ($context === 'com_finder.index') {
            $this->remove((int) $item->link_id);
        }
    }

    /** Refresh landing search entries after related content is saved. */
    public function onFinderAfterSave(FinderEvent\AfterSaveEvent $event): void
    {
        $context = $event->getContext();
        $item    = $event->getItem();

        if ($context === 'com_jet_landing.landing') {
            $this->reindex((int) $item->id);
        } elseif ($context === 'com_jet_landing.section') {
            $sectionId = (int) $item->id;
            $landingIds = array_unique([(int) $item->landing_id, $this->previousLandings[$sectionId] ?? (int) $item->landing_id]);
            unset($this->previousLandings[$sectionId]);

            foreach ($landingIds as $landingId) {
                $this->reindex($landingId);
            }
        } elseif (in_array($context, ['com_content.article', 'com_content.form'], true)) {
            foreach ($this->getLandingIdsForArticles([(int) $item->id]) as $landingId) {
                $this->reindex($landingId);
            }
        } elseif ($context === 'com_categories.category' && ($item->extension ?? '') === 'com_content') {
            foreach ($this->getLandingIdsForCategories([(int) $item->id]) as $landingId) {
                $this->reindex($landingId);
            }
        }
    }

    /** Capture the search state needed before an existing record changes. */
    public function onFinderBeforeSave(FinderEvent\BeforeSaveEvent $event): void
    {
        if ($event->getContext() === 'com_jet_landing.landing' && !$event->getIsNew()) {
            $this->checkItemAccess($event->getItem());
        } elseif ($event->getContext() === 'com_jet_landing.section' && !$event->getIsNew()) {
            $sectionId = (int) $event->getItem()->id;
            $landingIds = $this->getLandingIdsForSections([$sectionId]);

            if ($landingIds) {
                $this->previousLandings[$sectionId] = $landingIds[0];
            }
        }
    }

    /** Refresh aggregated text when an article category is published or unpublished. */
    public function onFinderCategoryChangeState(FinderEvent\AfterCategoryChangeStateEvent $event): void
    {
        if ($event->getExtension() !== 'com_content') {
            return;
        }

        foreach ($this->getLandingIdsForCategories($event->getPks()) as $landingId) {
            $this->reindex($landingId);
        }
    }

    /** Synchronize landing search entries with related publication state changes. */
    public function onFinderChangeState(FinderEvent\AfterChangeStateEvent $event): void
    {
        $context = $event->getContext();

        if ($context === 'com_jet_landing.landing') {
            $this->itemStateChange($event->getPks(), $event->getValue());
        } elseif ($context === 'com_jet_landing.section') {
            foreach ($this->getLandingIdsForSections($event->getPks()) as $landingId) {
                $this->reindex($landingId);
            }
        } elseif ($context === 'com_content.article') {
            foreach ($this->getLandingIdsForArticles($event->getPks()) as $landingId) {
                $this->reindex($landingId);
            }
        } elseif ($context === 'com_plugins.plugin' && $event->getValue() === 0) {
            $this->pluginDisable($event->getPks());
        }
    }

    /** Aggregate searchable landing content and submit it to Joomla Smart Search. */
    protected function index(Result $item): void
    {
        if (!ComponentHelper::isEnabled($this->extension)) {
            return;
        }

        $item->setLanguage();
        $item->params   = new Registry($item->params);
        $item->metadata = new Registry($item->metadata);
        $item->url      = $this->getUrl($item->id, $this->extension, $this->layout);
        $item->route    = RouteHelper::getLandingRoute((int) $item->id, (string) $item->language);
        $item->summary  = trim($item->summary . ' ' . $this->getSectionContent((int) $item->id));
        $item->metakey  = (string) $item->metadata->get('metakey');
        $item->metadesc = (string) $item->metadata->get('metadesc');

        $item->addInstruction(Indexer::META_CONTEXT, 'metakey');
        $item->addInstruction(Indexer::META_CONTEXT, 'metadesc');
        $item->addTaxonomy('Type', 'Landing');
        $item->addTaxonomy('Language', $item->language);

        $this->indexer->index($item);
    }

    /** Initialize the Smart Search adapter before indexing. */
    protected function setup(): bool
    {
        return true;
    }

    /** Build the list query using typed filters and Joomla query APIs. */
    protected function getListQuery($query = null): QueryInterface
    {
        $db = $this->getDatabase();

        return ($query instanceof QueryInterface ? $query : $db->createQuery())
            ->select('a.id, a.title, a.alias, a.description AS summary')
            ->select('a.state, a.access, a.ordering, a.created AS start_date')
            ->select('a.publish_up AS publish_start_date, a.publish_down AS publish_end_date')
            ->select('a.created_by, a.modified, a.modified_by, a.params, a.metadata, a.language')
            ->from($db->quoteName('#__jet_landings', 'a'));
    }

    /** Aggregate visible section text without exposing inaccessible article content. */
    private function getSectionContent(int $landingId): string
    {
        $db    = $this->getDatabase();
        $now   = (new Date('now', 'UTC'))->toSql(false, $db);
        $query = $db->createQuery()
            ->select([
                $db->quoteName('s.title'),
                $db->quoteName('s.content'),
                $db->quoteName('s.source_type'),
                $db->quoteName('s.seo_mode'),
                $db->quoteName('content.title', 'article_title'),
                $db->quoteName('content.introtext'),
                $db->quoteName('content.fulltext'),
                $db->quoteName('content.state', 'article_state'),
                $db->quoteName('content.access', 'article_access'),
                $db->quoteName('content.publish_up', 'article_publish_up'),
                $db->quoteName('content.publish_down', 'article_publish_down'),
                $db->quoteName('category.published', 'category_state'),
                $db->quoteName('category.access', 'category_access'),
                $db->quoteName('landing.access', 'landing_access'),
            ])
            ->from($db->quoteName('#__jet_landing_sections', 's'))
            ->join('LEFT', $db->quoteName('#__content', 'content'), $db->quoteName('content.id') . ' = ' . $db->quoteName('s.source_id'))
            ->join('LEFT', $db->quoteName('#__categories', 'category'), $db->quoteName('category.id') . ' = ' . $db->quoteName('content.catid'))
            ->join('INNER', $db->quoteName('#__jet_landings', 'landing'), $db->quoteName('landing.id') . ' = ' . $db->quoteName('s.landing_id'))
            ->where($db->quoteName('s.landing_id') . ' = :landingId')
            ->where($db->quoteName('s.state') . ' = 1')
            ->extendWhere('AND', [$db->quoteName('s.publish_up') . ' IS NULL', $db->quoteName('s.publish_up') . ' <= :sectionUp'], 'OR')
            ->extendWhere('AND', [$db->quoteName('s.publish_down') . ' IS NULL', $db->quoteName('s.publish_down') . ' >= :sectionDown'], 'OR')
            ->order($db->quoteName('s.ordering') . ' ASC')
            ->bind(':landingId', $landingId, ParameterType::INTEGER)
            ->bind(':sectionUp', $now)
            ->bind(':sectionDown', $now);
        $sections = $db->setQuery($query)->loadObjectList();

        return implode(' ', array_map(
            static function (object $section) use ($now): string {
                if ($section->source_type !== 'article') {
                    return $section->title . ' ' . strip_tags($section->content);
                }

                $allowedAccess = [1, (int) $section->landing_access];

                if (
                    (int) $section->article_state !== 1
                    || (int) $section->category_state < 1
                    || !in_array((int) $section->article_access, $allowedAccess, true)
                    || !in_array((int) $section->category_access, $allowedAccess, true)
                    || ($section->article_publish_up !== null && $section->article_publish_up > $now)
                    || ($section->article_publish_down !== null && $section->article_publish_down < $now)
                ) {
                    return '';
                }

                $title = $section->article_title ?: $section->title;
                $text  = $section->seo_mode === 'independent'
                    ? ($section->introtext ?: $section->fulltext)
                    : trim((string) $section->introtext . ' ' . (string) $section->fulltext);

                return $title . ' ' . strip_tags((string) $text);
            },
            $sections
        ));
    }

    /** Find affected landing IDs from changed section IDs. */
    private function getLandingIdsForSections(array $sectionIds): array
    {
        $ids = array_values(array_filter(array_map('intval', $sectionIds)));

        if (!$ids) {
            return [];
        }

        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select('DISTINCT ' . $db->quoteName('landing_id'))
            ->from($db->quoteName('#__jet_landing_sections'))
            ->whereIn($db->quoteName('id'), $ids);

        return array_map('intval', $db->setQuery($query)->loadColumn());
    }

    /** Find affected landing IDs from changed article IDs. */
    private function getLandingIdsForArticles(array $articleIds): array
    {
        $ids = array_values(array_filter(array_map('intval', $articleIds)));

        if (!$ids) {
            return [];
        }

        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select('DISTINCT ' . $db->quoteName('landing_id'))
            ->from($db->quoteName('#__jet_landing_sections'))
            ->where($db->quoteName('source_type') . ' = ' . $db->quote('article'))
            ->whereIn($db->quoteName('source_id'), $ids);

        return array_map('intval', $db->setQuery($query)->loadColumn());
    }

    /** Find landing pages whose indexed article text depends on the changed categories. */
    private function getLandingIdsForCategories(array $categoryIds): array
    {
        $ids = array_values(array_filter(array_map('intval', $categoryIds), static fn (int $id): bool => $id > 0));

        if (!$ids) {
            return [];
        }

        $db = $this->getDatabase();
        $query = $db->createQuery()
            ->select('DISTINCT ' . $db->quoteName('section.landing_id'))
            ->from($db->quoteName('#__jet_landing_sections', 'section'))
            ->join('INNER', $db->quoteName('#__content', 'article'), $db->quoteName('article.id') . ' = ' . $db->quoteName('section.source_id'))
            ->where($db->quoteName('section.source_type') . ' = ' . $db->quote('article'))
            ->whereIn($db->quoteName('article.catid'), $ids);

        return array_map('intval', $db->setQuery($query)->loadColumn());
    }
}
