<?php

declare(strict_types=1);

namespace Joomla\Plugin\System\JetCookieConsent\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Event\Application\AfterRenderEvent;
use Joomla\CMS\Event\Application\BeforeCompileHeadEvent;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\Priority;
use Joomla\Event\SubscriberInterface;

final class JetCookieConsent extends CMSPlugin implements SubscriberInterface
{
	protected $autoloadLanguage = true;

	private const CATEGORIES = ['preferences', 'statistics', 'marketing', 'external'];

	private const ATTRIBUTE_PATTERN = '/(?:^|\s)([^\s"\'=<>\/\x60]+)(?:\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'=<>\x60]+)))?/';

	public static function getSubscribedEvents(): array
	{
		return [
			'onBeforeCompileHead' => 'registerAssets',
			'onAfterRender' => ['processPage', Priority::NORMAL],
		];
	}

	public function registerAssets(BeforeCompileHeadEvent $event): void
	{
		if (!$this->getApplication()->isClient('site') || !$event->getDocument() instanceof HtmlDocument) {
			return;
		}

		$wa = $event->getDocument()->getWebAssetManager();
		$wa->getRegistry()->addExtensionRegistryFile('plg_system_jet_cookie_consent');
		$wa->useStyle('plg_system_jet_cookie_consent.style');
		$wa->useScript('plg_system_jet_cookie_consent.script');
	}

	public function processPage(AfterRenderEvent $event): void
	{
		$app = $this->getApplication();

		if (!$app->isClient('site') || $app->getInput()->getCmd('format', 'html') !== 'html') {
			return;
		}

		$body = $app->getBody();

		if ($body === '' || stripos($body, '</body>') === false) {
			return;
		}

		$rules = $this->getSourceRules();
		$detectedCategories = [];
		[$managedScripts, $managedCategories] = $this->renderManagedScripts();

		if ($managedScripts !== '') {
			$body = preg_replace_callback('/<\/head>/i', static fn (): string => $managedScripts . "\n</head>", $body, 1) ?? $body;
		}

		$body = $this->neutraliseContent($body, $rules, $detectedCategories);
		$categories = $this->getEnabledCategories(array_merge($detectedCategories, $managedCategories));
		$options = $this->getOptions();
		$layout = new FileLayout('banner', dirname(__DIR__, 2) . '/layouts');
		$banner = $layout->render([
			'options' => $options,
			'categories' => $categories,
		]);

		$body = preg_replace_callback('/<\/body>/i', static fn (): string => $banner . "\n</body>", $body, 1) ?? $body;
		$app->setBody($body);
	}

	/** @return array<string, bool|int|string> */
	private function getOptions(): array
	{
		$cookieName = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $this->params->get('cookie_name', 'jet_cookie_consent'));
		$version = trim((string) $this->params->get('consent_version', '1'));
		$reopenIcon = (bool) $this->params->get('show_reopen_icon', 1);
		$reopenShowLabel = (bool) $this->params->get('show_reopen_label', 0);

		return [
			'heading' => $this->textOrDefault('heading', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_HEADING'),
			'message' => $this->textOrDefault('message', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_MESSAGE'),
			'policyUrl' => trim((string) $this->params->get('policy_url', '')),
			'policyLabel' => $this->textOrDefault('policy_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_POLICY_LABEL'),
			'policyTarget' => (string) $this->params->get('policy_target', 'self') === 'blank' ? '_blank' : '_self',
			'acceptLabel' => $this->textOrDefault('accept_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_ACCEPT_LABEL'),
			'rejectLabel' => $this->textOrDefault('reject_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_REJECT_LABEL'),
			'customiseLabel' => $this->textOrDefault('customise_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_CUSTOMISE_LABEL'),
			'saveLabel' => $this->textOrDefault('save_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_SAVE_LABEL'),
			'reopenLabel' => $this->textOrDefault('reopen_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_REOPEN_LABEL'),
			'reopenIcon' => $reopenIcon,
			'reopenShowLabel' => $reopenShowLabel,
			'showReopen' => (bool) $this->params->get('show_reopen', 1) && ($reopenIcon || $reopenShowLabel),
			'cookieName' => $cookieName !== '' ? $cookieName : 'jet_cookie_consent',
			'consentVersion' => substr($version !== '' ? $version : '1', 0, 64),
			'lifetimeDays' => max(1, min(730, (int) $this->params->get('lifetime_days', 184))),
			'delay' => max(0, min(10000, (int) $this->params->get('delay', 0))),
			'position' => (string) $this->params->get('position', 'bottom') === 'top' ? 'top' : 'bottom',
			'width' => (string) $this->params->get('width', 'container') === 'full' ? 'full' : 'container',
			'radius' => $this->normalise((string) $this->params->get('radius', 'normal'), ['none', 'normal', 'large'], 'normal'),
			'shadow' => (bool) $this->params->get('shadow', 1),
			'backgroundColor' => $this->colour('background_color'),
			'textColor' => $this->colour('text_color'),
			'borderColor' => $this->colour('border_color'),
		];
	}

	/** @param array<int, string> $detected @return array<int, string> */
	private function getEnabledCategories(array $detected): array
	{
		$enabled = [];

		foreach (self::CATEGORIES as $category) {
			if ((bool) $this->params->get('enable_' . $category, 0)
				|| in_array($category, $detected, true)) {
				$enabled[] = $category;
			}
		}

		return $enabled;
	}

	/** @return array<int, array{pattern: string, category: string, host: string}> */
	private function getSourceRules(): array
	{
		$rules = [];

		foreach ($this->normaliseSubform($this->params->get('source_rules', [])) as $item) {
			$pattern = trim((string) ($item['pattern'] ?? ''));
			$category = (string) ($item['category'] ?? '');

			if ($pattern !== '' && in_array($category, self::CATEGORIES, true)) {
				$rules[] = ['pattern' => $pattern, 'category' => $category, 'host' => strtolower(trim((string) ($item['host'] ?? '')))];
			}
		}

		return $rules;
	}

	/** @return array{0: string, 1: array<int, string>} */
	private function renderManagedScripts(): array
	{
		$html = [];
		$categories = [];

		foreach ($this->normaliseSubform($this->params->get('managed_scripts', [])) as $item) {
			$category = (string) ($item['category'] ?? '');
			$source = trim((string) ($item['source'] ?? ''));
			$code = trim((string) ($item['code'] ?? ''));

			if (!in_array($category, self::CATEGORIES, true) || ($source === '' && $code === '')) {
				continue;
			}

			$attributes = [
				'type="text/plain"',
				'data-jet-cookie-category="' . htmlspecialchars($category, ENT_QUOTES, 'UTF-8') . '"',
				'data-jet-cookie-type="' . ((string) ($item['type'] ?? 'classic') === 'module' ? 'module' : 'text/javascript') . '"',
			];

			if ($source !== '') {
				$attributes[] = 'data-jet-cookie-src="' . htmlspecialchars($source, ENT_QUOTES, 'UTF-8') . '"';
			}

			if ($code !== '') {
				$attributes[] = 'data-jet-cookie-code="' . base64_encode($code) . '"';
			}

			if (!empty($item['async'])) {
				$attributes[] = 'data-jet-cookie-async="true"';
			}

			foreach (['target', 'title', 'description', 'provider', 'url'] as $metadata) {
				$value = trim((string) ($item[$metadata] ?? ''));

				if ($value !== '') {
					$attributes[] = 'data-jet-cookie-' . $metadata . '="' . htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '"';
				}
			}

			$html[] = '<script ' . implode(' ', $attributes) . '></script>';
			$categories[] = $category;
		}

		return [implode("\n", $html), array_values(array_unique($categories))];
	}

	/**
	 * @param array<int, array{pattern: string, category: string, host: string}> $rules
	 * @param array<int, string> $detectedCategories
	 */
	private function neutraliseContent(string $html, array $rules, array &$detectedCategories): string
	{
		$scriptFallbacks = [];
		$index = 0;
		// Skip comments and raw text as complete tokens, including JavaScript strings containing iframe markup.
		$pattern = '~<!--.*?-->|<(script|iframe|style|textarea|title|template|noscript)\b((?:"[^"]*"|\'[^\']*\'|[^\'">])*)>(.*?)</\1\s*>~is';
		$html = preg_replace_callback(
			$pattern,
			function (array $matches) use ($rules, &$detectedCategories, &$scriptFallbacks, &$index): string {
				$tag = strtolower($matches[1] ?? '');

				if (!in_array($tag, ['script', 'iframe'], true)) {
					return $matches[0];
				}

				$attributes = $matches[2];
				$source = $this->attribute($attributes, 'src') ?? $this->attribute($attributes, 'data-jet-cookie-src') ?? '';

				if (str_contains($source, '/media/plg_system_jet_cookie_consent/')) {
					return $matches[0];
				}

				$category = $this->classify($attributes, $source, $rules);

				if (!in_array($category, self::CATEGORIES, true)) {
					return $matches[0];
				}

				$detectedCategories[] = $category;

				if ($tag === 'iframe') {
					return $this->renderBlockedContent($attributes, $source, $category, ++$index, $matches[0]);
				}

				$target = $this->attribute($attributes, 'data-jet-cookie-target') ?? '';

				if ($target !== '') {
					$scriptFallbacks[$target][] = $this->renderBlockedContent($attributes, $source, $category, ++$index);
				}

				$originalType = $this->attribute($attributes, 'type') ?? 'text/javascript';
				if ($originalType === 'text/plain' && $this->attribute($attributes, 'data-jet-cookie-type') !== null) {
					return $matches[0];
				}
				$attributes = $this->withoutAttribute($attributes, 'type');
				$attributes = $this->withoutAttribute($attributes, 'src');
				$attributes = $this->withoutAttribute($attributes, 'data-jet-cookie-category');
				$attributes = $this->withoutAttribute($attributes, 'data-jet-cookie-src');
				$attributes = $this->withoutAttribute($attributes, 'data-jet-cookie-type');
				$attributes = trim($attributes);
				$blocked = $attributes !== '' ? ' ' . $attributes : '';
				$blocked .= ' type="text/plain" data-jet-cookie-category="' . $category . '"';
				$blocked .= ' data-jet-cookie-type="' . htmlspecialchars($originalType, ENT_QUOTES, 'UTF-8') . '"';

				if ($source !== '') {
					$blocked .= ' data-jet-cookie-src="' . htmlspecialchars($source, ENT_QUOTES, 'UTF-8') . '"';
				}

				return '<script' . $blocked . '>' . $matches[3] . '</script>';
			},
			$html
		) ?? $html;

		if ($scriptFallbacks === []) {
			return $html;
		}

		// Insert alternatives into explicitly named visual containers, never into the document head.
		return preg_replace_callback(
			'~<!--.*?-->|<(script|iframe|style|textarea|title|template|noscript)\b((?:"[^"]*"|\'[^\']*\'|[^\'">])*)>(.*?)</\1\s*>|<(div|section|figure)\b((?:"[^"]*"|\'[^\']*\'|[^\'">])*)>~is',
			function (array $matches) use (&$scriptFallbacks): string {
				if (empty($matches[4])) {
					return $matches[0];
				}

				$id = $this->attribute($matches[5], 'id') ?? '';
				$fallbacks = $scriptFallbacks[$id] ?? [];
				unset($scriptFallbacks[$id]);

				return $matches[0] . implode('', $fallbacks);
			},
			$html
		) ?? $html;
	}

	/**
	 * @param array<int, array{pattern: string, category: string, host: string}> $rules
	 */
	private function classify(string $attributes, string $source, array $rules): string
	{
		$explicit = strtolower($this->attribute($attributes, 'data-jet-cookie-category') ?? '');

		if (in_array($explicit, self::CATEGORIES, true)) {
			return $explicit;
		}

		$host = strtolower((string) parse_url(str_starts_with($source, '//') ? 'https:' . $source : $source, PHP_URL_HOST));

		foreach ($rules as $rule) {
			if ($source !== '' && ($rule['host'] === '' || $rule['host'] === $host) && stripos($source, $rule['pattern']) !== false) {
				return $rule['category'];
			}
		}

		return '';
	}

	/** @return array{kind: string, name: string, url: string, subject: string} */
	private function provider(string $source): array
	{
		$url = $this->safeExternalUrl($source);
		$parts = parse_url($url);
		$host = strtolower($parts['host'] ?? '');
		$path = $parts['path'] ?? '';
		$result = ['kind' => '', 'name' => $host ?: Text::_('PLG_SYSTEM_JET_COOKIE_CONSENT_EXTERNAL_PROVIDER'), 'url' => $url, 'subject' => ''];
		parse_str($parts['query'] ?? '', $query);

		if ((in_array($host, ['google.com', 'www.google.com', 'maps.google.com', 'google.it', 'www.google.it', 'maps.google.it'], true)
				&& preg_match('~^/maps(?:/|$)~', $path))
			|| ($host === 'maps.googleapis.com' && $path === '/maps/api/js')) {
			$result['kind'] = 'map';
			$result['name'] = 'Google Maps';
			$subject = is_string($query['q'] ?? null) ? trim($query['q']) : '';
			$result['subject'] = $subject;
			$result['url'] = $subject !== ''
				? 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($subject)
				: ($host === 'maps.googleapis.com' ? '' : $url);
		}

		if (in_array($host, ['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtube-nocookie.com', 'www.youtube-nocookie.com'], true)
			&& (str_starts_with($path, '/embed/') || in_array($path, ['/iframe_api', '/player_api'], true))) {
			$result['kind'] = 'video';
			$result['name'] = 'YouTube';
			$result['url'] = '';

			if (preg_match('~^/embed/([a-zA-Z0-9_-]{11})$~', $path, $match)) {
				$result['url'] = 'https://www.youtube.com/watch?v=' . $match[1];
			} elseif (is_string($query['list'] ?? null) && preg_match('/^[a-zA-Z0-9_-]+$/', $query['list'])) {
				$result['url'] = 'https://www.youtube.com/playlist?list=' . rawurlencode($query['list']);
			}
		}

		return $result;
	}

	private function safeExternalUrl(string $url): string
	{
		$url = trim($url);
		$url = str_starts_with($url, '//') ? 'https:' . $url : $url;
		$parts = parse_url($url);

		if ($parts === false || !in_array(strtolower($parts['scheme'] ?? ''), ['http', 'https'], true)
			|| empty($parts['host']) || isset($parts['user']) || isset($parts['pass'])
			|| preg_match('/[\x00-\x20\x7f\\\\]/', $url)) {
			return '';
		}

		return $url;
	}

	private function renderBlockedContent(string $attributes, string $source, string $category, int $index, string $iframe = ''): string
	{
		$provider = $this->provider($source);
		$providerName = trim($this->attribute($attributes, 'data-jet-cookie-provider') ?? '') ?: $provider['name'];
		$title = trim($this->attribute($attributes, 'data-jet-cookie-title') ?? $this->attribute($attributes, 'title') ?? '');

		if ($title === '') {
			$title = match (true) {
				$provider['kind'] === 'map' && $provider['subject'] !== '' => Text::sprintf('PLG_SYSTEM_JET_COOKIE_CONSENT_BLOCKED_MAP_TITLE', $provider['subject']),
				$provider['kind'] === 'map' => Text::_('PLG_SYSTEM_JET_COOKIE_CONSENT_BLOCKED_MAP'),
				$provider['kind'] === 'video' => Text::_('PLG_SYSTEM_JET_COOKIE_CONSENT_BLOCKED_VIDEO'),
				default => $this->textOrDefault('blocked_title', 'PLG_SYSTEM_JET_COOKIE_CONSENT_BLOCKED_TITLE'),
			};
		}

		$categoryLabel = Text::_('PLG_SYSTEM_JET_COOKIE_CONSENT_CATEGORY_' . strtoupper($category));
		$message = strtr($this->textOrDefault('blocked_message', 'PLG_SYSTEM_JET_COOKIE_CONSENT_BLOCKED_MESSAGE'), [
			'{provider}' => $providerName,
			'{category}' => $categoryLabel,
		]);
		$styles = [];

		if ($iframe !== '') {
			foreach (['width' => 'width', 'height' => '--jet-cookie-content-height'] as $attribute => $property) {
				$dimension = $this->attribute($attributes, $attribute) ?? '';

				if (preg_match('/^\d{1,4}(?:\.\d+)?%?$/', $dimension)) {
					$styles[] = $property . ': ' . $dimension . (str_ends_with($dimension, '%') ? '' : 'px');
				}
			}
		}

		$explicitUrl = $this->attribute($attributes, 'data-jet-cookie-url');
		$layout = new FileLayout('blocked', dirname(__DIR__, 2) . '/layouts');

		return $layout->render([
			'id' => 'jet-cookie-blocked-' . $index,
			'category' => $category,
			'title' => $title,
			'description' => trim($this->attribute($attributes, 'data-jet-cookie-description') ?? ''),
			'message' => $message,
			'consentLabel' => strtr($this->textOrDefault('blocked_consent_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_BLOCKED_CONSENT_LABEL'), ['{category}' => $categoryLabel]),
			'externalLabel' => $this->textOrDefault('blocked_external_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_BLOCKED_EXTERNAL_LABEL'),
			'externalUrl' => $explicitUrl !== null ? $this->safeExternalUrl($explicitUrl) : ($iframe !== '' ? $provider['url'] : ''),
			'policyUrl' => trim((string) $this->params->get('policy_url', '')),
			'policyLabel' => $this->textOrDefault('policy_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_POLICY_LABEL'),
			'content' => $iframe !== '' ? base64_encode($iframe) : '',
			'classes' => $iframe !== '' ? ($this->attribute($attributes, 'class') ?? '') : '',
			'styles' => implode('; ', $styles),
		]);
	}

	private function attribute(string $attributes, string $name): ?string
	{
		preg_match_all(self::ATTRIBUTE_PATTERN, $attributes, $matches, PREG_SET_ORDER | PREG_UNMATCHED_AS_NULL);

		foreach ($matches as $match) {
			if (strtolower($match[1]) === strtolower($name)) {
				return html_entity_decode($match[2] ?? $match[3] ?? $match[4] ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8');
			}
		}

		return null;
	}

	private function withoutAttribute(string $attributes, string $name): string
	{
		return preg_replace_callback(
			self::ATTRIBUTE_PATTERN,
			static fn (array $match): string => strtolower($match[1]) === strtolower($name) ? '' : $match[0],
			$attributes
		) ?? $attributes;
	}

	/** @return array<int, array<string, mixed>> */
	private function normaliseSubform(mixed $value): array
	{
		$result = [];

		foreach ((array) $value as $item) {
			if (is_object($item)) {
				$item = get_object_vars($item);
			}

			if (is_array($item)) {
				$result[] = $item;
			}
		}

		return $result;
	}

	private function textOrDefault(string $name, string $languageKey): string
	{
		$value = trim((string) $this->params->get($name, ''));

		return $value !== '' ? $value : Text::_($languageKey);
	}

	private function colour(string $name): string
	{
		$value = trim((string) $this->params->get($name, ''));

		return preg_match('/^#[0-9a-f]{6}$/i', $value) ? $value : '';
	}

	/** @param array<int, string> $allowed */
	private function normalise(string $value, array $allowed, string $default): string
	{
		return in_array($value, $allowed, true) ? $value : $default;
	}
}
