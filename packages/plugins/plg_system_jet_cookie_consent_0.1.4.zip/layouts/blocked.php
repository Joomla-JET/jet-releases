<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/** @var array<string, string> $displayData */
$escape = static fn (string $value): string => htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$titleId = $displayData['id'] . '-title';
$descriptionId = $displayData['id'] . '-description';
?>
<div
	id="<?= $escape($displayData['id']) ?>"
	class="jet-cookie-blocked <?= $escape($displayData['classes']) ?>"
	data-jet-cookie-blocked
	data-jet-cookie-category="<?= $escape($displayData['category']) ?>"
	<?php if ($displayData['content'] !== '') : ?>data-jet-cookie-content="<?= $escape($displayData['content']) ?>"<?php endif; ?>
	<?php if ($displayData['styles'] !== '') : ?>style="<?= $escape($displayData['styles']) ?>"<?php endif; ?>
	role="region"
	aria-labelledby="<?= $escape($titleId) ?>"
	aria-describedby="<?= $escape($descriptionId) ?>"
>
	<div class="jet-cookie-blocked__content">
		<h3 id="<?= $escape($titleId) ?>" class="h5"><?= $escape($displayData['title']) ?></h3>
		<?php if ($displayData['description'] !== '') : ?>
			<p><?= $escape($displayData['description']) ?></p>
		<?php endif; ?>
		<p id="<?= $escape($descriptionId) ?>"><?= $escape($displayData['message']) ?></p>
		<?php if ($displayData['policyUrl'] !== '') : ?>
			<p><a href="<?= $escape($displayData['policyUrl']) ?>"><?= $escape($displayData['policyLabel']) ?></a></p>
		<?php endif; ?>
		<div class="jet-cookie-blocked__actions">
			<button type="button" class="btn btn-primary" data-jet-cookie-enable="<?= $escape($displayData['category']) ?>" disabled><?= $escape($displayData['consentLabel']) ?></button>
			<?php if ($displayData['externalUrl'] !== '') : ?>
				<a class="btn btn-outline-primary" href="<?= $escape($displayData['externalUrl']) ?>" target="_blank" rel="noopener noreferrer"><?= $escape($displayData['externalLabel']) ?><span class="visually-hidden"> <?= Text::_('PLG_SYSTEM_JET_COOKIE_CONSENT_NEW_WINDOW') ?></span></a>
			<?php endif; ?>
		</div>
		<noscript><p class="mt-2 mb-0"><?= Text::_('PLG_SYSTEM_JET_COOKIE_CONSENT_BLOCKED_NOSCRIPT') ?></p></noscript>
	</div>
</div>
