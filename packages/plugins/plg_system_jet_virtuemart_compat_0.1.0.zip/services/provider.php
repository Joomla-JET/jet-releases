<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Plugin\System\JetVirtueMartCompat\Extension\JetVirtueMartCompat;

return new class () implements ServiceProviderInterface {
    public function register(Container $container): void
    {
        $container->set(
            PluginInterface::class,
            $container->lazy(JetVirtueMartCompat::class, static function (Container $container): JetVirtueMartCompat {
                return new JetVirtueMartCompat((array) PluginHelper::getPlugin('system', 'jet_virtuemart_compat'));
            })
        );
    }
};
