<?php

declare(strict_types=1);

defined('_JEXEC') or die;

// This global name is required by VirtueMart's legacy category and user-field code.
// Keep the compatibility boundary isolated; conversion uses Joomla's public API.
if (!function_exists('utf8_strtolower')) {
    function utf8_strtolower(string $string): string|false
    {
        return \Joomla\String\StringHelper::strtolower($string);
    }
}
