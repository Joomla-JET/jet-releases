<?php

declare(strict_types=1);

namespace Joomla\Plugin\System\JetVirtueMartCompat\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Event\Application\AfterInitialiseEvent;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\Priority;
use Joomla\Event\SubscriberInterface;

final class JetVirtueMartCompat extends CMSPlugin implements SubscriberInterface
{
    public static function getSubscribedEvents(): array
    {
        return ['onAfterInitialise' => ['registerCompatibility', Priority::HIGH]];
    }

    public function registerCompatibility(AfterInitialiseEvent $event): void
    {
        if (function_exists('utf8_strtolower')) {
            return;
        }

        require_once dirname(__DIR__) . '/Compatibility/functions.php';
    }
}
