<?php

declare(strict_types=1);

namespace Joomla\Plugin\System\JetLanding\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Event\Application\AfterRouteEvent;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Router\Route;
use Joomla\Component\JetLanding\Site\Helper\RouteHelper;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;
use Joomla\Event\SubscriberInterface;

final class JetLanding extends CMSPlugin implements SubscriberInterface
{
    use DatabaseAwareTrait;

    protected $autoloadLanguage = true;

    public static function getSubscribedEvents(): array
    {
        return ['onAfterRoute' => 'redirectConsolidatedArticle'];
    }

    public function redirectConsolidatedArticle(AfterRouteEvent $event): void
    {
        $app = $this->getApplication();

        if (!$app->isClient('site')) {
            return;
        }

        $input  = $app->getInput();
        $method = strtoupper($input->server->getCmd('REQUEST_METHOD', 'GET'));

        if (
            !in_array($method, ['GET', 'HEAD'], true)
            || $input->getCmd('option') !== 'com_content'
            || $input->getCmd('view') !== 'article'
            || $input->getCmd('format', 'html') !== 'html'
        ) {
            return;
        }

        $articleId = $input->getInt('id');

        if ($articleId < 1) {
            return;
        }

        $target = $this->getRedirectTarget($articleId);

        if (!$target) {
            return;
        }

        $route       = RouteHelper::getLandingRoute((int) $target->landing_id, (string) $target->language);
        $destination = Route::_($route, false, Route::TLS_IGNORE, true)
            . '#' . rawurlencode((string) $target->section_alias);

        $app->redirect($destination, 301);
    }

    private function getRedirectTarget(int $articleId): ?object
    {
        $db     = $this->getDatabase();
        $now    = Factory::getDate()->toSql();
        $levels = $this->getApplication()->getIdentity()->getAuthorisedViewLevels();
        $query  = $db->createQuery()
            ->select([
                $db->quoteName('s.alias', 'section_alias'),
                $db->quoteName('l.id', 'landing_id'),
                $db->quoteName('l.language'),
            ])
            ->from($db->quoteName('#__jet_landing_sections', 's'))
            ->join('INNER', $db->quoteName('#__jet_landings', 'l'), $db->quoteName('l.id') . ' = ' . $db->quoteName('s.landing_id'))
            ->join('INNER', $db->quoteName('#__content', 'content'), $db->quoteName('content.id') . ' = ' . $db->quoteName('s.source_id'))
            ->join('INNER', $db->quoteName('#__categories', 'category'), $db->quoteName('category.id') . ' = ' . $db->quoteName('content.catid'))
            ->where($db->quoteName('s.source_type') . ' = ' . $db->quote('article'))
            ->where($db->quoteName('s.source_id') . ' = :articleId')
            ->where($db->quoteName('s.seo_mode') . ' = ' . $db->quote('consolidated'))
            ->where($db->quoteName('s.state') . ' = 1')
            ->where($db->quoteName('l.state') . ' = 1')
            ->where($db->quoteName('content.state') . ' = 1')
            ->where($db->quoteName('category.published') . ' > 0')
            ->whereIn($db->quoteName('l.access'), $levels)
            ->whereIn($db->quoteName('content.access'), $levels)
            ->whereIn($db->quoteName('category.access'), $levels)
            ->extendWhere('AND', [$db->quoteName('s.publish_up') . ' IS NULL', $db->quoteName('s.publish_up') . ' <= :sectionUp'], 'OR')
            ->extendWhere('AND', [$db->quoteName('s.publish_down') . ' IS NULL', $db->quoteName('s.publish_down') . ' >= :sectionDown'], 'OR')
            ->extendWhere('AND', [$db->quoteName('l.publish_up') . ' IS NULL', $db->quoteName('l.publish_up') . ' <= :landingUp'], 'OR')
            ->extendWhere('AND', [$db->quoteName('l.publish_down') . ' IS NULL', $db->quoteName('l.publish_down') . ' >= :landingDown'], 'OR')
            ->extendWhere('AND', [$db->quoteName('content.publish_up') . ' IS NULL', $db->quoteName('content.publish_up') . ' <= :articleUp'], 'OR')
            ->extendWhere('AND', [$db->quoteName('content.publish_down') . ' IS NULL', $db->quoteName('content.publish_down') . ' >= :articleDown'], 'OR')
            ->bind(':articleId', $articleId, ParameterType::INTEGER)
            ->bind(':sectionUp', $now)
            ->bind(':sectionDown', $now)
            ->bind(':landingUp', $now)
            ->bind(':landingDown', $now)
            ->bind(':articleUp', $now)
            ->bind(':articleDown', $now)
            ->order($db->quoteName('s.id') . ' ASC');

        if (Multilanguage::isEnabled()) {
            $query->whereIn(
                $db->quoteName('l.language'),
                ['*', $this->getApplication()->getLanguage()->getTag()],
                ParameterType::STRING
            );
            $query->whereIn(
                $db->quoteName('content.language'),
                ['*', $this->getApplication()->getLanguage()->getTag()],
                ParameterType::STRING
            );
        }

        return $db->setQuery($query, 0, 1)->loadObject() ?: null;
    }
}
