const VALID_CATEGORIES = new Set(['preferences', 'statistics', 'marketing']);

const readCookie = (name) => {
	const prefix = `${encodeURIComponent(name)}=`;
	const match = document.cookie.split('; ').find((item) => item.startsWith(prefix));

	if (!match) {
		return null;
	}

	try {
		return JSON.parse(decodeURIComponent(match.slice(prefix.length)));
	} catch {
		return null;
	}
};

const writeCookie = (element, choices) => {
	const name = encodeURIComponent(element.dataset.cookieName);
	const value = encodeURIComponent(JSON.stringify({
		version: element.dataset.consentVersion,
		choices,
		updatedAt: new Date().toISOString(),
	}));
	const days = Math.max(1, Number.parseInt(element.dataset.lifetimeDays || '180', 10) || 180);
	const secure = window.location.protocol === 'https:' ? '; Secure' : '';

	document.cookie = `${name}=${value}; Max-Age=${days * 86400}; Path=/; SameSite=Lax${secure}`;
};

const deleteCookie = (name) => {
	const secure = window.location.protocol === 'https:' ? '; Secure' : '';
	document.cookie = `${encodeURIComponent(name)}=; Max-Age=0; Path=/; SameSite=Lax${secure}`;
};

const getCategories = (element) => (element.dataset.categories || '')
	.split(',')
	.map((category) => category.trim())
	.filter((category) => VALID_CATEGORIES.has(category));

const normaliseChoices = (record, element) => {
	if (!record || record.version !== element.dataset.consentVersion || typeof record.choices !== 'object') {
		return null;
	}

	const choices = {necessary: true};

	getCategories(element).forEach((category) => {
		choices[category] = record.choices[category] === true;
	});

	return choices;
};

const getStatus = (choices, categories) => {
	const accepted = categories.filter((category) => choices[category]).length;

	if (accepted === 0) {
		return 'rejected';
	}

	return accepted === categories.length ? 'accepted' : 'customised';
};

const emit = (name, element, choices) => {
	const categories = getCategories(element);
	document.dispatchEvent(new CustomEvent(name, {
		detail: {
			status: choices ? getStatus(choices, categories) : null,
			choices,
			version: element.dataset.consentVersion,
			cookieName: element.dataset.cookieName,
		},
	}));
};

const decodeCode = (encoded) => {
	if (!encoded) {
		return '';
	}

	try {
		return new TextDecoder().decode(Uint8Array.from(window.atob(encoded), (character) => character.charCodeAt(0)));
	} catch {
		return '';
	}
};

const activateScript = (placeholder) => new Promise((resolve) => {
	if (placeholder.dataset.jetCookieActive === 'true') {
		resolve();
		return;
	}

	placeholder.dataset.jetCookieActive = 'true';
	const script = document.createElement('script');
	const source = placeholder.dataset.jetCookieSrc || '';
	const scriptType = placeholder.dataset.jetCookieType || 'text/javascript';
	const isAsync = placeholder.hasAttribute('async') || placeholder.dataset.jetCookieAsync === 'true';

	Array.from(placeholder.attributes).forEach(({name, value}) => {
		if (name !== 'type' && !name.startsWith('data-jet-cookie-') && name !== 'src') {
			script.setAttribute(name, value);
		}
	});

	if (scriptType !== 'text/javascript' && scriptType !== 'application/javascript') {
		script.type = scriptType;
	}

	if (source !== '') {
		script.src = source;
		script.async = isAsync;

		if (!isAsync) {
			script.addEventListener('load', resolve, {once: true});
			script.addEventListener('error', resolve, {once: true});
		}
	} else {
		script.textContent = placeholder.dataset.jetCookieCode
			? decodeCode(placeholder.dataset.jetCookieCode)
			: placeholder.textContent;
	}

	placeholder.replaceWith(script);

	if (source === '' || isAsync) {
		resolve();
	}
});

const activateAllowedScripts = async (choices) => {
	for (const placeholder of document.querySelectorAll('script[type="text/plain"][data-jet-cookie-category]')) {
		if (choices[placeholder.dataset.jetCookieCategory] === true) {
			await activateScript(placeholder);
		}
	}
};

const showBanner = (element, focus = false) => {
	const delay = Math.max(0, Number.parseInt(element.dataset.delay || '0', 10) || 0);

	window.setTimeout(() => {
		element.hidden = false;
		window.requestAnimationFrame(() => {
			element.classList.add('is-visible');
			if (focus) {
				element.querySelector('[tabindex="-1"]')?.focus();
			}
		});
	}, focus ? 0 : delay);
};

const hideBanner = (element) => {
	element.classList.remove('is-visible');
	window.setTimeout(() => {
		element.hidden = true;
	}, 220);
};

const setInputs = (element, choices) => {
	element.querySelectorAll('[data-jet-cookie-category-input]').forEach((input) => {
		input.checked = choices?.[input.dataset.jetCookieCategoryInput] === true;
	});
};

const initialise = async (element) => {
	const categories = getCategories(element);
	const reopen = document.querySelector('[data-jet-cookie-reopen]');
	const preferences = element.querySelector('[data-jet-cookie-preferences]');
	const customise = element.querySelector('[data-jet-cookie-customise]');
	let choices = normaliseChoices(readCookie(element.dataset.cookieName), element);

	if (choices) {
		setInputs(element, choices);
		await activateAllowedScripts(choices);
		if (reopen && element.dataset.showReopen === 'true') {
			reopen.hidden = false;
		}
	} else {
		showBanner(element);
	}

	emit('jet:cookie-consent-ready', element, choices);

	const persist = async (nextChoices) => {
		const revoked = choices && categories.some((category) => choices[category] && !nextChoices[category]);
		choices = nextChoices;
		writeCookie(element, choices);
		setInputs(element, choices);
		hideBanner(element);
		if (reopen && element.dataset.showReopen === 'true') {
			reopen.hidden = false;
			reopen.focus();
		}
		await activateAllowedScripts(choices);
		emit('jet:cookie-consent-change', element, choices);

		if (revoked) {
			window.location.reload();
		}
	};

	element.querySelector('[data-jet-cookie-accept]')?.addEventListener('click', () => {
		persist(Object.fromEntries([['necessary', true], ...categories.map((category) => [category, true])]));
	});

	element.querySelector('[data-jet-cookie-reject]')?.addEventListener('click', () => {
		persist(Object.fromEntries([['necessary', true], ...categories.map((category) => [category, false])]));
	});

	element.querySelector('[data-jet-cookie-save]')?.addEventListener('click', () => {
		const selected = {necessary: true};
		element.querySelectorAll('[data-jet-cookie-category-input]').forEach((input) => {
			selected[input.dataset.jetCookieCategoryInput] = input.checked;
		});
		persist(selected);
	});

	customise?.addEventListener('click', () => {
		const opening = preferences.hidden;
		preferences.hidden = !opening;
		customise.setAttribute('aria-expanded', opening ? 'true' : 'false');
		if (opening) {
			preferences.querySelector('input:not(:disabled)')?.focus();
		}
	});

	reopen?.addEventListener('click', () => {
		reopen.hidden = true;
		showBanner(element, true);
	});

	document.addEventListener('jet:cookie-consent-reset', (event) => {
		if (event.detail?.cookieName && event.detail.cookieName !== element.dataset.cookieName) {
			return;
		}
		deleteCookie(element.dataset.cookieName);
		window.location.reload();
	});
};

const start = () => document.querySelectorAll('[data-jet-cookie-consent]').forEach(initialise);

if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', start, {once: true});
} else {
	start();
}
