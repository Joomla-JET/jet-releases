<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Extension\PluginInterface;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Plugin\System\JetCookieConsent\Extension\JetCookieConsent;

return new class () implements ServiceProviderInterface {
	public function register(Container $container): void
	{
		$container->set(
			PluginInterface::class,
			$container->lazy(JetCookieConsent::class, static function (): JetCookieConsent {
				$plugin = new JetCookieConsent((array) PluginHelper::getPlugin('system', 'jet_cookie_consent'));
				$plugin->setApplication(Factory::getApplication());

				return $plugin;
			})
		);
	}
};
