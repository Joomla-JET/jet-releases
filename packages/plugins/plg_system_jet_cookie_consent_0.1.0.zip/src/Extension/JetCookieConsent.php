<?php

declare(strict_types=1);

namespace Joomla\Plugin\System\JetCookieConsent\Extension;

defined('_JEXEC') or die;

use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\Event\Application\AfterRenderEvent;
use Joomla\CMS\Event\Application\BeforeCompileHeadEvent;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\Priority;
use Joomla\Event\SubscriberInterface;

final class JetCookieConsent extends CMSPlugin implements SubscriberInterface
{
	protected $autoloadLanguage = true;

	private const CATEGORIES = ['preferences', 'statistics', 'marketing'];

	public static function getSubscribedEvents(): array
	{
		return [
			'onBeforeCompileHead' => 'registerAssets',
			'onAfterRender' => ['processPage', Priority::NORMAL],
		];
	}

	public function registerAssets(BeforeCompileHeadEvent $event): void
	{
		if (!$this->getApplication()->isClient('site') || !$event->getDocument() instanceof HtmlDocument) {
			return;
		}

		$wa = $event->getDocument()->getWebAssetManager();
		$wa->getRegistry()->addExtensionRegistryFile('plg_system_jet_cookie_consent');
		$wa->useStyle('plg_system_jet_cookie_consent.style');
		$wa->useScript('plg_system_jet_cookie_consent.script');
	}

	public function processPage(AfterRenderEvent $event): void
	{
		$app = $this->getApplication();

		if (!$app->isClient('site') || $app->getInput()->getCmd('format', 'html') !== 'html') {
			return;
		}

		$body = $app->getBody();

		if ($body === '' || stripos($body, '</body>') === false) {
			return;
		}

		$rules = $this->getSourceRules();
		$detectedCategories = [];
		$body = $this->neutraliseScripts($body, $rules, $detectedCategories);
		[$managedScripts, $managedCategories] = $this->renderManagedScripts();
		$categories = $this->getEnabledCategories(array_merge($detectedCategories, $managedCategories));
		$options = $this->getOptions();
		$layout = new FileLayout('banner', dirname(__DIR__, 2) . '/layouts');
		$banner = $layout->render([
			'options' => $options,
			'categories' => $categories,
		]);

		if ($managedScripts !== '') {
			$body = preg_replace('/<\/head>/i', $managedScripts . "\n</head>", $body, 1) ?? $body;
		}

		$body = preg_replace('/<\/body>/i', $banner . "\n</body>", $body, 1) ?? $body;
		$app->setBody($body);
	}

	/** @return array<string, bool|int|string> */
	private function getOptions(): array
	{
		$cookieName = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $this->params->get('cookie_name', 'jet_cookie_consent'));
		$version = trim((string) $this->params->get('consent_version', '1'));

		return [
			'heading' => $this->textOrDefault('heading', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_HEADING'),
			'message' => $this->textOrDefault('message', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_MESSAGE'),
			'policyUrl' => trim((string) $this->params->get('policy_url', '')),
			'policyLabel' => $this->textOrDefault('policy_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_POLICY_LABEL'),
			'policyTarget' => (string) $this->params->get('policy_target', 'self') === 'blank' ? '_blank' : '_self',
			'acceptLabel' => $this->textOrDefault('accept_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_ACCEPT_LABEL'),
			'rejectLabel' => $this->textOrDefault('reject_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_REJECT_LABEL'),
			'customiseLabel' => $this->textOrDefault('customise_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_CUSTOMISE_LABEL'),
			'saveLabel' => $this->textOrDefault('save_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_SAVE_LABEL'),
			'reopenLabel' => $this->textOrDefault('reopen_label', 'PLG_SYSTEM_JET_COOKIE_CONSENT_DEFAULT_REOPEN_LABEL'),
			'showReopen' => (bool) $this->params->get('show_reopen', 1),
			'cookieName' => $cookieName !== '' ? $cookieName : 'jet_cookie_consent',
			'consentVersion' => substr($version !== '' ? $version : '1', 0, 64),
			'lifetimeDays' => max(1, min(730, (int) $this->params->get('lifetime_days', 180))),
			'delay' => max(0, min(10000, (int) $this->params->get('delay', 0))),
			'position' => (string) $this->params->get('position', 'bottom') === 'top' ? 'top' : 'bottom',
			'width' => (string) $this->params->get('width', 'container') === 'full' ? 'full' : 'container',
			'radius' => $this->normalise((string) $this->params->get('radius', 'normal'), ['none', 'normal', 'large'], 'normal'),
			'shadow' => (bool) $this->params->get('shadow', 1),
			'backgroundColor' => $this->colour('background_color'),
			'textColor' => $this->colour('text_color'),
			'borderColor' => $this->colour('border_color'),
		];
	}

	/** @param array<int, string> $detected @return array<int, string> */
	private function getEnabledCategories(array $detected): array
	{
		$enabled = [];

		foreach (self::CATEGORIES as $category) {
			if ((bool) $this->params->get('enable_' . $category, $category === 'statistics' ? 1 : 0)
				|| in_array($category, $detected, true)) {
				$enabled[] = $category;
			}
		}

		return $enabled;
	}

	/** @return array<int, array{pattern: string, category: string}> */
	private function getSourceRules(): array
	{
		$rules = [];

		foreach ($this->normaliseSubform($this->params->get('source_rules', [])) as $item) {
			$pattern = trim((string) ($item['pattern'] ?? ''));
			$category = (string) ($item['category'] ?? '');

			if ($pattern !== '' && in_array($category, self::CATEGORIES, true)) {
				$rules[] = ['pattern' => $pattern, 'category' => $category];
			}
		}

		return $rules;
	}

	/** @return array{0: string, 1: array<int, string>} */
	private function renderManagedScripts(): array
	{
		$html = [];
		$categories = [];

		foreach ($this->normaliseSubform($this->params->get('managed_scripts', [])) as $item) {
			$category = (string) ($item['category'] ?? '');
			$source = trim((string) ($item['source'] ?? ''));
			$code = trim((string) ($item['code'] ?? ''));

			if (!in_array($category, self::CATEGORIES, true) || ($source === '' && $code === '')) {
				continue;
			}

			$attributes = [
				'type="text/plain"',
				'data-jet-cookie-category="' . htmlspecialchars($category, ENT_QUOTES, 'UTF-8') . '"',
				'data-jet-cookie-type="' . ((string) ($item['type'] ?? 'classic') === 'module' ? 'module' : 'text/javascript') . '"',
			];

			if ($source !== '') {
				$attributes[] = 'data-jet-cookie-src="' . htmlspecialchars($source, ENT_QUOTES, 'UTF-8') . '"';
			}

			if ($code !== '') {
				$attributes[] = 'data-jet-cookie-code="' . base64_encode($code) . '"';
			}

			if (!empty($item['async'])) {
				$attributes[] = 'data-jet-cookie-async="true"';
			}

			$html[] = '<script ' . implode(' ', $attributes) . '></script>';
			$categories[] = $category;
		}

		return [implode("\n", $html), array_values(array_unique($categories))];
	}

	/**
	 * @param array<int, array{pattern: string, category: string}> $rules
	 * @param array<int, string> $detectedCategories
	 */
	private function neutraliseScripts(string $html, array $rules, array &$detectedCategories): string
	{
		return preg_replace_callback(
			'/<script\b([^>]*)>(.*?)<\/script>/is',
			function (array $matches) use ($rules, &$detectedCategories): string {
				$attributes = $matches[1];
				$source = $this->attribute($attributes, 'src') ?? '';

				if (str_contains($source, '/media/plg_system_jet_cookie_consent/')) {
					return $matches[0];
				}

				$category = strtolower($this->attribute($attributes, 'data-jet-cookie-category') ?? '');

				if ($category === '') {
					foreach ($rules as $rule) {
						if ($source !== '' && stripos($source, $rule['pattern']) !== false) {
							$category = $rule['category'];
							break;
						}
					}
				}

				if (!in_array($category, self::CATEGORIES, true)) {
					return $matches[0];
				}

				$originalType = $this->attribute($attributes, 'type') ?? 'text/javascript';
				$attributes = $this->withoutAttribute($attributes, 'type');
				$attributes = $this->withoutAttribute($attributes, 'src');
				$attributes = $this->withoutAttribute($attributes, 'data-jet-cookie-category');
				$attributes = $this->withoutAttribute($attributes, 'data-jet-cookie-src');
				$attributes = $this->withoutAttribute($attributes, 'data-jet-cookie-type');
				$attributes = trim($attributes);
				$blocked = $attributes !== '' ? ' ' . $attributes : '';
				$blocked .= ' type="text/plain" data-jet-cookie-category="' . $category . '"';
				$blocked .= ' data-jet-cookie-type="' . htmlspecialchars($originalType, ENT_QUOTES, 'UTF-8') . '"';

				if ($source !== '') {
					$blocked .= ' data-jet-cookie-src="' . htmlspecialchars($source, ENT_QUOTES, 'UTF-8') . '"';
				}

				$detectedCategories[] = $category;

				return '<script' . $blocked . '>' . $matches[2] . '</script>';
			},
			$html
		) ?? $html;
	}

	private function attribute(string $attributes, string $name): ?string
	{
		$quotedName = preg_quote($name, '/');

		if (!preg_match('/(?:^|\s)' . $quotedName . '\s*=\s*(?:"([^"]*)"|\'([^\']*)\'|([^\s"\'=<>`]+))/i', $attributes, $match)) {
			return null;
		}

		return html_entity_decode($match[1] ?? $match[2] ?? $match[3] ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8');
	}

	private function withoutAttribute(string $attributes, string $name): string
	{
		return preg_replace(
			'/(?:^|\s)' . preg_quote($name, '/') . '\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s"\'=<>`]+)/i',
			'',
			$attributes
		) ?? $attributes;
	}

	/** @return array<int, array<string, mixed>> */
	private function normaliseSubform(mixed $value): array
	{
		$result = [];

		foreach ((array) $value as $item) {
			if (is_object($item)) {
				$item = get_object_vars($item);
			}

			if (is_array($item)) {
				$result[] = $item;
			}
		}

		return $result;
	}

	private function textOrDefault(string $name, string $languageKey): string
	{
		$value = trim((string) $this->params->get($name, ''));

		return $value !== '' ? $value : Text::_($languageKey);
	}

	private function colour(string $name): string
	{
		$value = trim((string) $this->params->get($name, ''));

		return preg_match('/^#[0-9a-f]{6}$/i', $value) ? $value : '';
	}

	/** @param array<int, string> $allowed */
	private function normalise(string $value, array $allowed, string $default): string
	{
		return in_array($value, $allowed, true) ? $value : $default;
	}
}
