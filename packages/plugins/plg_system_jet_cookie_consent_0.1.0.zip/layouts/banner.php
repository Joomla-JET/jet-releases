<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/** @var array<string, bool|int|string> $options */
$options = $displayData['options'];

/** @var array<int, string> $categories */
$categories = $displayData['categories'];

$alertId = 'jet-cookie-consent';
$titleId = $alertId . '-title';
$descriptionId = $alertId . '-description';
$preferencesId = $alertId . '-preferences';
$classes = [
	'jet-cookie-consent',
	'jet-cookie-consent--' . $options['position'],
	'jet-cookie-consent--radius-' . $options['radius'],
];

if ($options['shadow']) {
	$classes[] = 'jet-cookie-consent--shadow';
}

$styles = [];

foreach (['backgroundColor' => '--jet-cookie-bg', 'textColor' => '--jet-cookie-color', 'borderColor' => '--jet-cookie-border-color'] as $option => $property) {
	if ($options[$option] !== '') {
		$styles[] = $property . ': ' . $options[$option];
	}
}

$categoryKeys = [
	'preferences' => ['PLG_SYSTEM_JET_COOKIE_CONSENT_CATEGORY_PREFERENCES', 'PLG_SYSTEM_JET_COOKIE_CONSENT_CATEGORY_PREFERENCES_DESC'],
	'statistics' => ['PLG_SYSTEM_JET_COOKIE_CONSENT_CATEGORY_STATISTICS', 'PLG_SYSTEM_JET_COOKIE_CONSENT_CATEGORY_STATISTICS_DESC'],
	'marketing' => ['PLG_SYSTEM_JET_COOKIE_CONSENT_CATEGORY_MARKETING', 'PLG_SYSTEM_JET_COOKIE_CONSENT_CATEGORY_MARKETING_DESC'],
];
$containerClass = $options['width'] === 'full' ? 'container-fluid' : 'container';
?>
<div
	id="<?= $alertId ?>"
	class="<?= implode(' ', $classes) ?>"
	data-jet-cookie-consent
	data-cookie-name="<?= htmlspecialchars($options['cookieName'], ENT_COMPAT, 'UTF-8') ?>"
	data-consent-version="<?= htmlspecialchars($options['consentVersion'], ENT_COMPAT, 'UTF-8') ?>"
	data-lifetime-days="<?= (int) $options['lifetimeDays'] ?>"
	data-delay="<?= (int) $options['delay'] ?>"
	data-categories="<?= htmlspecialchars(implode(',', $categories), ENT_COMPAT, 'UTF-8') ?>"
	data-show-reopen="<?= $options['showReopen'] ? 'true' : 'false' ?>"
	<?php if ($styles !== []) : ?>style="<?= htmlspecialchars(implode('; ', $styles), ENT_COMPAT, 'UTF-8') ?>"<?php endif; ?>
	hidden
>
	<div class="<?= $containerClass ?>">
		<section class="jet-cookie-consent__panel" role="region" aria-labelledby="<?= $titleId ?>" aria-describedby="<?= $descriptionId ?>">
			<div class="jet-cookie-consent__content">
				<h2 id="<?= $titleId ?>" class="h5 mb-2" tabindex="-1"><?= htmlspecialchars($options['heading'], ENT_COMPAT, 'UTF-8') ?></h2>
				<p id="<?= $descriptionId ?>" class="mb-0">
					<?= htmlspecialchars($options['message'], ENT_COMPAT, 'UTF-8') ?>
					<?php if ($options['policyUrl'] !== '') : ?>
						<a href="<?= htmlspecialchars($options['policyUrl'], ENT_COMPAT, 'UTF-8') ?>" target="<?= $options['policyTarget'] ?>"<?php if ($options['policyTarget'] === '_blank') : ?> rel="noopener noreferrer"<?php endif; ?>><?= htmlspecialchars($options['policyLabel'], ENT_COMPAT, 'UTF-8') ?></a>
					<?php endif; ?>
				</p>
			</div>

			<div class="jet-cookie-consent__actions">
				<button type="button" class="btn btn-outline-secondary" data-jet-cookie-reject><?= htmlspecialchars($options['rejectLabel'], ENT_COMPAT, 'UTF-8') ?></button>
				<?php if ($categories !== []) : ?>
					<button type="button" class="btn btn-outline-primary" data-jet-cookie-customise aria-expanded="false" aria-controls="<?= $preferencesId ?>"><?= htmlspecialchars($options['customiseLabel'], ENT_COMPAT, 'UTF-8') ?></button>
				<?php endif; ?>
				<button type="button" class="btn btn-primary" data-jet-cookie-accept><?= htmlspecialchars($options['acceptLabel'], ENT_COMPAT, 'UTF-8') ?></button>
			</div>

			<?php if ($categories !== []) : ?>
				<div id="<?= $preferencesId ?>" class="jet-cookie-consent__preferences" data-jet-cookie-preferences hidden>
					<div class="form-check form-switch">
						<input id="jet-cookie-category-necessary" class="form-check-input" type="checkbox" checked disabled>
						<label class="form-check-label" for="jet-cookie-category-necessary">
							<strong><?= Text::_('PLG_SYSTEM_JET_COOKIE_CONSENT_CATEGORY_NECESSARY') ?></strong>
							<span><?= Text::_('PLG_SYSTEM_JET_COOKIE_CONSENT_CATEGORY_NECESSARY_DESC') ?></span>
						</label>
					</div>

					<?php foreach ($categories as $category) : ?>
						<?php [$labelKey, $descriptionKey] = $categoryKeys[$category]; ?>
						<div class="form-check form-switch">
							<input id="jet-cookie-category-<?= $category ?>" class="form-check-input" type="checkbox" data-jet-cookie-category-input="<?= $category ?>">
							<label class="form-check-label" for="jet-cookie-category-<?= $category ?>">
								<strong><?= Text::_($labelKey) ?></strong>
								<span><?= Text::_($descriptionKey) ?></span>
							</label>
						</div>
					<?php endforeach; ?>

					<button type="button" class="btn btn-primary" data-jet-cookie-save><?= htmlspecialchars($options['saveLabel'], ENT_COMPAT, 'UTF-8') ?></button>
				</div>
			<?php endif; ?>
		</section>
	</div>
</div>

<?php if ($options['showReopen']) : ?>
	<button type="button" class="btn btn-secondary btn-sm jet-cookie-consent-reopen jet-cookie-consent-reopen--<?= $options['position'] ?>" data-jet-cookie-reopen hidden><?= htmlspecialchars($options['reopenLabel'], ENT_COMPAT, 'UTF-8') ?></button>
<?php endif; ?>
