<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Session\Session;

/** @var Joomla\Component\JetLanding\Administrator\View\Landings\HtmlView $this */

$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('table.columns')->useScript('multiselect');

$user      = $this->getCurrentUser();
$listOrder = $this->escape((string) $this->state->get('list.ordering'));
$listDirn  = $this->escape((string) $this->state->get('list.direction'));
$saveOrder = $listOrder === 'a.ordering';

if ($saveOrder) {
    $saveOrderingUrl = Route::_(
        'index.php?option=com_jet_landing&task=landings.saveOrderAjax&tmpl=component&' . Session::getFormToken() . '=1',
        false
    );
    HTMLHelper::_('draggablelist.draggable');
}
?>
<form action="<?php echo Route::_('index.php?option=com_jet_landing&view=landings'); ?>" method="post" name="adminForm" id="adminForm">
    <div id="j-main-container" class="j-main-container">
        <?php echo LayoutHelper::render('joomla.searchtools.default', ['view' => $this]); ?>

        <?php if (!$this->items) : ?>
            <div class="alert alert-info"><?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?></div>
        <?php else : ?>
            <table class="table" id="landingList">
                <caption class="visually-hidden"><?php echo Text::_('COM_JET_LANDING_LANDINGS_TABLE_CAPTION'); ?></caption>
                <thead>
                    <tr>
                        <td class="w-1 text-center"><?php echo HTMLHelper::_('grid.checkall'); ?></td>
                        <th scope="col" class="w-1 text-center"><?php echo HTMLHelper::_('searchtools.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?></th>
                        <th scope="col"><?php echo HTMLHelper::_('searchtools.sort', 'JGLOBAL_TITLE', 'a.title', $listDirn, $listOrder); ?></th>
                        <th scope="col" class="w-10 d-none d-md-table-cell"><?php echo Text::_('COM_JET_LANDING_HEADING_SECTIONS'); ?></th>
                        <th scope="col" class="w-10 d-none d-md-table-cell"><?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ACCESS', 'a.access', $listDirn, $listOrder); ?></th>
                        <th scope="col" class="w-10 d-none d-md-table-cell"><?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_LANGUAGE', 'a.language', $listDirn, $listOrder); ?></th>
                        <th scope="col" class="w-1 text-center"><?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ORDERING', 'a.ordering', $listDirn, $listOrder); ?></th>
                        <th scope="col" class="w-5 d-none d-md-table-cell"><?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?></th>
                    </tr>
                </thead>
                <tbody<?php if ($saveOrder) : ?> class="js-draggable" data-url="<?php echo $this->escape($saveOrderingUrl); ?>" data-direction="<?php echo strtolower($listDirn); ?>" data-nested="true"<?php endif; ?>>
                    <?php foreach ($this->items as $i => $item) :
                        $canEdit   = $user->authorise('core.edit', 'com_jet_landing');
                        $canChange = $user->authorise('core.edit.state', 'com_jet_landing');
                    ?>
                        <tr class="row<?php echo $i % 2; ?>">
                            <td class="text-center"><?php echo HTMLHelper::_('grid.id', $i, $item->id); ?></td>
                            <td class="text-center"><?php echo HTMLHelper::_('jgrid.published', $item->state, $i, 'landings.', $canChange); ?></td>
                            <th scope="row">
                                <?php if ($canEdit) : ?>
                                    <a href="<?php echo Route::_('index.php?option=com_jet_landing&task=landing.edit&id=' . (int) $item->id); ?>">
                                        <?php echo $this->escape($item->title); ?>
                                    </a>
                                <?php else : ?>
                                    <?php echo $this->escape($item->title); ?>
                                <?php endif; ?>
                                <div class="small text-muted"><?php echo $this->escape($item->alias); ?></div>
                            </th>
                            <td class="d-none d-md-table-cell">
                                <a href="<?php echo Route::_('index.php?option=com_jet_landing&view=sections&filter[landing_id]=' . (int) $item->id); ?>">
                                    <?php echo (int) $item->section_count; ?>
                                </a>
                            </td>
                            <td class="d-none d-md-table-cell"><?php echo $this->escape($item->access_level); ?></td>
                            <td class="d-none d-md-table-cell"><?php echo LayoutHelper::render('joomla.content.language', $item); ?></td>
                            <td class="order text-center">
                                <?php if ($saveOrder) : ?>
                                    <span class="sortable-handler<?php echo $canChange ? '' : ' inactive'; ?>" aria-hidden="true"><span class="icon-ellipsis-v"></span></span>
                                    <input type="text" name="order[]" class="width-20 text-area-order hidden" value="<?php echo (int) $item->ordering; ?>">
                                <?php else : ?>
                                    <?php echo (int) $item->ordering; ?>
                                <?php endif; ?>
                            </td>
                            <td class="d-none d-md-table-cell"><?php echo (int) $item->id; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php echo $this->pagination->getListFooter(); ?>
        <?php endif; ?>

        <?php echo $this->filterForm->renderControlFields(); ?>
        <?php echo HTMLHelper::_('form.token'); ?>
    </div>
</form>
