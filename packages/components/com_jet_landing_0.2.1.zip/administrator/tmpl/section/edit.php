<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var Joomla\Component\JetLanding\Administrator\View\Section\HtmlView $this */

$this->getDocument()->getWebAssetManager()->useScript('keepalive')->useScript('form.validate');
?>
<form action="<?php echo Route::_('index.php?option=com_jet_landing&layout=edit&id=' . (int) $this->item->id); ?>" method="post" name="adminForm" id="section-form" class="form-validate">
    <?php echo HTMLHelper::_('uitab.startTabSet', 'sectionTabs', ['active' => 'details', 'recall' => true, 'breakpoint' => 768]); ?>
        <?php echo HTMLHelper::_('uitab.addTab', 'sectionTabs', 'details', Text::_('COM_JET_LANDING_TAB_CONTENT')); ?>
            <div class="main-card p-4">
                <?php echo $this->form->renderFieldset('details'); ?>
            </div>
        <?php echo HTMLHelper::_('uitab.endTab'); ?>

        <?php echo HTMLHelper::_('uitab.addTab', 'sectionTabs', 'media', Text::_('COM_JET_LANDING_FIELDSET_MEDIA_LABEL')); ?>
            <div class="main-card p-4">
                <?php echo $this->form->renderFieldset('media'); ?>
            </div>
        <?php echo HTMLHelper::_('uitab.endTab'); ?>

        <?php echo HTMLHelper::_('uitab.addTab', 'sectionTabs', 'display', Text::_('COM_JET_LANDING_CONFIG_DISPLAY_LABEL')); ?>
            <div class="main-card p-4">
                <?php echo $this->form->renderFieldset('display'); ?>
                <?php echo $this->form->renderFieldset('section_options'); ?>
            </div>
        <?php echo HTMLHelper::_('uitab.endTab'); ?>

        <?php echo HTMLHelper::_('uitab.addTab', 'sectionTabs', 'publishing', Text::_('JGLOBAL_FIELDSET_PUBLISHING')); ?>
            <div class="main-card p-4">
                <?php echo $this->form->renderFieldset('publishing'); ?>
            </div>
        <?php echo HTMLHelper::_('uitab.endTab'); ?>
    <?php echo HTMLHelper::_('uitab.endTabSet'); ?>

    <?php echo $this->form->renderControlFields(); ?>
</form>
