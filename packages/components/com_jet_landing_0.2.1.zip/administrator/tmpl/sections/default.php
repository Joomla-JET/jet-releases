<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Router\Route;

/** @var Joomla\Component\JetLanding\Administrator\View\Sections\HtmlView $this */

$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('table.columns')->useScript('multiselect');

$user      = $this->getCurrentUser();
$listOrder = $this->escape((string) $this->state->get('list.ordering'));
$listDirn  = $this->escape((string) $this->state->get('list.direction'));
?>
<form action="<?php echo Route::_('index.php?option=com_jet_landing&view=sections'); ?>" method="post" name="adminForm" id="adminForm">
    <div id="j-main-container" class="j-main-container">
        <?php echo LayoutHelper::render('joomla.searchtools.default', ['view' => $this]); ?>

        <?php if (!$this->items) : ?>
            <div class="alert alert-info"><?php echo Text::_('JGLOBAL_NO_MATCHING_RESULTS'); ?></div>
        <?php else : ?>
            <table class="table" id="sectionList">
                <caption class="visually-hidden"><?php echo Text::_('COM_JET_LANDING_SECTIONS_TABLE_CAPTION'); ?></caption>
                <thead>
                    <tr>
                        <td class="w-1 text-center"><?php echo HTMLHelper::_('grid.checkall'); ?></td>
                        <th scope="col" class="w-1 text-center"><?php echo HTMLHelper::_('searchtools.sort', 'JSTATUS', 'a.state', $listDirn, $listOrder); ?></th>
                        <th scope="col"><?php echo HTMLHelper::_('searchtools.sort', 'JGLOBAL_TITLE', 'a.title', $listDirn, $listOrder); ?></th>
                        <th scope="col" class="w-20 d-none d-md-table-cell"><?php echo HTMLHelper::_('searchtools.sort', 'COM_JET_LANDING_HEADING_LANDING', 'a.landing_id', $listDirn, $listOrder); ?></th>
                        <th scope="col" class="w-15 d-none d-lg-table-cell"><?php echo HTMLHelper::_('searchtools.sort', 'COM_JET_LANDING_HEADING_SOURCE', 'a.source_type', $listDirn, $listOrder); ?></th>
                        <th scope="col" class="w-10 d-none d-md-table-cell"><?php echo Text::_('COM_JET_LANDING_HEADING_LAYOUT'); ?></th>
                        <th scope="col" class="w-5 text-center"><?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ORDERING', 'a.ordering', $listDirn, $listOrder); ?></th>
                        <th scope="col" class="w-5 d-none d-md-table-cell"><?php echo HTMLHelper::_('searchtools.sort', 'JGRID_HEADING_ID', 'a.id', $listDirn, $listOrder); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($this->items as $i => $item) :
                        $canEdit   = $user->authorise('core.edit', 'com_jet_landing');
                        $canChange = $user->authorise('core.edit.state', 'com_jet_landing');
                    ?>
                        <tr class="row<?php echo $i % 2; ?>">
                            <td class="text-center"><?php echo HTMLHelper::_('grid.id', $i, $item->id); ?></td>
                            <td class="text-center"><?php echo HTMLHelper::_('jgrid.published', $item->state, $i, 'sections.', $canChange); ?></td>
                            <th scope="row">
                                <?php if ($canEdit) : ?>
                                    <a href="<?php echo Route::_('index.php?option=com_jet_landing&task=section.edit&id=' . (int) $item->id); ?>">
                                        <?php echo $this->escape($item->title); ?>
                                    </a>
                                <?php else : ?>
                                    <?php echo $this->escape($item->title); ?>
                                <?php endif; ?>
                                <div class="small text-muted">#<?php echo $this->escape($item->alias); ?></div>
                            </th>
                            <td class="d-none d-md-table-cell"><?php echo $this->escape($item->landing_title); ?></td>
                            <td class="d-none d-lg-table-cell">
                                <?php echo Text::_('COM_JET_LANDING_SOURCE_' . strtoupper($item->source_type)); ?>
                                <?php if ($item->source_type === 'article') : ?>
                                    <div class="small text-muted"><?php echo $this->escape($item->article_title ?: Text::_('COM_JET_LANDING_ARTICLE_MISSING')); ?></div>
                                    <div class="small text-muted"><?php echo Text::_('COM_JET_LANDING_SEO_MODE_' . strtoupper($item->seo_mode)); ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="d-none d-md-table-cell"><?php echo Text::_('COM_JET_LANDING_LAYOUT_' . strtoupper(str_replace('-', '_', $item->layout))); ?></td>
                            <td class="text-center">
                                <input type="number" name="order[]" class="form-control form-control-sm text-center" value="<?php echo (int) $item->ordering; ?>"<?php echo $canChange ? '' : ' disabled'; ?>>
                            </td>
                            <td class="d-none d-md-table-cell"><?php echo (int) $item->id; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php echo $this->pagination->getListFooter(); ?>
        <?php endif; ?>

        <?php echo $this->filterForm->renderControlFields(); ?>
        <?php echo HTMLHelper::_('form.token'); ?>
    </div>
</form>
