DROP TABLE IF EXISTS `#__jet_landing_sections`;
DROP TABLE IF EXISTS `#__jet_landings`;
