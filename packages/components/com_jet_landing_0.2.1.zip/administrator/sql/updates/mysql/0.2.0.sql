ALTER TABLE `#__jet_landing_sections`
  ADD COLUMN `source_type` varchar(32) NOT NULL DEFAULT 'custom' AFTER `alias`,
  ADD COLUMN `source_id` int unsigned DEFAULT NULL AFTER `source_type`,
  ADD COLUMN `seo_mode` varchar(32) NOT NULL DEFAULT 'independent' AFTER `source_id`,
  ADD KEY `idx_jet_section_source` (`source_type`, `source_id`);
