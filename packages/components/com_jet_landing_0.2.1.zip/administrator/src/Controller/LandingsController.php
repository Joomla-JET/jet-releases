<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

final class LandingsController extends AdminController
{
    protected $option = 'com_jet_landing';

    public function getModel($name = 'Landing', $prefix = 'Administrator', $config = ['ignore_request' => true]): BaseDatabaseModel
    {
        return parent::getModel($name, $prefix, $config);
    }
}
