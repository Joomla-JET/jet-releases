<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;

final class LandingModel extends AdminModel
{
    public $typeAlias = 'com_jet_landing.landing';

    protected $text_prefix = 'COM_JET_LANDING';

    public function getTable($name = 'Landing', $prefix = 'Administrator', $options = []): Table
    {
        return parent::getTable($name, $prefix, $options);
    }

    public function getForm($data = [], $loadData = true): Form|false
    {
        $form = $this->loadForm(
            'com_jet_landing.landing',
            'landing',
            ['control' => 'jform', 'load_data' => $loadData]
        );

        if (!$form) {
            return false;
        }

        if (!$this->getCurrentUser()->authorise('core.edit.state', 'com_jet_landing')) {
            foreach (['state', 'ordering', 'publish_up', 'publish_down'] as $field) {
                $form->setFieldAttribute($field, 'disabled', 'true');
                $form->setFieldAttribute($field, 'filter', 'unset');
            }
        }

        return $form;
    }

    protected function loadFormData(): object|array
    {
        $data = Factory::getApplication()->getUserState('com_jet_landing.edit.landing.data', []);

        if (empty($data)) {
            $data = $this->getItem();
        }

        $this->preprocessData('com_jet_landing.landing', $data);

        return $data;
    }

    protected function prepareTable($table): void
    {
        if (!(int) $table->id) {
            $table->ordering = $table->getNextOrder();
        }
    }

    protected function canDelete($record): bool
    {
        return !empty($record->id)
            && (int) $record->state === -2
            && $this->getCurrentUser()->authorise('core.delete', 'com_jet_landing');
    }
}
