<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

final class LandingsModel extends ListModel
{
    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        $config['filter_fields'] ??= [
            'id', 'a.id', 'title', 'a.title', 'alias', 'a.alias',
            'state', 'a.state', 'access', 'a.access', 'language', 'a.language',
            'ordering', 'a.ordering', 'created', 'a.created',
        ];

        parent::__construct($config, $factory);
    }

    protected function populateState($ordering = 'a.ordering', $direction = 'ASC'): void
    {
        parent::populateState($ordering, $direction);
    }

    protected function getListQuery(): QueryInterface
    {
        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select('a.*')
            ->select('ag.title AS access_level')
            ->select('(SELECT COUNT(*) FROM ' . $db->quoteName('#__jet_landing_sections', 'sc')
                . ' WHERE ' . $db->quoteName('sc.landing_id') . ' = ' . $db->quoteName('a.id') . ') AS section_count')
            ->from($db->quoteName('#__jet_landings', 'a'))
            ->join('LEFT', $db->quoteName('#__viewlevels', 'ag'), $db->quoteName('ag.id') . ' = ' . $db->quoteName('a.access'));

        $state = $this->getState('filter.state');

        if (is_numeric($state)) {
            $state = (int) $state;
            $query->where($db->quoteName('a.state') . ' = :state')->bind(':state', $state, ParameterType::INTEGER);
        } elseif ($state === '') {
            $query->whereIn($db->quoteName('a.state'), [0, 1]);
        }

        $access = (int) $this->getState('filter.access');

        if ($access > 0) {
            $query->where($db->quoteName('a.access') . ' = :access')->bind(':access', $access, ParameterType::INTEGER);
        }

        $language = (string) $this->getState('filter.language');

        if ($language !== '') {
            $query->where($db->quoteName('a.language') . ' = :language')->bind(':language', $language);
        }

        $search = trim((string) $this->getState('filter.search'));

        if ($search !== '') {
            if (str_starts_with($search, 'id:')) {
                $id = (int) substr($search, 3);
                $query->where($db->quoteName('a.id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
            } else {
                $search = '%' . $db->escape($search, true) . '%';
                $query->where('(' . $db->quoteName('a.title') . ' LIKE :searchTitle OR ' . $db->quoteName('a.alias') . ' LIKE :searchAlias)')
                    ->bind(':searchTitle', $search)
                    ->bind(':searchAlias', $search);
            }
        }

        $query->order(
            $db->escape((string) $this->getState('list.ordering', 'a.ordering'))
            . ' ' . $db->escape((string) $this->getState('list.direction', 'ASC'))
        );

        return $query;
    }
}
