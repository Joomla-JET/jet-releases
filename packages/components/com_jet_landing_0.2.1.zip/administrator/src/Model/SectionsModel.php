<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Factory\MVCFactoryInterface;
use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Database\ParameterType;
use Joomla\Database\QueryInterface;

final class SectionsModel extends ListModel
{
    public function __construct($config = [], ?MVCFactoryInterface $factory = null)
    {
        $config['filter_fields'] ??= [
            'id', 'a.id', 'title', 'a.title', 'alias', 'a.alias',
            'state', 'a.state', 'landing_id', 'a.landing_id',
            'source_type', 'a.source_type', 'seo_mode', 'a.seo_mode',
            'ordering', 'a.ordering', 'created', 'a.created',
        ];

        parent::__construct($config, $factory);
    }

    protected function populateState($ordering = 'a.landing_id, a.ordering', $direction = 'ASC'): void
    {
        parent::populateState($ordering, $direction);
    }

    protected function getListQuery(): QueryInterface
    {
        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select('a.*')
            ->select('l.title AS landing_title, l.alias AS landing_alias')
            ->select('content.title AS article_title')
            ->from($db->quoteName('#__jet_landing_sections', 'a'))
            ->join('INNER', $db->quoteName('#__jet_landings', 'l'), $db->quoteName('l.id') . ' = ' . $db->quoteName('a.landing_id'))
            ->join('LEFT', $db->quoteName('#__content', 'content'), $db->quoteName('content.id') . ' = ' . $db->quoteName('a.source_id'));

        $state = $this->getState('filter.state');

        if (is_numeric($state)) {
            $state = (int) $state;
            $query->where($db->quoteName('a.state') . ' = :state')->bind(':state', $state, ParameterType::INTEGER);
        } elseif ($state === '') {
            $query->whereIn($db->quoteName('a.state'), [0, 1]);
        }

        $landingId = (int) $this->getState('filter.landing_id');

        if ($landingId > 0) {
            $query->where($db->quoteName('a.landing_id') . ' = :landingId')->bind(':landingId', $landingId, ParameterType::INTEGER);
        }

        $sourceType = (string) $this->getState('filter.source_type');

        if (in_array($sourceType, ['custom', 'article'], true)) {
            $query->where($db->quoteName('a.source_type') . ' = :sourceType')
                ->bind(':sourceType', $sourceType);
        }

        $search = trim((string) $this->getState('filter.search'));

        if ($search !== '') {
            if (str_starts_with($search, 'id:')) {
                $id = (int) substr($search, 3);
                $query->where($db->quoteName('a.id') . ' = :id')->bind(':id', $id, ParameterType::INTEGER);
            } else {
                $search = '%' . $db->escape($search, true) . '%';
                $query->where('(' . $db->quoteName('a.title') . ' LIKE :searchTitle OR ' . $db->quoteName('a.alias') . ' LIKE :searchAlias OR ' . $db->quoteName('content.title') . ' LIKE :searchArticle)')
                    ->bind(':searchTitle', $search)
                    ->bind(':searchAlias', $search)
                    ->bind(':searchArticle', $search);
            }
        }

        $query->order(
            $db->escape((string) $this->getState('list.ordering', 'a.landing_id, a.ordering'))
            . ' ' . $db->escape((string) $this->getState('list.direction', 'ASC'))
        );

        return $query;
    }
}
