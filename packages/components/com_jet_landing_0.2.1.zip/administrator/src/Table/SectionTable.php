<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Table;

defined('_JEXEC') or die;

use Joomla\CMS\Application\ApplicationHelper;
use Joomla\CMS\Date\Date;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Table\Table;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\CurrentUserTrait;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\Event\DispatcherInterface;

final class SectionTable extends Table implements CurrentUserInterface
{
    use CurrentUserTrait;

    protected $_jsonEncode = ['params'];

    protected $_supportNullValue = true;

    public function __construct(DatabaseInterface $db, ?DispatcherInterface $dispatcher = null)
    {
        $this->typeAlias = 'com_jet_landing.section';

        parent::__construct('#__jet_landing_sections', 'id', $db, $dispatcher);

        $this->setColumnAlias('published', 'state');
    }

    public function check(): bool
    {
        if (!parent::check()) {
            return false;
        }

        $this->landing_id = (int) $this->landing_id;
        $this->source_type = in_array((string) $this->source_type, ['custom', 'article'], true)
            ? (string) $this->source_type
            : 'custom';
        $this->seo_mode = in_array((string) $this->seo_mode, ['independent', 'consolidated', 'duplicate'], true)
            ? (string) $this->seo_mode
            : 'independent';
        $this->source_id = $this->source_type === 'article' ? (int) $this->source_id : null;
        $this->title     = trim((string) $this->title);

        if ($this->landing_id < 1) {
            $this->setError(Text::_('COM_JET_LANDING_ERROR_LANDING_REQUIRED'));

            return false;
        }

        if ($this->source_type === 'article') {
            if ((int) $this->source_id < 1) {
                $this->setError(Text::_('COM_JET_LANDING_ERROR_ARTICLE_REQUIRED'));

                return false;
            }

            $articleTitle = $this->getDatabase()->setQuery(
                $this->getDatabase()->createQuery()
                    ->select($this->getDatabase()->quoteName('title'))
                    ->from($this->getDatabase()->quoteName('#__content'))
                    ->where($this->getDatabase()->quoteName('id') . ' = :articleId')
                    ->bind(':articleId', $this->source_id, ParameterType::INTEGER)
            )->loadResult();

            if (!$articleTitle) {
                $this->setError(Text::_('COM_JET_LANDING_ERROR_ARTICLE_NOT_FOUND'));

                return false;
            }

            $this->title = $this->title ?: trim((string) $articleTitle);

            if ($this->seo_mode === 'consolidated' && $this->hasOtherConsolidatedSection()) {
                $this->setError(Text::_('COM_JET_LANDING_ERROR_ARTICLE_ALREADY_CONSOLIDATED'));

                return false;
            }
        }

        if ($this->title === '') {
            $this->setError(Text::_('COM_JET_LANDING_ERROR_TITLE_REQUIRED'));

            return false;
        }

        $this->alias = ApplicationHelper::stringURLSafe(trim((string) $this->alias) ?: $this->title);

        if ($this->alias === '') {
            $this->alias = ApplicationHelper::stringURLSafe((string) microtime(true));
        }

        $this->publish_up   = $this->publish_up ?: null;
        $this->publish_down = $this->publish_down ?: null;

        if ($this->publish_up !== null && $this->publish_down !== null && $this->publish_down < $this->publish_up) {
            $this->setError(Text::_('JGLOBAL_START_PUBLISH_AFTER_FINISH'));

            return false;
        }

        $duplicate = new self($this->getDatabase(), $this->getDispatcher());

        if (
            $duplicate->load(['landing_id' => $this->landing_id, 'alias' => $this->alias])
            && (int) $duplicate->id !== (int) $this->id
        ) {
            $this->setError(Text::_('COM_JET_LANDING_ERROR_UNIQUE_SECTION_ALIAS'));

            return false;
        }

        return true;
    }

    private function hasOtherConsolidatedSection(): bool
    {
        $db    = $this->getDatabase();
        $query = $db->createQuery()
            ->select('COUNT(*)')
            ->from($db->quoteName('#__jet_landing_sections'))
            ->where($db->quoteName('source_type') . ' = ' . $db->quote('article'))
            ->where($db->quoteName('source_id') . ' = :articleId')
            ->where($db->quoteName('seo_mode') . ' = ' . $db->quote('consolidated'))
            ->where($db->quoteName('state') . ' <> -2')
            ->bind(':articleId', $this->source_id, ParameterType::INTEGER);

        if ((int) $this->id > 0) {
            $query->where($db->quoteName('id') . ' <> :sectionId')
                ->bind(':sectionId', $this->id, ParameterType::INTEGER);
        }

        return (int) $db->setQuery($query)->loadResult() > 0;
    }

    public function store($updateNulls = true): bool
    {
        $date   = (new Date('now', 'UTC'))->toSql();
        $userId = (int) $this->getCurrentUser()->id;

        if (!(int) $this->id) {
            $this->created    = $this->created ?: $date;
            $this->created_by = $this->created_by ?: $userId;
        }

        $this->modified    = $date;
        $this->modified_by = $userId;
        $this->version     = max(1, (int) $this->version + ((int) $this->id > 0 ? 1 : 0));

        return parent::store($updateNulls);
    }
}
