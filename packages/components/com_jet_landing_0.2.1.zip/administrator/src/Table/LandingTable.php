<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Table;

defined('_JEXEC') or die;

use Joomla\CMS\Application\ApplicationHelper;
use Joomla\CMS\Date\Date;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Table\Table;
use Joomla\CMS\User\CurrentUserInterface;
use Joomla\CMS\User\CurrentUserTrait;
use Joomla\Database\DatabaseInterface;
use Joomla\Event\DispatcherInterface;

final class LandingTable extends Table implements CurrentUserInterface
{
    use CurrentUserTrait;

    protected $_jsonEncode = ['params', 'metadata'];

    protected $_supportNullValue = true;

    public function __construct(DatabaseInterface $db, ?DispatcherInterface $dispatcher = null)
    {
        $this->typeAlias = 'com_jet_landing.landing';

        parent::__construct('#__jet_landings', 'id', $db, $dispatcher);

        $this->setColumnAlias('published', 'state');
    }

    public function check(): bool
    {
        if (!parent::check()) {
            return false;
        }

        $this->title = trim((string) $this->title);

        if ($this->title === '') {
            $this->setError(Text::_('COM_JET_LANDING_ERROR_TITLE_REQUIRED'));

            return false;
        }

        $this->alias = ApplicationHelper::stringURLSafe(trim((string) $this->alias) ?: $this->title);

        if ($this->alias === '') {
            $this->alias = ApplicationHelper::stringURLSafe((string) microtime(true));
        }

        $this->publish_up   = $this->publish_up ?: null;
        $this->publish_down = $this->publish_down ?: null;

        if ($this->publish_up !== null && $this->publish_down !== null && $this->publish_down < $this->publish_up) {
            $this->setError(Text::_('JGLOBAL_START_PUBLISH_AFTER_FINISH'));

            return false;
        }

        $duplicate = new self($this->getDatabase(), $this->getDispatcher());

        if (
            $duplicate->load(['alias' => $this->alias, 'language' => $this->language])
            && (int) $duplicate->id !== (int) $this->id
        ) {
            $this->setError(Text::_('COM_JET_LANDING_ERROR_UNIQUE_ALIAS'));

            return false;
        }

        return true;
    }

    public function store($updateNulls = true): bool
    {
        $date   = (new Date('now', 'UTC'))->toSql();
        $userId = (int) $this->getCurrentUser()->id;

        if (!(int) $this->id) {
            $this->created    = $this->created ?: $date;
            $this->created_by = $this->created_by ?: $userId;
        }

        $this->modified    = $date;
        $this->modified_by = $userId;
        $this->version     = max(1, (int) $this->version + ((int) $this->id > 0 ? 1 : 0));

        return parent::store($updateNulls);
    }
}
