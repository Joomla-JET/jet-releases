<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\View\Landings;

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

final class HtmlView extends BaseHtmlView
{
    public array $items = [];

    public $pagination;

    public $state;

    public $filterForm;

    public array $activeFilters = [];

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $model->setUseExceptions(true);

        $this->items         = $model->getItems();
        $this->pagination    = $model->getPagination();
        $this->state         = $model->getState();
        $this->filterForm    = $model->getFilterForm();
        $this->activeFilters = $model->getActiveFilters();

        $this->filterForm
            ->addControlField('task')
            ->addControlField('boxchecked', '0');

        if ($errors = $model->getErrors()) {
            throw new GenericDataException(implode("\n", $errors), 500);
        }

        $this->addToolbar();
        parent::display($tpl);
    }

    private function addToolbar(): void
    {
        $canDo   = ContentHelper::getActions('com_jet_landing');
        $toolbar = $this->getDocument()->getToolbar();

        ToolbarHelper::title(Text::_('COM_JET_LANDING_MANAGER_LANDINGS'), 'copy');

        if ($canDo->get('core.create')) {
            $toolbar->addNew('landing.add');
        }

        if ($canDo->get('core.edit.state')) {
            $dropdown = $toolbar->dropdownButton('status-group', 'JTOOLBAR_CHANGE_STATUS')
                ->toggleSplit(false)
                ->icon('icon-ellipsis-h')
                ->buttonClass('btn btn-action')
                ->listCheck(true);
            $child = $dropdown->getChildToolbar();
            $child->publish('landings.publish')->listCheck(true);
            $child->unpublish('landings.unpublish')->listCheck(true);
            $child->archive('landings.archive')->listCheck(true);
            $child->trash('landings.trash')->listCheck(true);
        }

        if ((int) $this->state->get('filter.state') === -2 && $canDo->get('core.delete')) {
            $toolbar->delete('landings.delete')->message('JGLOBAL_CONFIRM_DELETE')->listCheck(true);
        }

        if ($canDo->get('core.admin') || $canDo->get('core.options')) {
            $toolbar->preferences('com_jet_landing');
        }
    }
}
