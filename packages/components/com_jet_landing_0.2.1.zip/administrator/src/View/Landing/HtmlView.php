<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\View\Landing;

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\GenericDataException;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;

final class HtmlView extends BaseHtmlView
{
    public $form;

    public $item;

    public $state;

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $model->setUseExceptions(true);

        $this->form  = $model->getForm();
        $this->item  = $model->getItem();
        $this->state = $model->getState();

        if ($errors = $model->getErrors()) {
            throw new GenericDataException(implode("\n", $errors), 500);
        }

        $this->form->addControlField('task');

        $this->addToolbar();
        parent::display($tpl);
    }

    private function addToolbar(): void
    {
        $isNew   = !(int) $this->item->id;
        $canDo   = ContentHelper::getActions('com_jet_landing');
        $toolbar = $this->getDocument()->getToolbar();

        ToolbarHelper::title(
            $isNew ? Text::_('COM_JET_LANDING_MANAGER_LANDING_NEW') : Text::_('COM_JET_LANDING_MANAGER_LANDING_EDIT'),
            'copy'
        );

        if (($isNew && $canDo->get('core.create')) || (!$isNew && $canDo->get('core.edit'))) {
            $toolbar->apply('landing.apply');
            $toolbar->save('landing.save');
        }

        if ($canDo->get('core.create')) {
            $toolbar->save2new('landing.save2new');
        }

        $toolbar->cancel('landing.cancel', $isNew ? 'JTOOLBAR_CANCEL' : 'JTOOLBAR_CLOSE');
    }
}
