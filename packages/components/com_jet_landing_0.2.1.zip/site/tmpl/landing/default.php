<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

/** @var Joomla\Component\JetLanding\Site\View\Landing\HtmlView $this */

$pageClass = trim('jet-landing ' . (string) $this->params->get('page_class'));
$container = (bool) $this->params->get('container', 0) ? ' container' : '';
$navigationPosition = (string) $this->params->get('navigation_position', 'top');

if (!in_array($navigationPosition, ['none', 'top', 'left', 'right'], true) || !$this->sections) {
    $navigationPosition = 'none';
}

$hasSidebar = in_array($navigationPosition, ['left', 'right'], true);
$navigationOffset = min(500, max(0, (int) $this->params->get('navigation_offset', 16)));
$renderSections = function (): void {
    foreach ($this->sections as $section) {
        $this->section = $section;
        echo $this->loadTemplate('section');
    }
};
?>
<main
    class="<?php echo $this->escape($pageClass); ?>"
    data-jet-landing="<?php echo (int) $this->item->id; ?>"
    data-navigation-position="<?php echo $this->escape($navigationPosition); ?>"
    style="--jet-landing-navigation-offset: <?php echo $navigationOffset; ?>px"
>
    <?php if ((bool) $this->params->get('show_title', 1)) : ?>
        <header class="<?php echo trim($container); ?> py-4">
            <h1><?php echo $this->escape($this->item->title); ?></h1>
            <?php if (trim((string) $this->item->description) !== '') : ?>
                <div class="lead">
                    <?php echo (bool) $this->params->get('prepare_content', 1)
                        ? HTMLHelper::_('content.prepare', $this->item->description, '', 'com_jet_landing.landing')
                        : $this->item->description; ?>
                </div>
            <?php endif; ?>
        </header>
    <?php endif; ?>

    <?php if ($navigationPosition === 'top') : ?>
        <?php echo $this->loadTemplate('navigation'); ?>
        <?php $renderSections(); ?>
    <?php elseif ($hasSidebar) : ?>
        <div class="container">
            <div class="row g-lg-5 align-items-start">
                <aside class="col-lg-3 align-self-stretch<?php echo $navigationPosition === 'right' ? ' order-lg-2' : ''; ?> py-3 py-lg-5">
                    <?php echo $this->loadTemplate('navigation'); ?>
                </aside>
                <div class="col-lg-9<?php echo $navigationPosition === 'right' ? ' order-lg-1' : ''; ?>">
                    <?php $renderSections(); ?>
                </div>
            </div>
        </div>
    <?php else : ?>
        <?php $renderSections(); ?>
    <?php endif; ?>
</main>
