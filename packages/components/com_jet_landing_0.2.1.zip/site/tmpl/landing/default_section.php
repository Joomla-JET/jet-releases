<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

$section = $this->section;
$layout  = in_array($section->layout, ['default', 'hero', 'image-left', 'image-right', 'centered', 'call-to-action'], true)
    ? $section->layout
    : 'default';
$params      = $section->params;
$background  = (string) $params->get('background', 'none');
$customClass = trim((string) $params->get('section_class'));
$classes     = ['jet-landing__section', 'jet-landing__section--' . $layout, 'py-5'];

if ($background !== 'none') {
    $classes[] = 'bg-' . $background;

    if (in_array($background, ['primary', 'dark'], true)) {
        $classes[] = 'text-white';
    }
}

if ($layout === 'hero') {
    $classes[] = 'text-center';
}

if (in_array($layout, ['centered', 'call-to-action'], true)) {
    $classes[] = 'text-center';
}

if ($customClass !== '') {
    $classes[] = $customClass;
}

$image = $section->image !== '' ? HTMLHelper::cleanImageURL($section->image) : null;
$content = !empty($section->content_prepared) || !(bool) $this->params->get('prepare_content', 1)
    ? $section->content
    : HTMLHelper::_('content.prepare', $section->content, '', 'com_jet_landing.section');
$showReadmore = $section->source_type === 'article'
    && $section->seo_mode === 'independent'
    && (bool) $params->get('show_readmore', 1)
    && trim((string) $section->article_url) !== '';
$readmoreText = trim((string) $params->get('readmore_text')) ?: Text::_('COM_JET_LANDING_READMORE');
$hasColumns = $image && in_array($layout, ['image-left', 'image-right'], true);
$hasSidebar = in_array($this->params->get('navigation_position'), ['left', 'right'], true);
?>
<section id="<?php echo $this->escape($section->alias); ?>" class="<?php echo $this->escape(implode(' ', $classes)); ?>" data-jet-landing-section>
    <div class="<?php echo $hasSidebar ? 'container-fluid' : 'container'; ?>">
        <?php if ($hasColumns) : ?>
            <div class="row align-items-center g-4 g-lg-5">
                <div class="col-lg-6<?php echo $layout === 'image-right' ? ' order-lg-2' : ''; ?>">
                    <img src="<?php echo $this->escape($image->url); ?>" alt="<?php echo $this->escape($section->image_alt); ?>" class="img-fluid rounded" loading="lazy">
                </div>
                <div class="col-lg-6<?php echo $layout === 'image-right' ? ' order-lg-1' : ''; ?>">
                    <?php if ((bool) $params->get('show_title', 1)) : ?><h2><?php echo $this->escape($section->title); ?></h2><?php endif; ?>
                    <div class="jet-landing__content"><?php echo $content; ?></div>
                    <?php if ($showReadmore) : ?>
                        <a class="btn btn-primary mt-3" href="<?php echo Route::_($section->article_url); ?>"><?php echo $this->escape($readmoreText); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        <?php else : ?>
            <div class="<?php echo in_array($layout, ['hero', 'centered', 'call-to-action'], true) ? 'mx-auto col-lg-9 col-xl-8' : ''; ?>">
                <?php if ($image) : ?>
                    <img src="<?php echo $this->escape($image->url); ?>" alt="<?php echo $this->escape($section->image_alt); ?>" class="img-fluid rounded mb-4" loading="lazy">
                <?php endif; ?>
                <?php if ((bool) $params->get('show_title', 1)) : ?><h2><?php echo $this->escape($section->title); ?></h2><?php endif; ?>
                <div class="jet-landing__content<?php echo $layout === 'hero' ? ' lead' : ''; ?>"><?php echo $content; ?></div>
                <?php if ($showReadmore) : ?>
                    <a class="btn btn-primary mt-3" href="<?php echo Route::_($section->article_url); ?>"><?php echo $this->escape($readmoreText); ?></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
