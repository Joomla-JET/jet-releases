<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

$position = in_array($this->params->get('navigation_position'), ['top', 'left', 'right'], true)
    ? (string) $this->params->get('navigation_position')
    : 'top';
$style = in_array($this->params->get('navigation_style'), ['pills', 'underline', 'plain'], true)
    ? (string) $this->params->get('navigation_style')
    : 'pills';
$isSidebar = in_array($position, ['left', 'right'], true);
$isSticky  = (bool) $this->params->get('navigation_sticky', 1);
$offset    = min(500, max(0, (int) $this->params->get('navigation_offset', 16)));
$collapseId = 'jet-landing-navigation-' . (int) $this->item->id;
$navClasses = ['nav'];
$navigationStyles = ['--jet-landing-navigation-offset: ' . $offset . 'px'];
$colourProperties = [
    'navigation_background_color'  => '--jet-landing-navigation-background',
    'navigation_text_color'        => '--jet-landing-navigation-text',
    'navigation_border_color'      => '--jet-landing-navigation-border',
    'navigation_accent_color'      => '--jet-landing-navigation-accent',
    'navigation_accent_text_color' => '--jet-landing-navigation-accent-text',
];

foreach ($colourProperties as $parameter => $property) {
    $colour = trim((string) $this->params->get($parameter, ''));

    if (preg_match('/^#[0-9a-f]{6}$/i', $colour)) {
        $navigationStyles[] = $property . ': ' . $colour;
    }
}

if ($isSidebar) {
    $navClasses[] = 'flex-column';
} else {
    $navClasses[] = 'flex-row flex-wrap';
}

if ($style !== 'plain') {
    $navClasses[] = 'nav-' . $style;
}

$wrapperClasses = [
    'jet-landing__navigation',
    'jet-landing__navigation--' . $position,
    'jet-landing__navigation--' . $style,
];

if ($position === 'top') {
    $wrapperClasses[] = 'container';
}

if ($isSticky) {
    $wrapperClasses[] = 'jet-landing__navigation--sticky';
}
?>
<nav
    class="<?php echo $this->escape(implode(' ', $wrapperClasses)); ?>"
    aria-label="<?php echo $this->escape($this->item->title); ?>"
    data-jet-landing-navigation
    data-scrollspy="<?php echo (bool) $this->params->get('navigation_scrollspy', 1) ? 'true' : 'false'; ?>"
    style="<?php echo $this->escape(implode('; ', $navigationStyles)); ?>"
>
    <button
        class="btn btn-outline-secondary d-lg-none w-100 d-flex align-items-center justify-content-between"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#<?php echo $this->escape($collapseId); ?>"
        aria-expanded="false"
        aria-controls="<?php echo $this->escape($collapseId); ?>"
    >
        <span><?php echo Text::_('COM_JET_LANDING_CONFIG_NAVIGATION_LABEL'); ?></span>
        <span class="icon-bars" aria-hidden="true"></span>
        <span class="visually-hidden"><?php echo Text::_('COM_JET_LANDING_NAVIGATION_TOGGLE'); ?></span>
    </button>

    <div id="<?php echo $this->escape($collapseId); ?>" class="collapse d-lg-block">
        <ul class="<?php echo $this->escape(implode(' ', $navClasses)); ?>">
            <?php foreach ($this->sections as $section) : ?>
                <li class="nav-item">
                    <a
                        class="nav-link"
                        href="#<?php echo rawurlencode($section->alias); ?>"
                        data-jet-landing-target="<?php echo $this->escape($section->alias); ?>"
                    >
                        <?php echo $this->escape($section->title); ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</nav>
