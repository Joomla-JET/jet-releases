<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Site\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;

final class RouteHelper
{
    public static function getLandingRoute(int $id, string $language = '*'): string
    {
        $link  = 'index.php?option=com_jet_landing&view=landing&id=' . $id;
        $items = Factory::getApplication()->getMenu()->getItems('component', 'com_jet_landing') ?: [];

        foreach ($items as $item) {
            if (
                ($item->query['view'] ?? '') === 'landing'
                && (int) ($item->query['id'] ?? 0) === $id
                && ($language === '*' || $item->language === '*' || $item->language === $language)
            ) {
                return $link . '&Itemid=' . (int) $item->id;
            }
        }

        return $link;
    }
}
