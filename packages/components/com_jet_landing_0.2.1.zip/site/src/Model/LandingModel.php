<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Site\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Date\Date;
use Joomla\CMS\Event\Content\ContentPrepareEvent;
use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\MVC\Model\ItemModel;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Component\Content\Site\Helper\RouteHelper as ContentRouteHelper;
use Joomla\Component\Content\Site\Model\ArticleModel;
use Joomla\Database\ParameterType;
use Joomla\Registry\Registry;

final class LandingModel extends ItemModel
{
    private ?object $item = null;

    private ?array $sections = null;

    private ?ArticleModel $articleModel = null;

    protected function populateState(): void
    {
        $app   = Factory::getApplication();
        $input = $app->getInput();
        $id    = $input->getInt('id');

        if ($id < 1) {
            $menu = $app->getMenu()->getActive();
            $id   = (int) ($menu?->query['id'] ?? 0);
        }

        $this->setState('landing.id', $id);
    }

    public function getItem($pk = null): object|false
    {
        $id = (int) ($pk ?: $this->getState('landing.id'));

        if ($id < 1) {
            return false;
        }

        if ($this->item !== null && (int) $this->item->id === $id) {
            return $this->item;
        }

        $db     = $this->getDatabase();
        $now    = (new Date('now', 'UTC'))->toSql();
        $levels = $this->getCurrentUser()->getAuthorisedViewLevels();
        $query  = $db->createQuery()
            ->select('a.*')
            ->from($db->quoteName('#__jet_landings', 'a'))
            ->where($db->quoteName('a.id') . ' = :id')
            ->where($db->quoteName('a.state') . ' = 1')
            ->whereIn($db->quoteName('a.access'), $levels)
            ->where('(' . $db->quoteName('a.publish_up') . ' IS NULL OR ' . $db->quoteName('a.publish_up') . ' <= :now)')
            ->where('(' . $db->quoteName('a.publish_down') . ' IS NULL OR ' . $db->quoteName('a.publish_down') . ' >= :now)')
            ->bind(':id', $id, ParameterType::INTEGER)
            ->bind(':now', $now);

        if (Multilanguage::isEnabled()) {
            $language = Factory::getApplication()->getLanguage()->getTag();
            $query->whereIn($db->quoteName('a.language'), ['*', $language], ParameterType::STRING);
        }

        $this->item = $db->setQuery($query)->loadObject();

        if (!$this->item) {
            return false;
        }

        $this->item->params   = new Registry($this->item->params);
        $this->item->metadata = new Registry($this->item->metadata);

        return $this->item;
    }

    public function getSections(bool $prepareContent = true): array
    {
        if ($this->sections !== null) {
            return $this->sections;
        }

        $landing = $this->getItem();

        if (!$landing) {
            return [];
        }

        $db    = $this->getDatabase();
        $now   = (new Date('now', 'UTC'))->toSql();
        $query = $db->createQuery()
            ->select('s.*')
            ->from($db->quoteName('#__jet_landing_sections', 's'))
            ->where($db->quoteName('s.landing_id') . ' = :landingId')
            ->where($db->quoteName('s.state') . ' = 1')
            ->where('(' . $db->quoteName('s.publish_up') . ' IS NULL OR ' . $db->quoteName('s.publish_up') . ' <= :now)')
            ->where('(' . $db->quoteName('s.publish_down') . ' IS NULL OR ' . $db->quoteName('s.publish_down') . ' >= :now)')
            ->order($db->quoteName('s.ordering') . ' ASC, ' . $db->quoteName('s.id') . ' ASC')
            ->bind(':landingId', $landing->id, ParameterType::INTEGER)
            ->bind(':now', $now);

        $rows           = $db->setQuery($query)->loadObjectList();
        $this->sections = [];

        foreach ($rows as $section) {
            $section->params = new Registry($section->params);
            $section->source_type = in_array((string) $section->source_type, ['custom', 'article'], true)
                ? (string) $section->source_type
                : 'custom';

            if ($section->source_type === 'article') {
                $section = $this->resolveArticleSection($section, $prepareContent);

                if ($section === null) {
                    continue;
                }
            } else {
                $section->content_prepared = false;
                $section->article_url      = '';
            }

            $this->sections[] = $section;
        }

        return $this->sections;
    }

    private function resolveArticleSection(object $section, bool $prepareContent): ?object
    {
        try {
            $article = $this->getArticleModel()->getItem((int) $section->source_id);
        } catch (\Throwable) {
            return null;
        }

        if (!$article || !(bool) $article->params->get('access-view')) {
            return null;
        }

        $now = Factory::getDate()->toSql();

        if (
            (int) $article->state !== 1
            || ($article->publish_up !== null && $article->publish_up > $now)
            || ($article->publish_down !== null && $article->publish_down < $now)
        ) {
            return null;
        }

        $article = clone $article;
        $seoMode = in_array((string) $section->seo_mode, ['independent', 'consolidated', 'duplicate'], true)
            ? (string) $section->seo_mode
            : 'independent';
        $introtext = trim((string) $article->introtext);
        $fulltext  = trim((string) $article->fulltext);

        $article->text = $seoMode === 'independent'
            ? ($introtext !== '' ? $introtext : $fulltext)
            : trim($introtext . ' ' . $fulltext);

        if ($prepareContent) {
            PluginHelper::importPlugin('content', null, true, $this->getDispatcher());
            $this->getDispatcher()->dispatch(
                'onContentPrepare',
                new ContentPrepareEvent('onContentPrepare', [
                    'context' => 'com_content.article',
                    'subject' => $article,
                    'params'  => $article->params,
                    'page'    => 0,
                ])
            );
        }

        $section->seo_mode        = $seoMode;
        $section->content         = $article->text;
        $section->content_prepared = $prepareContent;
        $section->article         = $article;
        $section->article_url     = ContentRouteHelper::getArticleRoute(
            (int) $article->id,
            (int) $article->catid,
            (string) $article->language
        );

        if ((string) $section->params->get('article_title_source', 'article') === 'article') {
            $section->title = (string) $article->title;
        }

        $this->resolveArticleImage($section, $article);

        return $section;
    }

    private function resolveArticleImage(object $section, object $article): void
    {
        $images = new Registry($article->images);
        $source = (string) $section->params->get('article_image_source', 'auto');

        if (!in_array($source, ['auto', 'intro', 'full', 'section', 'none'], true)) {
            $source = 'auto';
        }

        if ($source === 'none') {
            $section->image     = '';
            $section->image_alt = '';

            return;
        }

        if ($source === 'section' || ($source === 'auto' && trim((string) $section->image) !== '')) {
            return;
        }

        $candidates = $source === 'full'
            ? [['image_fulltext', 'image_fulltext_alt']]
            : ($source === 'intro'
                ? [['image_intro', 'image_intro_alt']]
                : [['image_intro', 'image_intro_alt'], ['image_fulltext', 'image_fulltext_alt']]);

        $section->image     = '';
        $section->image_alt = '';

        foreach ($candidates as [$imageKey, $altKey]) {
            $image = trim((string) $images->get($imageKey));

            if ($image !== '') {
                $section->image     = $image;
                $section->image_alt = (string) $images->get($altKey, '');

                return;
            }
        }
    }

    private function getArticleModel(): ArticleModel
    {
        if ($this->articleModel !== null) {
            return $this->articleModel;
        }

        $component = Factory::getApplication()->bootComponent('com_content');
        $model     = $component->getMVCFactory()->createModel('Article', 'Site', ['ignore_request' => true]);

        if (!$model instanceof ArticleModel) {
            throw new \RuntimeException('Unable to create the com_content article model.');
        }

        $model->setState('params', ComponentHelper::getParams('com_content'));
        $model->setState('filter.published', 1);
        $model->setState('filter.archived', 1);
        $model->setState('filter.language', Multilanguage::isEnabled());

        return $this->articleModel = $model;
    }

}
