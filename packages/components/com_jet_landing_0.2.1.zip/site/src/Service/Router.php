<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Site\Service;

defined('_JEXEC') or die;

use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Categories\CategoryFactoryInterface;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Menu\AbstractMenu;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

final class Router extends RouterView
{
    public function __construct(
        SiteApplication $app,
        AbstractMenu $menu,
        ?CategoryFactoryInterface $categoryFactory,
        private readonly DatabaseInterface $db
    )
    {
        $this->name = 'jet_landing';

        $landing = new RouterViewConfiguration('landing');
        $landing->setKey('id');
        $this->registerView($landing);

        parent::__construct($app, $menu);

        $this->attachRule(new MenuRules($this));
        $this->attachRule(new StandardRules($this));
        $this->attachRule(new NomenuRules($this));
    }

    public function getLandingSegment(string $id, array $query): array
    {
        if (str_contains($id, ':')) {
            [$numericId, $alias] = explode(':', $id, 2);

            return [(int) $numericId => $alias];
        }

        $numericId = (int) $id;
        $alias     = $this->db->setQuery(
            $this->db->createQuery()
                ->select($this->db->quoteName('alias'))
                ->from($this->db->quoteName('#__jet_landings'))
                ->where($this->db->quoteName('id') . ' = :id')
                ->bind(':id', $numericId, ParameterType::INTEGER)
        )->loadResult();

        return [$numericId => $alias ?: (string) $numericId];
    }

    public function getLandingId(string $segment, array $query): int|false
    {
        if (ctype_digit($segment)) {
            return (int) $segment;
        }

        $id = $this->db->setQuery(
            $this->db->createQuery()
                ->select($this->db->quoteName('id'))
                ->from($this->db->quoteName('#__jet_landings'))
                ->where($this->db->quoteName('alias') . ' = :alias')
                ->bind(':alias', $segment)
        )->loadResult();

        return $id ? (int) $id : false;
    }
}
