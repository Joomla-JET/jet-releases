<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Site\View\Landing;

defined('_JEXEC') or die;

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Router\Route;
use Joomla\Component\JetLanding\Site\Helper\RouteHelper;
use Joomla\Registry\Registry;

final class HtmlView extends BaseHtmlView
{
    public object $item;

    public array $sections = [];

    public Registry $params;

    public object $section;

    public function display($tpl = null): void
    {
        $model = $this->getModel();
        $item  = $model->getItem();

        if (!$item) {
            throw new \RuntimeException(Text::_('COM_JET_LANDING_ERROR_NOT_FOUND'), 404);
        }

        $this->item   = $item;
        $this->params = clone ComponentHelper::getParams('com_jet_landing');

        foreach ($item->params->toArray() as $name => $value) {
            if ($value !== '') {
                $this->params->set($name, $value);
            }
        }

        $this->sections = $model->getSections((bool) $this->params->get('prepare_content', 1));

        $this->prepareDocument();
        parent::display($tpl);
    }

    private function prepareDocument(): void
    {
        $document = $this->getDocument();
        $document->setTitle((string) $this->item->title);
        $document->addHeadLink(
            Route::_(
                RouteHelper::getLandingRoute((int) $this->item->id, (string) $this->item->language),
                true,
                Route::TLS_IGNORE,
                true
            ),
            'canonical'
        );

        if ($description = trim((string) $this->item->metadata->get('metadesc'))) {
            $document->setDescription($description);
        }

        if ($keywords = trim((string) $this->item->metadata->get('metakey'))) {
            $document->setMetadata('keywords', $keywords);
        }

        if ($robots = trim((string) $this->item->metadata->get('robots'))) {
            $document->setMetadata('robots', $robots);
        }

        $assets = $document->getWebAssetManager();
        $assets->useStyle('com_jet_landing.site');

        if ($this->sections && $this->params->get('navigation_position', 'top') !== 'none') {
            $assets->useScript('com_jet_landing.navigation');
        }
    }
}
