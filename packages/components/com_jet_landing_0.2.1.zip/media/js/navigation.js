document.querySelectorAll('[data-jet-landing-navigation]').forEach((navigation) => {
    const links = [...navigation.querySelectorAll('[data-jet-landing-target]')];
    const targets = links
        .map((link) => document.getElementById(link.dataset.jetLandingTarget))
        .filter(Boolean);

    if (!targets.length) {
        return;
    }

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

    links.forEach((link) => link.addEventListener('click', (event) => {
        if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
            return;
        }

        const target = document.getElementById(link.dataset.jetLandingTarget);

        if (!target) {
            return;
        }

        event.preventDefault();
        target.scrollIntoView({
            behavior: reduceMotion.matches ? 'instant' : 'smooth',
            block: 'start',
        });
        history.pushState(null, '', `#${encodeURIComponent(target.id)}`);
    }));

    if (navigation.dataset.scrollspy !== 'true') {
        return;
    }

    let activeId = '';

    const activate = (id) => {
        if (id === activeId) {
            return;
        }

        activeId = id;

        links.forEach((link) => {
            const active = link.dataset.jetLandingTarget === id;
            link.classList.toggle('active', active);

            if (active) {
                link.setAttribute('aria-current', 'location');
            } else {
                link.removeAttribute('aria-current');
            }
        });
    };

    let updateScheduled = false;

    const updateActiveSection = () => {
        updateScheduled = false;

        if (window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 2) {
            activate(targets[targets.length - 1].id);

            return;
        }

        const activationLine = Math.max(96, Math.min(window.innerHeight * .3, 240));
        let current = targets[0];

        targets.forEach((target) => {
            if (target.getBoundingClientRect().top <= activationLine) {
                current = target;
            }
        });

        activate(current.id);
    };

    const scheduleUpdate = () => {
        if (updateScheduled) {
            return;
        }

        updateScheduled = true;
        window.requestAnimationFrame(updateActiveSection);
    };

    window.addEventListener('scroll', scheduleUpdate, {passive: true});
    window.addEventListener('resize', scheduleUpdate);
    window.addEventListener('load', scheduleUpdate);
    scheduleUpdate();
});
