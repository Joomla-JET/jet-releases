<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Table\Table;

/** Load and validate section records through Joomla MVC. */
final class SectionModel extends AdminModel
{
    public $typeAlias = 'com_jet_landing.section';

    protected $text_prefix = 'COM_JET_LANDING';

    /** Resolve the extension table through the Joomla MVC factory. */
    public function getTable($name = 'Section', $prefix = 'Administrator', $options = []): Table
    {
        return parent::getTable($name, $prefix, $options);
    }

    /** Load the Joomla edit form and constrain fields by state-edit permission. */
    public function getForm($data = [], $loadData = true): Form|false
    {
        $form = $this->loadForm(
            'com_jet_landing.section',
            'section',
            ['control' => 'jform', 'load_data' => $loadData]
        );

        if (!$form) {
            return false;
        }

        if (!$this->getCurrentUser()->authorise('core.edit.state', 'com_jet_landing')) {
            foreach (['state', 'ordering', 'publish_up', 'publish_down'] as $field) {
                $form->setFieldAttribute($field, 'disabled', 'true');
                $form->setFieldAttribute($field, 'filter', 'unset');
            }
        }

        return $form;
    }

    /** Restore submitted form values or load the existing item. */
    protected function loadFormData(): object|array
    {
        $app  = Factory::getApplication();
        $data = $app->getUserState('com_jet_landing.edit.section.data', []);

        if (empty($data)) {
            $data = $this->getItem();

            if (!(int) $data->id) {
                $data->landing_id = $app->getInput()->getInt('landing_id');
            }
        }

        $this->preprocessData('com_jet_landing.section', $data);

        return $data;
    }

    /** Assign initial ordering before Joomla persists a new record. */
    protected function prepareTable($table): void
    {
        if (!(int) $table->id) {
            $table->ordering = $table->getNextOrder(
                $this->getDatabase()->quoteName('landing_id') . ' = ' . (int) $table->landing_id
            );
        }
    }

    /** Require a trashed record and component delete permission. */
    protected function canDelete($record): bool
    {
        return !empty($record->id)
            && (int) $record->state === -2
            && $this->getCurrentUser()->authorise('core.delete', 'com_jet_landing');
    }
}
