<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

/** Handle landing-page forms with Joomla authorization and session checks. */
final class LandingController extends FormController
{
    protected $option = 'com_jet_landing';
}
