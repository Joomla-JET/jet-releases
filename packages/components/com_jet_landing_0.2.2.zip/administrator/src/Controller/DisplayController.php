<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

/** Dispatch authorized requests to the default Joomla MVC view. */
final class DisplayController extends BaseController
{
    protected $default_view = 'landings';
}
