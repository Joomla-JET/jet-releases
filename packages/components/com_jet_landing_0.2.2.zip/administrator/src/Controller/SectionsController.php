<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\MVC\Model\BaseDatabaseModel;

/** Apply Joomla administrative actions to landing sections. */
final class SectionsController extends AdminController
{
    protected $option = 'com_jet_landing';

    /** Resolve the edit model used by Joomla batch and state actions. */
    public function getModel($name = 'Section', $prefix = 'Administrator', $config = ['ignore_request' => true]): BaseDatabaseModel
    {
        return parent::getModel($name, $prefix, $config);
    }
}
