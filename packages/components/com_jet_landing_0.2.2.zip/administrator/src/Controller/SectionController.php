<?php

declare(strict_types=1);

namespace Joomla\Component\JetLanding\Administrator\Controller;

defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\FormController;

/** Handle section forms with Joomla authorization and session checks. */
final class SectionController extends FormController
{
    protected $option = 'com_jet_landing';
}
