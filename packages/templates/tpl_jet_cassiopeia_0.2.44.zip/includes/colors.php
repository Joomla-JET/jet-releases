<?php

/** Build constrained CSS color properties for all JET Cassiopeia document layouts. */

declare(strict_types=1);

use Joomla\Registry\Registry;

defined('_JEXEC') or die;

return static function (Registry $params): string {
    $properties = [
        'bodybg' => '--body-bg', 'bodycolor' => '--body-color',
        'btnbg' => '--btnbg', 'btnbgh' => '--btnbgh',
        'btncolor' => '--btncolor', 'btncolorh' => '--btncolorh',
        'footerbg' => '--footerbg', 'footercolor' => '--footercolor',
        'headerbg' => '--headerbg', 'headercolor' => '--headercolor',
        'linkcolor' => '--link-color', 'linkcolorh' => '--link-hover-color',
    ];
    for ($level = 1; $level <= 6; $level++) {
        $properties['h' . $level . 'color'] = '--h' . $level . '-color';
    }
    $variables = [];
    foreach ($properties as $parameter => $property) {
        $default = str_starts_with($parameter, 'h') && preg_match('/^h[1-6]color$/', $parameter)
            ? 'rgb(23, 23, 23)' : '';
        $color = trim((string) $params->get($parameter, $default));
        // Form filtering alone does not protect settings imported through another extension.
        if (preg_match('/\A(?:#[0-9a-f]{3,4}|#[0-9a-f]{6}(?:[0-9a-f]{2})?|[a-z]+|(?:rgb|hsl)a?\([0-9.,% \/+\-]+\))\z/i', $color)) {
            $variables[] = $property . ': ' . $color . ';';
        }
    }
    return implode("\n", $variables);
};
