<?php

/** Register shared colors and typography from prepared template parameters. */

declare(strict_types=1);

use Joomla\CMS\Document\HtmlDocument;
use Joomla\Registry\Registry;

defined('_JEXEC') or die;

return static function (HtmlDocument $document, Registry $params): void {
    $colors = require __DIR__ . '/colors.php';
    $typography = require __DIR__ . '/typography.php';
    $assets = $document->getWebAssetManager();
    $assets->registerAndUseStyle('colors_custom', 'global/colors.css');
    $assets->registerAndUseStyle('font_advanced', 'global/fonts.css');
    $variables = trim($colors($params) . "\n" . $typography($params));

    if ($params->get('useFontScheme') === 'system') {
        // Some parent layouts interpret "system" as a stylesheet URL instead of a font scheme.
        if ($assets->assetExists('style', 'fontscheme.current')) {
            $assets->disableStyle('fontscheme.current');
        }

        foreach (['systemFontBody' => 'body', 'systemFontHeading' => 'headings'] as $field => $target) {
            if ($params->get($field, '') !== '') {
                $variables .= "\n--cassiopeia-font-family-" . $target . ': ' . $params->get($field, '') . ';';
                $variables .= "\n--cassiopeia-font-weight-" . ($target === 'body' ? 'normal: 400;' : 'headings: 700;');
            }
        }
    }

    if ($variables !== '') {
        $assets->addInlineStyle(':root {' . "\n" . $variables . "\n" . '}');
    }
};
