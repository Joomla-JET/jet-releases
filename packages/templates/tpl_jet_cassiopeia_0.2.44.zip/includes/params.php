<?php

/** Prepare safe template parameters before the parent renders any inline CSS. */

declare(strict_types=1);

use Joomla\Registry\Registry;

defined('_JEXEC') or die;

return static function (Registry $params): Registry {
    static $fontOptions = null;

    if ($fontOptions === null) {
        $manifest = simplexml_load_file(dirname(__DIR__) . '/templateDetails.xml');

        if ($manifest === false) {
            throw new RuntimeException('JET Cassiopeia cannot read its template manifest.');
        }

        $fontOptions = [];

        // The manifest is the single source of truth for local, remote and system font choices.
        foreach (['useFontScheme', 'systemFontBody', 'systemFontHeading'] as $field) {
            $fontOptions[$field] = [];

            foreach ($manifest->xpath('//field[@name="' . $field . '"]//option') ?: [] as $option) {
                $fontOptions[$field][] = (string) $option['value'];
            }
        }
    }

    $prepared = clone $params;

    foreach ($fontOptions as $field => $options) {
        $value = $params->get($field);
        $value = is_string($value) || is_int($value) ? (string) $value : '';
        $prepared->set($field, in_array($value, $options, true) ? $value : ($field === 'useFontScheme' ? '0' : ''));
    }

    // JET generates these properties itself; imported legacy switches must not bypass its validation.
    $prepared->set('colorSettings', false);
    $prepared->set('fontSettings', false);

    return $prepared;
};
