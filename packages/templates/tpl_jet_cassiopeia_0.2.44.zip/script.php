<?php

/** Remove retired template-owned overrides and assets when Joomla installs an update. */

declare(strict_types=1);

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;
use Joomla\Filesystem\File;

defined('_JEXEC') or die;

return new class () implements ServiceProviderInterface {
    /** Register the template installer through Joomla's service container. */
    public function register(Container $container): void
    {
        $container->set(InstallerScriptInterface::class, static fn (): InstallerScriptInterface =>
            new class () implements InstallerScriptInterface {
                /** Delegate initial installation to Joomla. */
                public function install(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Delegate the update to Joomla before removing retired files. */
                public function update(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Delegate template removal to Joomla. */
                public function uninstall(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Keep Joomla's standard installation checks. */
                public function preflight(string $type, InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Delete only known retired files, preserving additional administrator overrides. */
                public function postflight(string $type, InstallerAdapter $adapter): bool
                {
                    if (!in_array($type, ['install', 'update'], true)) {
                        return true;
                    }

                    $templateRoot = $adapter->getParent()->getPath('extension_root');

                    if (!is_string($templateRoot) || $templateRoot === '') {
                        throw new RuntimeException('JET Cassiopeia cannot locate its installed template.');
                    }

                    $mediaRoot = JPATH_PUBLIC . '/media/templates/site/jet_cassiopeia';

                    foreach ([
                        $templateRoot . '/html/mod_sigplus/flow.php',
                        $templateRoot . '/html/mod_sigplus/portfolio.php',
                        $mediaRoot . '/css/sigplus-portfolio.css',
                        $mediaRoot . '/js/sigplus-portfolio.js',
                    ] as $file) {
                        if (is_file($file) && !File::delete($file)) {
                            throw new RuntimeException('JET Cassiopeia could not remove a retired file: ' . $file);
                        }
                    }

                    return true;
                }
            }
        );
    }
};
