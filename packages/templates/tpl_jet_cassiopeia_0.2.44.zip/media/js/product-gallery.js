import PhotoSwipeLightbox from '../vendor/photoswipe/photoswipe-lightbox.esm.min.js';

const gallerySelector = '[data-jet-product-gallery]';
const galleries = new Map();

/** Preload only a selected main image, with a bounded wait for unavailable media. */
const preloadImage = (src) => new Promise((resolve) => {
  const image = new Image();
  const finish = () => {
    clearTimeout(timeout);
    image.onload = null;
    image.onerror = null;
    resolve();
  };
  const timeout = setTimeout(finish, 10000);

  image.onload = finish;
  image.onerror = finish;
  image.src = src;
});

/** Attach one gallery instance and return its teardown for AJAX replacements. */
const initialiseGallery = (gallery) => {
  const links = [...gallery.querySelectorAll('[data-jet-gallery-item]')];
  const mainLink = gallery.querySelector('[data-jet-gallery-main]');
  const galleryLinks = links.length ? links : (mainLink ? [mainLink] : []);
  const mainImage = mainLink?.querySelector('img');
  const thumbnailViewport = gallery.querySelector('[data-jet-gallery-viewport]');
  const previousButton = gallery.querySelector('[data-jet-gallery-previous]');
  const nextButton = gallery.querySelector('[data-jet-gallery-next]');

  if (!galleryLinks.length || !mainLink || !mainImage) {
    return null;
  }

  const controller = new AbortController();
  const events = { signal: controller.signal };
  const items = galleryLinks.map((link) => ({
    src: link.href,
    width: 1,
    height: 1,
    alt: link.dataset.pswpAlt || link.querySelector('img')?.alt || '',
  }));
  let selectedIndex = 0;
  let transitionId = 0;

  const lightbox = new PhotoSwipeLightbox({
    dataSource: items,
    preload: [1, 1],
    pswpModule: () => import('../vendor/photoswipe/photoswipe.esm.min.js'),
  });

  /** Refresh slide geometry when an image loads, including previously cached neighbours. */
  const updateImageDimensions = ({ content, isError }) => {
    const image = content.element;
    const item = items[content.index];
    const instance = lightbox.pswp;

    if (isError || !instance || !image?.naturalWidth || !image.naturalHeight || !item) {
      return;
    }

    if (item.width === image.naturalWidth && item.height === image.naturalHeight) {
      return;
    }

    item.width = image.naturalWidth;
    item.height = image.naturalHeight;

    // Let PhotoSwipe finish its load/append event before replacing the affected slide.
    queueMicrotask(() => {
      if (lightbox.pswp === instance && !instance.isDestroying) {
        instance.refreshSlideContent(content.index);
      }
    });
  };

  lightbox.on('loadComplete', updateImageDimensions);
  lightbox.on('contentAppend', updateImageDimensions);
  lightbox.init();

  const changeMainImage = async (src, alt) => {
    const currentTransitionId = ++transitionId;
    await preloadImage(src);

    if (controller.signal.aborted || currentTransitionId !== transitionId) {
      return;
    }

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      mainImage.src = src;
      mainImage.alt = alt;
      return;
    }

    mainImage.getAnimations().forEach((animation) => animation.cancel());
    const fadeOut = mainImage.animate([
      { opacity: 1, transform: 'scale(1)' },
      { opacity: 0, transform: 'scale(.985)' },
    ], { duration: 140, easing: 'ease-in', fill: 'forwards' });

    await fadeOut.finished.catch(() => {});

    if (controller.signal.aborted || currentTransitionId !== transitionId) {
      fadeOut.cancel();
      return;
    }

    mainImage.src = src;
    mainImage.alt = alt;
    fadeOut.cancel();
    mainImage.animate([
      { opacity: 0, transform: 'scale(1.015)' },
      { opacity: 1, transform: 'scale(1)' },
    ], { duration: 220, easing: 'ease-out' });
  };

  const updateThumbnailControls = () => {
    const thumbnail = thumbnailViewport?.querySelector('[data-jet-gallery-thumbnail]');

    if (!thumbnail || !previousButton || !nextButton) {
      return;
    }

    const gap = parseFloat(window.getComputedStyle(thumbnail.parentElement).rowGap) || 0;
    const thumbnailHeight = thumbnail.getBoundingClientRect().height;
    thumbnailViewport.style.maxHeight = `${(thumbnailHeight * 5) + (gap * 4)}px`;

    const hasOverflow = thumbnailViewport.scrollHeight > thumbnailViewport.clientHeight + 1;
    const isAtStart = thumbnailViewport.scrollTop <= 1;
    const isAtEnd = thumbnailViewport.scrollTop + thumbnailViewport.clientHeight
      >= thumbnailViewport.scrollHeight - 1;

    previousButton.hidden = !hasOverflow || isAtStart;
    nextButton.hidden = !hasOverflow || isAtEnd;
    previousButton.disabled = isAtStart;
    nextButton.disabled = isAtEnd;
  };

  const scrollThumbnails = (direction) => {
    const thumbnail = thumbnailViewport?.querySelector('[data-jet-gallery-thumbnail]');

    if (thumbnail) {
      const gap = parseFloat(window.getComputedStyle(thumbnail.parentElement).rowGap) || 0;
      thumbnailViewport.scrollBy({
        top: direction * (thumbnail.getBoundingClientRect().height + gap),
        behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
      });
    }
  };

  links.forEach((link, index) => {
    link.addEventListener('click', (event) => {
      event.preventDefault();
      selectedIndex = index;
      mainLink.href = link.href;
      mainImage.removeAttribute('width');
      mainImage.removeAttribute('height');
      changeMainImage(link.href, items[index].alt);

      links.forEach((item, itemIndex) => {
        if (itemIndex === selectedIndex) {
          item.setAttribute('aria-current', 'true');
        } else {
          item.removeAttribute('aria-current');
        }
      });

      const thumbnail = link.closest('[data-jet-gallery-thumbnail]');

      if (thumbnailViewport && thumbnail) {
        const viewportBounds = thumbnailViewport.getBoundingClientRect();
        const thumbnailBounds = thumbnail.getBoundingClientRect();
        let scrollTop = thumbnailViewport.scrollTop;

        if (thumbnailBounds.top < viewportBounds.top) {
          scrollTop += thumbnailBounds.top - viewportBounds.top;
        } else if (thumbnailBounds.bottom > viewportBounds.bottom) {
          scrollTop += thumbnailBounds.bottom - viewportBounds.bottom;
        }

        thumbnailViewport.scrollTo({
          top: scrollTop,
          behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
        });
      }
    }, events);
  });

  galleryLinks[0].setAttribute('aria-current', 'true');
  previousButton?.addEventListener('click', () => scrollThumbnails(-1), events);
  nextButton?.addEventListener('click', () => scrollThumbnails(1), events);
  thumbnailViewport?.addEventListener('scroll', updateThumbnailControls, { ...events, passive: true });
  window.addEventListener('resize', updateThumbnailControls, events);
  updateThumbnailControls();

  mainLink.addEventListener('click', (event) => {
    event.preventDefault();
    const item = items[selectedIndex];

    if (mainImage.currentSrc === item.src && mainImage.naturalWidth && mainImage.naturalHeight) {
      item.width = mainImage.naturalWidth;
      item.height = mainImage.naturalHeight;
    }

    lightbox.loadAndOpen(selectedIndex);
  }, events);

  return () => {
    controller.abort();
    lightbox.destroy();
    mainImage.getAnimations().forEach((animation) => animation.cancel());
  };
};

/** Include gallery roots and nested galleries in an inserted or removed subtree. */
const collectGalleries = (node, affected) => {
  if (node instanceof Element) {
    if (node.matches(gallerySelector)) {
      affected.add(node);
    }

    node.querySelectorAll(gallerySelector).forEach((gallery) => affected.add(gallery));
  }
};

/** Initialise new markup and dispose handlers belonging to replaced VirtueMart content. */
const refreshGalleries = (affected) => {
  affected.forEach((gallery) => {
    galleries.get(gallery)?.();
    galleries.delete(gallery);

    if (gallery.isConnected) {
      const destroy = initialiseGallery(gallery);

      if (destroy) {
        galleries.set(gallery, destroy);
      }
    }
  });
};

refreshGalleries(document.querySelectorAll(gallerySelector));

new MutationObserver((records) => {
  const affected = new Set();

  records.forEach((record) => {
    const owner = record.target instanceof Element ? record.target.closest(gallerySelector) : null;

    if (owner) {
      affected.add(owner);
    }

    record.addedNodes.forEach((node) => collectGalleries(node, affected));
    record.removedNodes.forEach((node) => collectGalleries(node, affected));
  });

  refreshGalleries(affected);
}).observe(document.body, { childList: true, subtree: true });
