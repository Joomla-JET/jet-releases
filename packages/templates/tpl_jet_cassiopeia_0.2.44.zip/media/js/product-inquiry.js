/** Load a fresh inquiry form on each opening, including dynamically replaced product pages. */
document.addEventListener('show.bs.modal', (event) => {
  const modal = event.target;

  if (modal instanceof Element && modal.matches('[data-jet-product-inquiry]')) {
    const frame = modal.querySelector('iframe[data-jet-inquiry-src]');

    if (frame) {
      frame.src = frame.dataset.jetInquirySrc;
    }
  }
});

document.addEventListener('hidden.bs.modal', (event) => {
  const modal = event.target;

  if (modal instanceof Element && modal.matches('[data-jet-product-inquiry]')) {
    const frame = modal.querySelector('iframe[data-jet-inquiry-src]');

    if (frame) {
      frame.src = 'about:blank';
    }
  }
});

/** Accept a close request only from the same-origin inquiry frame inside its own modal. */
window.addEventListener('message', (event) => {
  if (event.origin !== window.location.origin || event.data?.type !== 'jet:product-inquiry-close') {
    return;
  }

  document.querySelectorAll('[data-jet-product-inquiry] iframe[data-jet-inquiry-src]').forEach((frame) => {
    if (frame.contentWindow === event.source) {
      window.bootstrap?.Modal?.getInstance(frame.closest('[data-jet-product-inquiry]'))?.hide();
    }
  });
});
