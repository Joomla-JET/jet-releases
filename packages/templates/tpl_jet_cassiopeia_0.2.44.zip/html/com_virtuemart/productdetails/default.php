<?php

/**
 * Default product layout provided by JET Cassiopeia.
 */

defined('_JEXEC') or die;

require __DIR__ . '/jet.php';
