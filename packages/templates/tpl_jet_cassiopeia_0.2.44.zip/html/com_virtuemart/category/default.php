<?php

/**
 * Default category layout provided by JET Cassiopeia.
 */

defined('_JEXEC') or die;

require __DIR__ . '/jet.php';
