<?php

/**
 * Default products sublayout provided by JET Cassiopeia.
 */

defined('_JEXEC') or die;

require __DIR__ . '/products_jet.php';
