<?php

/** Register the site's selected favicon after Cassiopeia adds its default icons. */

declare(strict_types=1);

use Joomla\CMS\Document\HtmlDocument;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;

defined('_JEXEC') or die;

return static function (HtmlDocument $document, Registry $params): void {
    $selected = $params->get('favicon', '');

    if (!is_string($selected) || trim($selected) === '' || preg_match('/[\x00-\x1f\x7f]/', $selected)) {
        return;
    }

    // Media selections can include Joomla image dimensions in the URL fragment.
    try {
        $image = HTMLHelper::cleanImageURL(trim($selected));
    } catch (RuntimeException) {
        return;
    }

    $path = rawurldecode($image->url);

    // Accept local media files only, including when imported parameters bypass the form.
    if (
        $path === '' || str_starts_with($path, '/')
        || preg_match('/[\x00-\x1f\x7f\\\\:?#%<>"\']/', $path)
        || preg_match('#(?:^|/)\.{1,2}(?:/|$)#', $path)
    ) {
        return;
    }

    $types = ['svg' => 'image/svg+xml', 'png' => 'image/png', 'ico' => 'image/vnd.microsoft.icon'];
    $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));

    if (!isset($types[$extension]) || !is_file(JPATH_PUBLIC . '/' . $path)) {
        return;
    }

    $links = $document->getHeadData()['links'];

    foreach ($links as $url => $link) {
        $relations = preg_split('/\s+/', strtolower($link['relation']));

        // A selected site icon replaces the parent's favicon and pinned Joomla branding.
        if (array_intersect(['icon', 'mask-icon'], $relations)) {
            unset($links[$url]);
        }
    }

    $document->setHeadData(['links' => $links]);
    $url = rtrim(Uri::root(true), '/') . '/' . implode('/', array_map('rawurlencode', explode('/', $path)));
    $document->addFavicon($url, $types[$extension]);
};
