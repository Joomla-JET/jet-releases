<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.jet_cassiopeia
 *
 * @copyright   (C) 2025 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/** @var Joomla\CMS\Document\HtmlDocument $this */

$prepareJetParams = require __DIR__ . '/includes/params.php';
$this->params = $prepareJetParams($this->params);

require JPATH_THEMES . '/cassiopeia/component.php';

$registerJetFavicon = require __DIR__ . '/includes/favicon.php';
$registerJetFavicon($this, $this->params);

$registerJetStyles = require __DIR__ . '/includes/styles.php';
$registerJetStyles($this, $this->params);
