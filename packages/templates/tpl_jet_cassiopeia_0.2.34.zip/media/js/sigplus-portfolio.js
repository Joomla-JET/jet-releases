const humanize = (value) => decodeURIComponent(value)
  .replace(/\.[^.]+$/, "")
  .replace(/[-_]+/g, " ")
  .replace(/\s+/g, " ")
  .trim()
  .replace(/^./, (letter) => letter.toLocaleUpperCase());

const setupPortfolio = (portfolio) => {
  const gallery = portfolio.querySelector(".sigplus-gallery");
  const filters = portfolio.querySelector(".jet-sigplus-filters");
  const list = gallery?.querySelector(":scope > ul");
  const metadataNode = portfolio.querySelector("[data-jet-sigplus-metadata]");
  let metadata = {};

  try {
    metadata = JSON.parse(metadataNode?.textContent || "{}");
  } catch {
    metadata = {};
  }

  const metadataEntries = Object.entries(metadata);

  if (!gallery || !filters || !list || portfolio.dataset.jetSigplusReady) return false;

  const items = [...list.children].filter((item) => item.matches("li"));

  if (!items.length) return false;

  portfolio.dataset.jetSigplusReady = "true";
  const group = gallery.id || `sigplus-${Math.random().toString(36).slice(2)}`;
  const categories = new Map();

  items.forEach((item) => {
    const link = item.querySelector("a.sigplus-image");
    const image = link?.querySelector("img");
    const sourceTitle = item.querySelector(".sigplus-title");
    const sourceSummary = item.querySelector(".sigplus-summary");
    const href = link?.getAttribute("href") || "";
    const pathname = decodeURIComponent(new URL(href, window.location.href).pathname).replace(/\\/g, "/");
    const segments = pathname.split("/").filter(Boolean);
    const category = segments.at(-2);
    const metadataItem = metadataEntries.find(([path]) => pathname.endsWith(`/${path}`))?.[1];

    if (!link || !image || !category) return;

    const label = humanize(category);
    item.dataset.galleryCategory = category;
    categories.set(category, label);

    const body = document.createElement("div");
    body.className = "jet-sigplus-card__body";

    const categoryNode = document.createElement("span");
    categoryNode.className = "jet-sigplus-card__category";
    categoryNode.textContent = label;

    const titleText = metadataItem?.title?.trim() || sourceTitle?.textContent.trim() || image.getAttribute("alt")?.trim() || "";
    const summaryText = metadataItem?.summary?.trim() || sourceSummary?.textContent.trim() || "";

    if (metadataItem) {
      image.setAttribute("alt", titleText);
      link.setAttribute("title", summaryText || titleText);

      if (summaryText) link.dataset.summary = summaryText;
    }

    body.append(categoryNode);

    if (titleText) {
      const title = document.createElement("div");
      title.className = "jet-sigplus-card__title";
      title.textContent = titleText;
      body.append(title);
    }

    if (summaryText) {
      const summary = document.createElement("div");
      summary.className = "jet-sigplus-card__summary";
      summary.textContent = summaryText;
      body.append(summary);
    }

    item.append(body);
  });

  if (categories.size < 2) {
    filters.hidden = true;
    return true;
  }

  const initialFilter = categories.keys().next().value;
  const choices = new Map([...categories, ["all", portfolio.dataset.filterAllLabel || "All"]]);

  choices.forEach((label, value) => {
    const button = document.createElement("button");
    const active = value === initialFilter;

    button.type = "button";
    button.className = "btn btn-outline-secondary";
    button.classList.toggle("active", active);
    button.dataset.galleryFilter = value;
    button.setAttribute("aria-pressed", String(active));
    button.textContent = label;
    filters.append(button);
  });

  const buttons = [...filters.querySelectorAll("[data-gallery-filter]")];

  const selectFilter = (selected) => {
    buttons.forEach((candidate) => {
      const active = candidate.dataset.galleryFilter === selected;

      candidate.setAttribute("aria-pressed", String(active));
      candidate.classList.toggle("active", active);
    });

    items.forEach((item) => {
      const visible = selected === "all" || item.dataset.galleryCategory === selected;
      const link = item.querySelector("a.sigplus-image");

      item.hidden = !visible;

      if (link) {
        if (visible) link.dataset.fancybox = `${group}-${selected}`;
        else link.removeAttribute("data-fancybox");
      }
    });
  };

  buttons.forEach((button) => {
    button.addEventListener("click", () => {
      selectFilter(button.dataset.galleryFilter);
    });
  });

  selectFilter(initialFilter);

  return true;
};

const initialisePortfolio = (portfolio) => {
  if (setupPortfolio(portfolio)) return;

  const observer = new MutationObserver(() => {
    if (setupPortfolio(portfolio)) observer.disconnect();
  });

  observer.observe(portfolio, { childList: true, subtree: true });
};

const initialisePortfolios = () => {
  document.querySelectorAll("[data-jet-sigplus-filter]").forEach(initialisePortfolio);
};

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initialisePortfolios, { once: true });
} else {
  initialisePortfolios();
}
