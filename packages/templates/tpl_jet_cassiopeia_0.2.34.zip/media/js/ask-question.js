const form = document.getElementById('askform');

if (form) {
  const fields = [...form.querySelectorAll('[data-jet-validate]')];
  const comment = document.getElementById('comment');
  const counter = document.getElementById('counter');

  const validateField = (field) => {
    const feedback = document.getElementById(`${field.id}-feedback`);
    const isValid = field.checkValidity();

    field.classList.toggle('is-invalid', !isValid);

    if (isValid) {
      field.removeAttribute('aria-invalid');
    } else {
      field.setAttribute('aria-invalid', 'true');
    }

    if (feedback) {
      feedback.textContent = isValid ? '' : field.validationMessage;
    }

    return isValid;
  };

  fields.forEach((field) => {
    field.addEventListener('blur', () => validateField(field));
    field.addEventListener('input', () => {
      if (field.classList.contains('is-invalid')) {
        validateField(field);
      }
    });
  });

  if (comment && counter) {
    const updateCounter = () => {
      counter.value = comment.value.length;
    };

    comment.addEventListener('input', updateCounter);
    updateCounter();
  }

  form.addEventListener('submit', (event) => {
    const results = fields.map(validateField);

    if (results.every(Boolean)) {
      return;
    }

    event.preventDefault();
    fields.find((field) => !field.checkValidity())?.focus();
  });
}
