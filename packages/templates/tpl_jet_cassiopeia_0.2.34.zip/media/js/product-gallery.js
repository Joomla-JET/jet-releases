import PhotoSwipeLightbox from '../vendor/photoswipe/photoswipe-lightbox.esm.min.js';

const getImageSize = (src) => new Promise((resolve) => {
  const image = new Image();

  image.addEventListener('load', () => resolve({
    width: image.naturalWidth,
    height: image.naturalHeight,
  }), { once: true });
  image.addEventListener('error', () => resolve({ width: 1, height: 1 }), { once: true });
  image.src = src;
});

document.querySelectorAll('[data-jet-product-gallery]').forEach((gallery) => {
  const links = [...gallery.querySelectorAll('[data-jet-gallery-item]')];
  const mainLink = gallery.querySelector('[data-jet-gallery-main]');
  const mainImage = mainLink?.querySelector('img');
  const thumbnailViewport = gallery.querySelector('[data-jet-gallery-viewport]');
  const previousButton = gallery.querySelector('[data-jet-gallery-previous]');
  const nextButton = gallery.querySelector('[data-jet-gallery-next]');
  let selectedIndex = 0;
  let transitionId = 0;

  if (!links.length || !mainLink || !mainImage) {
    return;
  }

  const changeMainImage = async (src, alt) => {
    const currentTransitionId = ++transitionId;

    await getImageSize(src);

    if (currentTransitionId !== transitionId) {
      return;
    }

    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      mainImage.src = src;
      mainImage.alt = alt;
      return;
    }

    mainImage.getAnimations().forEach((animation) => animation.cancel());

    const fadeOut = mainImage.animate([
      { opacity: 1, transform: 'scale(1)' },
      { opacity: 0, transform: 'scale(.985)' },
    ], {
      duration: 140,
      easing: 'ease-in',
      fill: 'forwards',
    });

    await fadeOut.finished.catch(() => {});

    if (currentTransitionId !== transitionId) {
      return;
    }

    mainImage.src = src;
    mainImage.alt = alt;
    fadeOut.cancel();

    mainImage.animate([
      { opacity: 0, transform: 'scale(1.015)' },
      { opacity: 1, transform: 'scale(1)' },
    ], {
      duration: 220,
      easing: 'ease-out',
    });
  };

  const updateThumbnailControls = () => {
    if (!thumbnailViewport || !previousButton || !nextButton) {
      return;
    }

    const thumbnail = thumbnailViewport.querySelector('[data-jet-gallery-thumbnail]');

    if (!thumbnail) {
      return;
    }

    const thumbnails = thumbnail.parentElement;
    const gap = parseFloat(window.getComputedStyle(thumbnails).rowGap) || 0;
    const thumbnailHeight = thumbnail.getBoundingClientRect().height;

    thumbnailViewport.style.maxHeight = `${(thumbnailHeight * 5) + (gap * 4)}px`;

    const hasOverflow = thumbnailViewport.scrollHeight > thumbnailViewport.clientHeight + 1;
    const isAtStart = thumbnailViewport.scrollTop <= 1;
    const isAtEnd = thumbnailViewport.scrollTop + thumbnailViewport.clientHeight
      >= thumbnailViewport.scrollHeight - 1;

    previousButton.hidden = !hasOverflow || isAtStart;
    nextButton.hidden = !hasOverflow || isAtEnd;
    previousButton.disabled = isAtStart;
    nextButton.disabled = isAtEnd;
  };

  const scrollThumbnails = (direction) => {
    const thumbnail = thumbnailViewport?.querySelector('[data-jet-gallery-thumbnail]');

    if (!thumbnail) {
      return;
    }

    const gap = parseFloat(window.getComputedStyle(thumbnail.parentElement).rowGap) || 0;

    thumbnailViewport.scrollBy({
      top: direction * (thumbnail.getBoundingClientRect().height + gap),
      behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
    });
  };

  const lightboxReady = Promise.all(links.map(async (link) => {
    const size = await getImageSize(link.href);

    return {
      src: link.href,
      width: size.width,
      height: size.height,
      alt: link.dataset.pswpAlt || link.querySelector('img')?.alt || '',
    };
  })).then((items) => {
    const lightbox = new PhotoSwipeLightbox({
      dataSource: items,
      pswpModule: () => import('../vendor/photoswipe/photoswipe.esm.min.js'),
    });

    lightbox.init();

    return lightbox;
  });

  links.forEach((link, index) => {
    link.addEventListener('click', (event) => {
      event.preventDefault();

      const alt = link.dataset.pswpAlt || link.querySelector('img')?.alt || '';

      selectedIndex = index;
      mainLink.href = link.href;
      mainImage.removeAttribute('width');
      mainImage.removeAttribute('height');
      changeMainImage(link.href, alt);

      links.forEach((item, itemIndex) => {
        if (itemIndex === selectedIndex) {
          item.setAttribute('aria-current', 'true');
        } else {
          item.removeAttribute('aria-current');
        }
      });

      const selectedThumbnail = link.closest('[data-jet-gallery-thumbnail]');

      if (thumbnailViewport && selectedThumbnail) {
        const viewportBounds = thumbnailViewport.getBoundingClientRect();
        const thumbnailBounds = selectedThumbnail.getBoundingClientRect();
        let scrollTop = thumbnailViewport.scrollTop;

        if (thumbnailBounds.top < viewportBounds.top) {
          scrollTop += thumbnailBounds.top - viewportBounds.top;
        } else if (thumbnailBounds.bottom > viewportBounds.bottom) {
          scrollTop += thumbnailBounds.bottom - viewportBounds.bottom;
        }

        thumbnailViewport.scrollTo({
          top: scrollTop,
          behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
        });
      }
    });
  });

  links[0].setAttribute('aria-current', 'true');

  previousButton?.addEventListener('click', () => scrollThumbnails(-1));
  nextButton?.addEventListener('click', () => scrollThumbnails(1));
  thumbnailViewport?.addEventListener('scroll', updateThumbnailControls, { passive: true });
  window.addEventListener('resize', updateThumbnailControls);
  updateThumbnailControls();

  mainLink.addEventListener('click', async (event) => {
    event.preventDefault();
    (await lightboxReady).loadAndOpen(selectedIndex);
  });
});
