const initialiseCarousels = () => {
	const Carousel = window.bootstrap?.Carousel;

	if (!Carousel) {
		return;
	}

	document.querySelectorAll('[data-jet-vm-carousel]').forEach((element) => {
		Carousel.getOrCreateInstance(element).cycle();
	});
};

if (document.readyState === 'loading') {
	document.addEventListener('DOMContentLoaded', initialiseCarousels, { once: true });
} else {
	initialiseCarousels();
}
