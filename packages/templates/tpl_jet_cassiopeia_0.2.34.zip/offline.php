<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.jet_cassiopeia
 *
 * @copyright   (C) 2025 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

/** @var Joomla\CMS\Document\HtmlDocument $this */

require JPATH_THEMES . '/cassiopeia/offline.php';

$wa = $this->getWebAssetManager();

$buildTypographyVariables = require __DIR__ . '/includes/typography.php';
$typographyVariables = $buildTypographyVariables($this->params);

// Advanced Color Settings
$wa->registerAndUseStyle('colors_custom', 'global/colors.css')
    ->addInlineStyle(':root {
        --body-bg: ' . $this->params->get('bodybg') . ';
        --body-color: ' . $this->params->get('bodycolor') . ';
        --btnbg: ' . $this->params->get('btnbg') . ';
        --btnbgh: ' . $this->params->get('btnbgh') . ';
        --btncolor: ' . $this->params->get('btncolor') . ';
        --btncolorh: ' . $this->params->get('btncolorh') . ';
        --footerbg: ' . $this->params->get('footerbg') . ';
        --footercolor: ' . $this->params->get('footercolor') . ';
        --headerbg: ' . $this->params->get('headerbg') . ';
        --headercolor: ' . $this->params->get('headercolor') . ';
        --h1-color: ' . $this->params->get('h1color', 'rgb(23, 23, 23)') . ';
        --h2-color: ' . $this->params->get('h2color', 'rgb(23, 23, 23)') . ';
        --h3-color: ' . $this->params->get('h3color', 'rgb(23, 23, 23)') . ';
        --h4-color: ' . $this->params->get('h4color', 'rgb(23, 23, 23)') . ';
        --h5-color: ' . $this->params->get('h5color', 'rgb(23, 23, 23)') . ';
        --h6-color: ' . $this->params->get('h6color', 'rgb(23, 23, 23)') . ';
        --link-color: ' . $this->params->get('linkcolor') . ';
        --link-hover-color: ' . $this->params->get('linkcolorh') . ';
    }')

    // Advanced Font Settings
    ->registerAndUseStyle('font_advanced', 'global/fonts.css')
    ->addInlineStyle(':root {
        ' . $typographyVariables . '
    }');
