<?php

defined('_JEXEC') or die;

$moduleClass = preg_split('/\s+/', trim((string) $params->get('moduleclass_sfx', ''))) ?: [];

if (in_array('jet-sigplus-portfolio', $moduleClass, true)) {
	require __DIR__ . '/portfolio.php';

	return;
}

require JPATH_SITE . '/modules/mod_sigplus/tmpl/default.php';
