<?php

defined('_JEXEC') or die;

/** @var Joomla\Registry\Registry $params */
/** @var string $gallery_html */

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;

$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
$wa->useStyle('template.jet-cassiopeia.sigplus-portfolio')
	->useScript('template.jet-cassiopeia.sigplus-portfolio');

$metadata = [];
$source = trim(str_replace('\\', '/', (string) $params->get('source', '')), '/');
$captionSource = basename((string) $params->get('caption_source', 'labels.txt'));
$captionPath = JPATH_ROOT . '/images/' . $source . '/' . $captionSource;

if ($source !== '' && !str_contains($source, '..') && is_file($captionPath)) {
	foreach (file($captionPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
		[$path, $title, $summary] = array_pad(explode('|', $line, 3), 3, '');
		$path = ltrim(str_replace('\\', '/', trim($path)), '/');
		$path = str_starts_with($path, '*') ? substr($path, 1) : $path;

		if ($path !== '' && !str_contains($path, '..')) {
			$metadata[$path] = [
				'title' => trim($title),
				'summary' => trim($summary),
			];
		}
	}
}
?>
<div class="mod_sigplus jet-sigplus-portfolio"
	data-jet-sigplus-filter
	data-filter-all-label="<?= htmlspecialchars(Text::_('JALL'), ENT_QUOTES, 'UTF-8') ?>">
	<?php if ($metadata) : ?>
		<script type="application/json" data-jet-sigplus-metadata><?= json_encode($metadata, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?></script>
	<?php endif; ?>
	<nav class="jet-sigplus-filters" aria-label="<?= htmlspecialchars(Text::_('JGLOBAL_FILTER_LABEL'), ENT_QUOTES, 'UTF-8') ?>"></nav>
	<div class="jet-sigplus-portfolio__gallery">
		<?= $gallery_html ?>
	</div>
</div>
