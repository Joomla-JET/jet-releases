<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\Helpers\StringHelper as HTMLStringHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

vmLanguage::loadJLang('com_virtuemart', true);

$carouselId = 'jet-vm-carousel-' . (int) $module->id;
$descriptionId = $carouselId . '-description';
$rootClass  = trim('vmgroup ' . trim((string) $params->get('moduleclass_sfx', '')));
$slideCount = count($products);
$hasFooterText = trim((string) $footerText) !== '';

$escape = static fn (string $value): string => htmlspecialchars($value, ENT_QUOTES, 'UTF-8', false);

$productUrl = static fn (object $product): string => Route::_(
	'index.php?option=com_virtuemart&view=productdetails'
	. '&virtuemart_category_id=' . (int) $product->virtuemart_category_id
	. '&virtuemart_product_id=' . (int) $product->virtuemart_product_id
);
?>
<div class="<?= $escape($rootClass) ?> jet-vm-product-carousel">
	<?php if ($headerText) : ?>
		<div class="vmheader mb-3"><?= $headerText ?></div>
	<?php endif; ?>

	<?php if ($slideCount > 0) : ?>
		<div
			id="<?= $carouselId ?>"
			class="carousel slide overflow-hidden"
			data-jet-vm-carousel
			data-bs-ride="carousel"
			data-bs-wrap="true"
			role="region"
			aria-label="<?= $escape((string) $module->title) ?>"
			<?php if ($hasFooterText) : ?>aria-describedby="<?= $escape($descriptionId) ?>"<?php endif; ?>
		>
			<?php if ($slideCount > 1) : ?>
				<div class="carousel-indicators">
					<?php foreach ($products as $index => $product) : ?>
						<button
							type="button"
							data-bs-target="#<?= $carouselId ?>"
							data-bs-slide-to="<?= (int) $index ?>"
							class="<?= $index === 0 ? 'active' : '' ?>"
							<?= $index === 0 ? 'aria-current="true"' : '' ?>
							aria-label="<?= $escape(Text::sprintf('JLIB_HTML_PAGE_CURRENT_OF_TOTAL', $index + 1, $slideCount)) ?>"
						></button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<div class="carousel-inner bg-body-secondary">
				<?php foreach ($products as $index => $product) : ?>
					<?php
					$url         = $productUrl($product);
					$productName = (string) $product->product_name;
					$description = trim(strip_tags((string) ($product->product_s_desc ?? '')));
					$description = $description !== ''
						? HTMLStringHelper::truncate($description, 180, true, false)
						: '';
					?>
					<div class="carousel-item position-relative<?= $index === 0 ? ' active' : '' ?>">
						<div class="ratio ratio-21x9 jet-vm-product-carousel__media">
							<?php if (!empty($product->images[0])) : ?>
								<?= $product->images[0]->displayMediaFull(
									'class="d-block w-100 h-100 object-fit-cover" loading="' . ($index === 0 ? 'eager' : 'lazy') . '"',
									false,
									'',
									false
								) ?>
							<?php else : ?>
								<span class="d-flex w-100 h-100 align-items-center justify-content-center bg-body-secondary text-body-secondary">
									<?= $escape($productName) ?>
								</span>
							<?php endif; ?>
						</div>
						<a
							class="jet-vm-product-carousel__slide-link<?= $slideCount > 1 ? ' jet-vm-product-carousel__slide-link--with-controls' : '' ?>"
							href="<?= $escape($url) ?>"
							tabindex="-1"
							aria-hidden="true"
						></a>

						<div class="carousel-caption jet-vm-product-carousel__caption start-0 end-0 bottom-0 d-block bg-dark bg-opacity-50 px-4 py-3 text-start">
							<div class="d-flex align-items-center justify-content-between gap-3 mt-1">
								<div>
									<h2 class="mb-0 text-white"><?= $escape($productName) ?></h2>

									<?php if ($description !== '') : ?>
										<p class="d-none d-md-block mt-1 mb-0 text-white"><?= $escape($description) ?></p>
									<?php endif; ?>
								</div>

								<a class="btn btn-outline-light btn-sm flex-shrink-0" href="<?= $escape($url) ?>">
									<?= vmText::_('COM_VIRTUEMART_PRODUCT_DETAILS') ?>
								</a>
							</div>

							<?php if ($show_price && isset($product->prices)) : ?>
								<div class="product-price mt-2 text-white">
									<?php if (!empty($product->prices['salesPrice'])) : ?>
										<?= $currency->createPriceDiv('salesPrice', '', $product->prices, false, false, 1.0, true) ?>
									<?php endif; ?>
									<?php if (!empty($product->prices['salesPriceWithDiscount'])) : ?>
										<?= $currency->createPriceDiv('salesPriceWithDiscount', '', $product->prices, false, false, 1.0, true) ?>
									<?php endif; ?>
								</div>
							<?php endif; ?>

							<?php if ($show_addtocart) : ?>
								<div class="mt-2 position-relative">
									<?= shopFunctionsF::renderVmSubLayout('addtocart', [
										'product' => $product,
										'position' => ['ontop', 'addtocart'],
									]) ?>
								</div>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; ?>
			</div>

			<?php if ($slideCount > 1) : ?>
				<button class="carousel-control-prev jet-vm-product-carousel__control" type="button" data-bs-target="#<?= $carouselId ?>" data-bs-slide="prev">
					<span class="carousel-control-prev-icon" aria-hidden="true"></span>
					<span class="visually-hidden"><?= Text::_('JPREVIOUS') ?></span>
				</button>
				<button class="carousel-control-next jet-vm-product-carousel__control" type="button" data-bs-target="#<?= $carouselId ?>" data-bs-slide="next">
					<span class="carousel-control-next-icon" aria-hidden="true"></span>
					<span class="visually-hidden"><?= Text::_('JNEXT') ?></span>
				</button>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ($hasFooterText) : ?>
		<p id="<?= $escape($descriptionId) ?>" class="vmfooter small text-body-secondary mt-2 mb-0"><?= $escape(trim((string) $footerText)) ?></p>
	<?php endif; ?>
</div>
