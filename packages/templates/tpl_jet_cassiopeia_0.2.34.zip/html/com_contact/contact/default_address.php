<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.jet_cassiopeia
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\String\PunycodeHelper;

/** @var \Joomla\Component\Contact\Site\View\Contact\HtmlView $this */
$details = [];

$phoneHref = static function (string $number): string {
    return preg_replace('/(?!^\+)[^0-9]/', '', trim($number)) ?? '';
};

if (
    $this->params->get('address_check') > 0
    && ($this->item->address || $this->item->suburb || $this->item->state || $this->item->country || $this->item->postcode)
) {
    $addressLines = [];

    if ($this->item->address && $this->params->get('show_street_address')) {
        $streetAddress = preg_replace('/\s+/u', ' ', trim((string) $this->item->address)) ?? '';
        $addressLines[] = $this->escape($streetAddress);
    }

    $locality = [];

    if ($this->item->postcode && $this->params->get('show_postcode')) {
        $locality[] = $this->escape(trim((string) $this->item->postcode));
    }

    if ($this->item->suburb && $this->params->get('show_suburb')) {
        $locality[] = $this->escape(trim((string) $this->item->suburb));
    }

    if ($locality !== []) {
        $addressLines[] = implode(' ', $locality);
    }

    if ($this->item->state && $this->params->get('show_state')) {
        $addressLines[] = $this->escape(trim((string) $this->item->state));
    }

    if ($this->item->country && $this->params->get('show_country')) {
        $addressLines[] = $this->escape(trim((string) $this->item->country));
    }

    if ($addressLines !== []) {
        $details[] = [
            'class' => 'col-12 col-md-4 jet-contact__detail--address',
            'icon' => 'icon-location',
            'label' => Text::_('COM_CONTACT_ADDRESS'),
            'content' => '<address class="mb-0">' . implode(', ', $addressLines) . '</address>',
        ];
    }
}

if ($this->item->telephone && $this->params->get('show_telephone')) {
    $telephone = trim((string) $this->item->telephone);
    $details[] = [
        'class' => 'col-12 col-md-4',
        'icon' => 'icon-phone',
        'label' => Text::_('COM_CONTACT_TELEPHONE'),
        'content' => '<a class="fw-semibold text-decoration-none" href="tel:'
            . htmlspecialchars($phoneHref($telephone), ENT_COMPAT, 'UTF-8') . '">'
            . $this->escape($telephone) . '</a>',
    ];
}

if ($this->item->mobile && $this->params->get('show_mobile')) {
    $mobile = trim((string) $this->item->mobile);
    $details[] = [
        'class' => 'col-12 col-md-4',
        'icon' => 'icon-mobile',
        'label' => Text::_('COM_CONTACT_MOBILE'),
        'content' => '<a class="fw-semibold text-decoration-none" href="tel:'
            . htmlspecialchars($phoneHref($mobile), ENT_COMPAT, 'UTF-8') . '">'
            . $this->escape($mobile) . '</a>',
    ];
}

if ($this->item->email_to && $this->params->get('show_email')) {
    $details[] = [
        'class' => 'col-12 col-md-4',
        'icon' => 'icon-envelope',
        'label' => Text::_('COM_CONTACT_EMAIL_LABEL'),
        'content' => '<span class="contact-emailto">' . $this->item->email_to . '</span>',
    ];
}

if ($this->item->fax && $this->params->get('show_fax')) {
    $details[] = [
        'class' => 'col-12 col-md-4',
        'icon' => 'icon-fax',
        'label' => Text::_('COM_CONTACT_FAX'),
        'content' => '<span class="contact-fax">' . $this->escape(trim((string) $this->item->fax)) . '</span>',
    ];
}

if ($this->item->webpage && $this->params->get('show_webpage')) {
    $webpage = trim((string) $this->item->webpage);
    $details[] = [
        'class' => 'col-12 col-md-4',
        'icon' => 'icon-home',
        'label' => Text::_('COM_CONTACT_WEBPAGE'),
        'content' => '<a class="fw-semibold text-decoration-none" href="'
            . htmlspecialchars($webpage, ENT_COMPAT, 'UTF-8') . '" target="_blank" rel="noopener noreferrer">'
            . $this->escape(PunycodeHelper::urlToUTF8($webpage)) . '</a>',
    ];
}

$detailsLayoutClass = count($details) === 3 ? 'jet-contact__details--compact d-md-flex' : 'row g-0';
?>

<?php if ($details !== []) : ?>
    <div class="com-contact__address contact-address jet-contact__details <?php echo $detailsLayoutClass; ?> border rounded-4 bg-body shadow-sm overflow-hidden">
        <?php foreach ($details as $detail) : ?>
            <div class="<?php echo $detail['class']; ?> jet-contact__detail">
                <div class="d-flex gap-2 h-100 px-3 py-2">
                    <span class="jet-contact__detail-icon flex-shrink-0 lh-1 mt-1" aria-hidden="true">
                        <span class="<?php echo $detail['icon']; ?>"></span>
                    </span>
                    <div class="jet-contact__detail-content">
                        <div class="jet-contact__detail-label small text-body-secondary mb-0">
                            <?php echo $detail['label']; ?>
                        </div>
                        <div class="contact-detail-value jet-contact__detail-value">
                            <?php echo $detail['content']; ?>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
