<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.jet_cassiopeia
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ContentHelper;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\CMS\Layout\LayoutHelper;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Router\Route;
use Joomla\Component\Contact\Site\Helper\RouteHelper;

/** @var \Joomla\Component\Contact\Site\View\Contact\HtmlView $this */
$tparams = $this->item->params;
$canDo   = ContentHelper::getActions('com_contact', 'category', $this->item->catid);
$canEdit = $canDo->get('core.edit') || ($canDo->get('core.edit.own') && $this->item->created_by === $this->getCurrentUser()->id);
$htag    = $tparams->get('show_page_heading') ? 'h2' : 'h1';
$htag2   = ($tparams->get('show_page_heading') && $tparams->get('show_name')) ? 'h3' : 'h2';
$showEmailForm = $tparams->get('show_email_form') && ($this->item->email_to || $this->item->user_id);

$this->getDocument()->getWebAssetManager()->useStyle('template.jet-cassiopeia.contact');

$sectionTitle = static function (string $title, string $class = '') use ($htag2): void {
    $classAttribute = $class !== '' ? ' class="' . $class . '"' : '';
    echo '<' . $htag2 . $classAttribute . '>' . $title . '</' . $htag2 . '>';
};
?>

<div class="com-contact contact jet-contact">
    <?php if ($tparams->get('show_page_heading')) : ?>
        <h1 class="jet-contact__page-title">
            <?php echo $this->escape($tparams->get('page_heading')); ?>
        </h1>
    <?php endif; ?>

    <?php if ($this->item->name && $tparams->get('show_name')) : ?>
        <div class="page-header jet-contact__header">
            <<?php echo $htag; ?> class="jet-contact__title">
                <?php if ($this->item->published == 0) : ?>
                    <span class="badge bg-warning text-light"><?php echo Text::_('JUNPUBLISHED'); ?></span>
                <?php endif; ?>
                <span class="contact-name"><?php echo $this->item->name; ?></span>
            </<?php echo $htag; ?>>
        </div>
    <?php endif; ?>

    <?php if ($canEdit) : ?>
        <div class="icons">
            <div class="float-end">
                <?php echo HTMLHelper::_('contacticon.edit', $this->item, $tparams); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php $showContactCategory = $tparams->get('show_contact_category'); ?>

    <?php if ($showContactCategory === 'show_no_link') : ?>
        <?php $sectionTitle('<span class="contact-category">' . $this->item->category_title . '</span>', 'jet-contact__subtitle'); ?>
    <?php elseif ($showContactCategory === 'show_with_link') : ?>
        <?php $contactLink = RouteHelper::getCategoryRoute($this->item->catid, $this->item->language); ?>
        <?php $sectionTitle('<span class="contact-category"><a href="' . $contactLink . '">' . $this->escape($this->item->category_title) . '</a></span>', 'jet-contact__subtitle'); ?>
    <?php endif; ?>

    <?php echo $this->item->event->afterDisplayTitle; ?>

    <?php if ($tparams->get('show_contact_list') && count($this->contacts) > 1) : ?>
        <form action="#" method="get" name="selectForm" id="selectForm" class="jet-contact__select mb-4">
            <label class="form-label" for="select_contact"><?php echo Text::_('COM_CONTACT_SELECT_CONTACT'); ?></label>
            <?php echo HTMLHelper::_(
                'select.genericlist',
                $this->contacts,
                'select_contact',
                'class="form-select" onchange="document.location.href = this.value"',
                'link',
                'name',
                $this->item->link
            ); ?>
        </form>
    <?php endif; ?>

    <?php if ($tparams->get('show_tags', 1) && !empty($this->item->tags->itemTags)) : ?>
        <div class="com-contact__tags jet-contact__tags">
            <?php $this->item->tagLayout = new FileLayout('joomla.content.tags'); ?>
            <?php echo $this->item->tagLayout->render($this->item->tags->itemTags); ?>
        </div>
    <?php endif; ?>

    <?php echo $this->item->event->beforeDisplayContent; ?>

    <div class="row g-4 g-xl-5 align-items-start">
        <div class="col-12 <?php echo $showEmailForm ? 'col-lg-7' : 'col-lg-12'; ?>">
            <?php if ($this->params->get('show_info', 1)) : ?>
                <section class="com-contact__container jet-contact__section d-block">
                    <?php $sectionTitle(Text::_('COM_CONTACT_DETAILS'), 'jet-contact__section-title'); ?>

                    <?php if ($this->item->image && $tparams->get('show_image')) : ?>
                        <div class="com-contact__thumbnail jet-contact__image">
                            <?php echo LayoutHelper::render(
                                'joomla.html.image',
                                [
                                    'src' => $this->item->image,
                                    'alt' => $this->item->name,
                                ]
                            ); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($this->item->con_position && $tparams->get('show_position')) : ?>
                        <dl class="com-contact__position contact-position">
                            <dt><?php echo Text::_('COM_CONTACT_POSITION'); ?>:</dt>
                            <dd><?php echo $this->item->con_position; ?></dd>
                        </dl>
                    <?php endif; ?>

                    <div class="com-contact__info jet-contact__info">
                        <?php echo $this->loadTemplate('address'); ?>

                        <?php if ($tparams->get('allow_vcard')) : ?>
                            <p class="mb-0 mt-3">
                                <?php echo Text::_('COM_CONTACT_DOWNLOAD_INFORMATION_AS'); ?>
                                <a href="<?php echo Route::_('index.php?option=com_contact&view=contact&catid=' . $this->item->catslug . '&id=' . $this->item->slug . '&format=vcf'); ?>">
                                    <?php echo Text::_('COM_CONTACT_VCARD'); ?>
                                </a>
                            </p>
                        <?php endif; ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php if ($tparams->get('show_links')) : ?>
                <section class="jet-contact__section">
                    <?php $sectionTitle(Text::_('COM_CONTACT_LINKS'), 'jet-contact__section-title'); ?>
                    <?php echo $this->loadTemplate('links'); ?>
                </section>
            <?php endif; ?>

            <?php if ($tparams->get('show_articles') && $this->item->user_id && $this->item->articles) : ?>
                <section class="jet-contact__section">
                    <?php $sectionTitle(Text::_('JGLOBAL_ARTICLES'), 'jet-contact__section-title'); ?>
                    <?php echo $this->loadTemplate('articles'); ?>
                </section>
            <?php endif; ?>

            <?php if ($tparams->get('show_profile') && $this->item->user_id && PluginHelper::isEnabled('user', 'profile')) : ?>
                <section class="jet-contact__section">
                    <?php $sectionTitle(Text::_('COM_CONTACT_PROFILE'), 'jet-contact__section-title'); ?>
                    <?php echo $this->loadTemplate('profile'); ?>
                </section>
            <?php endif; ?>

            <?php if ($tparams->get('show_user_custom_fields') && $this->contactUser) : ?>
                <section class="jet-contact__section">
                    <?php echo $this->loadTemplate('user_custom_fields'); ?>
                </section>
            <?php endif; ?>

            <?php if ($this->item->misc && $tparams->get('show_misc')) : ?>
                <section class="com-contact__miscinfo contact-miscinfo jet-contact__section jet-contact__misc">
                    <?php $sectionTitle(Text::_('COM_CONTACT_OTHER_INFORMATION'), 'jet-contact__section-title'); ?>
                    <div class="contact-misc">
                        <?php echo $this->item->misc; ?>
                    </div>
                </section>
            <?php endif; ?>
        </div>

        <?php if ($showEmailForm) : ?>
            <div class="col-12 col-lg-5">
                <aside class="jet-contact__form-panel">
                    <?php $sectionTitle(Text::_('COM_CONTACT_EMAIL_FORM'), 'jet-contact__form-title'); ?>
                    <?php echo $this->loadTemplate('form'); ?>
                </aside>
            </div>
        <?php endif; ?>
    </div>

    <?php echo $this->item->event->afterDisplayContent; ?>
</div>
