<?php

/**
 * @package     Joomla.Site
 * @subpackage  Templates.jet_cassiopeia
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;

/** @var \Joomla\Component\Contact\Site\View\Contact\HtmlView $this */
/** @var Joomla\CMS\WebAsset\WebAssetManager $wa */
$wa = $this->getDocument()->getWebAssetManager();
$wa->useScript('keepalive')
    ->useScript('form.validate');

$inputClasses = [
    'contact_name'    => 'form-control',
    'contact_email'   => 'form-control',
    'contact_subject' => 'form-control',
    'contact_message' => 'form-control',
];

foreach ($inputClasses as $fieldName => $class) {
    $this->form->setFieldAttribute($fieldName, 'class', $class);
}

$this->form->setFieldAttribute('contact_email_copy', 'class', 'form-check-input');
?>

<div class="com-contact__form contact-form jet-contact-form">
    <form id="contact-form" action="<?php echo Route::_('index.php'); ?>" method="post" class="form-validate">
        <?php foreach ($this->form->getFieldsets() as $fieldset) : ?>
            <?php if ($fieldset->name === 'captcha' && $this->captchaEnabled) : ?>
                <?php continue; ?>
            <?php endif; ?>

            <?php $fields = $this->form->getFieldset($fieldset->name); ?>

            <?php if (count($fields)) : ?>
                <fieldset class="jet-contact-form__fieldset">
                    <?php foreach ($fields as $field) : ?>
                        <?php echo $field->renderField(); ?>
                    <?php endforeach; ?>
                </fieldset>
            <?php endif; ?>
        <?php endforeach; ?>

        <?php if ($this->captchaEnabled) : ?>
            <fieldset class="jet-contact-form__fieldset">
                <?php echo $this->form->renderFieldset('captcha'); ?>
            </fieldset>
        <?php endif; ?>

        <div class="jet-contact-form__actions">
            <button class="btn btn-primary validate w-100" type="submit">
                <?php echo Text::_('COM_CONTACT_CONTACT_SEND'); ?>
            </button>
            <input type="hidden" name="option" value="com_contact">
            <input type="hidden" name="task" value="contact.submit">
            <input type="hidden" name="return" value="<?php echo $this->return_page; ?>">
            <input type="hidden" name="id" value="<?php echo $this->item->slug; ?>">
            <?php echo HTMLHelper::_('form.token'); ?>
        </div>
    </form>
</div>
