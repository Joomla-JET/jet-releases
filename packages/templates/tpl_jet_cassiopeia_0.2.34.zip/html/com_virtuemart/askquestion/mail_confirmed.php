<?php

/**
 * Jet Cassiopeia override – Ask-question confirmation (Bootstrap 5).
 *
 * Rendered inside the product-detail modal iframe after the question is sent.
 * Closes the parent Bootstrap 5 modal instead of legacy Fancybox/Facebox.
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;

Factory::getApplication()
	->getDocument()
	->getWebAssetManager()
	->useStyle('template.jet-cassiopeia.vm');

$thankYouIcon = '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="currentColor" class="bi bi-check-circle text-success" viewBox="0 0 16 16">
	<path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14m0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16"/>
	<path d="m10.97 4.97-.02.022-3.475 4.425-2.093-2.094a.75.75 0 0 0-1.06 1.06L6.97 9.98a.75.75 0 0 0 1.08-.02l4-4.5a.75.75 0 0 0-1.08-1.02z"/>
</svg>';
?>
<div class="ask-a-question-view d-flex flex-column align-items-center justify-content-center text-center p-5">
	<?php echo $thankYouIcon; ?>
	<h1 class="h5 mt-3 mb-2"><?php echo vmText::_('COM_VIRTUEMART_ASK_QUESTION_THANK_YOU'); ?></h1>
	<button class="btn btn-primary mt-3 d-inline-flex align-items-center gap-2" type="button" id="vmAskClose">
		<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-lg" viewBox="0 0 16 16">
			<path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8z"/>
		</svg>
		<?php echo vmText::_('COM_VIRTUEMART_CLOSE'); ?>
	</button>
</div>
<script>
(function () {
	'use strict';
	function closeParentModal() {
		try {
			var modalEl = window.parent.document.getElementById('vmAskQuestionModal');
			if (modalEl) {
				var instance = window.parent.bootstrap.Modal.getInstance(modalEl);
				if (instance) { instance.hide(); return; }
			}
		} catch (e) {}
	}
	document.getElementById('vmAskClose').addEventListener('click', closeParentModal);
})();
</script>
