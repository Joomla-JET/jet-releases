<?php

/**
 * Jet Cassiopeia override – Ask a question form (Bootstrap 5).
 *
 * Loaded inside the product-detail modal via iframe with tmpl=component.
 */

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;
use Joomla\CMS\HTML\HTMLHelper;

Factory::getApplication()
	->getDocument()
	->getWebAssetManager()
	->useStyle('template.jet-cassiopeia.vm')
	->useScript('template.jet-cassiopeia.ask-question');

$min = VmConfig::get('asks_minimum_comment_length', 50);
$max = VmConfig::get('asks_maximum_comment_length', 2000);

if (empty($this->product)) {
	echo vmText::_('COM_VIRTUEMART_PRODUCT_NOT_FOUND');
	echo '<br /><br />' . $this->continue_link_html;
	return;
}

$session = Factory::getSession();
$sessData = $session->get('askquestion', array());

if (!empty($this->login)) {
	echo $this->login;
	return;
}

$askName  = $this->user->name ?: ($sessData['name'] ?? '');
$askEmail = $this->user->email ?: ($sessData['email'] ?? '');
$actionUrl = Route::_(
	'index.php?option=com_virtuemart&view=productdetails'
	. '&virtuemart_product_id=' . $this->product->virtuemart_product_id
	. '&virtuemart_category_id=' . $this->product->virtuemart_category_id
	. '&tmpl=component',
	FALSE
);

?>

<div class="ask-a-question-view p-4">
	<form method="post" class="form-validate" action="<?php echo $actionUrl; ?>" name="askform" id="askform" novalidate>
		<div class="mb-3">
			<label class="form-label" for="name">
				<?php echo vmText::_('COM_VIRTUEMART_USER_FORM_NAME'); ?>
			</label>
			<input class="form-control" type="text" id="name" name="name" value="<?php echo htmlspecialchars($askName, ENT_QUOTES, 'UTF-8'); ?>" size="30" minlength="3" maxlength="64" aria-describedby="name-feedback" data-jet-validate required>
			<div class="invalid-feedback" id="name-feedback" aria-live="polite"></div>
		</div>

		<div class="mb-3">
			<label class="form-label" for="email">
				<?php echo vmText::_('COM_VIRTUEMART_USER_FORM_EMAIL'); ?>
			</label>
			<input class="form-control" type="email" id="email" name="email" value="<?php echo htmlspecialchars($askEmail, ENT_QUOTES, 'UTF-8'); ?>" size="30" aria-describedby="email-feedback" data-jet-validate required>
			<div class="invalid-feedback" id="email-feedback" aria-live="polite"></div>
		</div>

		<div class="mb-3">
			<label class="form-label" for="comment">
				<?php echo vmText::sprintf('COM_VIRTUEMART_ASK_COMMENT', $min, $max); ?>
			</label>
			<textarea class="form-control" id="comment" name="comment" rows="5" minlength="<?php echo $min; ?>" maxlength="<?php echo $max; ?>" aria-describedby="comment-feedback" data-jet-validate required><?php echo htmlspecialchars($sessData['comment'] ?? '', ENT_QUOTES, 'UTF-8'); ?></textarea>
			<div class="invalid-feedback" id="comment-feedback" aria-live="polite"></div>
		</div>

		<?php if (!empty($this->captcha)) : ?>
			<div class="mb-3">
				<?php echo $this->captcha; ?>
			</div>
		<?php endif; ?>

		<div class="d-flex align-items-center justify-content-between pt-2">
			<button class="btn btn-primary d-inline-flex align-items-center gap-2" type="submit" name="submit_ask">
				<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-send" viewBox="0 0 16 16">
					<path d="M15.854.146a.5.5 0 0 1 .11.54l-5.819 14.547a.75.75 0 0 1-1.329.124l-3.178-4.995L.643 7.184a.75.75 0 0 1 .124-1.33L15.314.037a.5.5 0 0 1 .54.11ZM6.636 10.07l2.761 4.338L14.13 2.576zm6.787-8.201L1.591 6.602l4.339 2.76z"/>
				</svg>
				<?php echo vmText::_('COM_VIRTUEMART_ASK_SUBMIT'); ?>
			</button>

			<div class="d-flex align-items-center gap-2">
				<label class="form-label text-body-secondary small mb-0" for="counter">
					<?php echo vmText::_('COM_VIRTUEMART_ASK_COUNT'); ?>
				</label>
				<input class="form-control form-control-sm text-center" style="width:4rem" id="counter" type="text" value="0" name="counter" maxlength="4" readonly disabled>
			</div>
		</div>

		<input type="hidden" name="virtuemart_product_id" value="<?php echo vRequest::getInt('virtuemart_product_id', 0); ?>">
		<input type="hidden" name="tmpl" value="component">
		<input type="hidden" name="view" value="productdetails">
		<input type="hidden" name="option" value="com_virtuemart">
		<input type="hidden" name="virtuemart_category_id" value="<?php echo vRequest::getInt('virtuemart_category_id'); ?>">
		<input type="hidden" name="task" value="mailAskquestion">
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
</div>
