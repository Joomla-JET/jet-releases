<?php

/**
 * VirtueMart products sublayout for Jet Cassiopeia.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Router\Route;

HTMLHelper::_('bootstrap.tooltip');

Factory::getApplication()
	->getDocument()
	->getWebAssetManager()
	->useStyle('template.jet-cassiopeia.vm');

$productsPerRow = empty($viewData['products_per_row']) ? 1 : (int) $viewData['products_per_row'];
$currency = $viewData['currency'];
$showRating = $viewData['showRating'];
$columnClass = 'col-sm-6 col-xl-' . max(3, (int) floor(12 / max(1, $productsPerRow)));

echo shopFunctionsF::renderVmSubLayout('askrecomjs');

$itemId = shopFunctionsF::getLastVisitedItemId();
$itemIdSuffix = $itemId ? '&Itemid=' . (int) $itemId : '';
$isDynamic = vRequest::getInt('dynamic', false) && vRequest::getInt('virtuemart_product_id', false);
?>

<?php foreach ($viewData['products'] as $type => $products) : ?>
	<?php
	if (empty($products)) {
		continue;
	}

	if (!$isDynamic && ((!empty($type) && count($products) > 0) || (count($viewData['products']) > 1 && count($products) > 0))) :
		$productTitle = vmText::_('COM_VIRTUEMART_' . strtoupper($type) . '_PRODUCT');
	?>
		<section class="<?php echo htmlspecialchars($type, ENT_COMPAT, 'UTF-8'); ?>-view mb-5">
			<h2 class="vm-products-type-title h4 mb-4"><?php echo $productTitle; ?></h2>
	<?php endif; ?>

	<div class="jet-vm-products row g-4">
		<?php foreach ($products as $product) : ?>
			<?php
			if (!is_object($product) || empty($product->link)) {
				vmdebug('$product is not object or link empty', $product);
				continue;
			}

			$productLink = empty($product->link) ? $product->canonical : $product->link;
			$productUrl = Route::_($productLink . $itemIdSuffix);
			$productName = vmText::_($product->product_name);
			?>

			<div class="product <?php echo $columnClass; ?>">
				<article class="jet-vm-product-card card h-100 overflow-hidden rounded-3 border-0 shadow-sm" data-vm="product-container">
					<a class="jet-vm-product-card__media ratio ratio-16x9 overflow-hidden bg-body-tertiary" href="<?php echo $productUrl; ?>" title="<?php echo htmlspecialchars($productName, ENT_COMPAT, 'UTF-8'); ?>">
						<?php if (!empty($product->images[0])) : ?>
							<?php echo $product->images[0]->displayMediaThumb('class="browseProductImage w-100 h-100 object-fit-contain p-2"', false); ?>
						<?php endif; ?>
					</a>

					<div class="card-body d-flex flex-column">
						<?php echo $product->event->afterDisplayTitle; ?>

						<?php if ($showRating || VmConfig::get('display_stock', 1)) : ?>
							<div class="vm-product-rating-container d-flex justify-content-between align-items-center gap-2 small mb-3">
								<?php echo shopFunctionsF::renderVmSubLayout('rating', ['showRating' => $showRating, 'product' => $product]); ?>
								<?php echo shopFunctionsF::renderVmSubLayout('displaystock', ['product' => $product]); ?>
							</div>
						<?php endif; ?>

						<h2 class="vm-product-title h5 lh-sm mb-2">
							<?php echo HTMLHelper::link($productUrl, $productName, ['class' => 'text-decoration-none']); ?>
						</h2>

						<?php if (!empty($product->product_s_desc)) : ?>
							<p class="vm-product-s-desc small lh-base text-body-secondary mb-4">
								<?php echo shopFunctionsF::limitStringByWord($product->product_s_desc, 36, ' ...'); ?>
							</p>
						<?php endif; ?>

						<div class="mt-auto pt-2">
							<?php echo HTMLHelper::link(
								$productUrl,
								vmText::_('COM_VIRTUEMART_PRODUCT_DETAILS'),
								['class' => 'btn btn-primary w-100']
							); ?>
						</div>
					</div>

					<?php
					if ($isDynamic) {
						echo vmJsApi::writeJS();
					}
					?>
				</article>
			</div>
		<?php endforeach; ?>
	</div>

	<?php if (!$isDynamic && ((!empty($type) && count($products) > 0) || (count($viewData['products']) > 1 && count($products) > 0))) : ?>
		</section>
	<?php endif; ?>
<?php endforeach; ?>
