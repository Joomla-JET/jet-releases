<?php

/**
 * Default products sublayout provided by Jet Cassiopeia.
 */

defined('_JEXEC') or die;

require __DIR__ . '/products_jet.php';
