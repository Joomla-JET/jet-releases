<?php

/**
 * VirtueMart category layout for Jet Cassiopeia.
 *
 * Keeps VirtueMart data flow intact and only modernizes the category markup
 * with Bootstrap 5 classes.
 */

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Router\Route;

Factory::getApplication()
	->getDocument()
	->getWebAssetManager()
	->useStyle('template.jet-cassiopeia.vm');

if (vRequest::getInt('dynamic', false) && vRequest::getInt('virtuemart_product_id', false)) {
	if (!empty($this->products)) {
		if ($this->fallback) {
			$product = $this->products;
			$this->products = [$product];
			vmdebug('Refallback');
		}

		echo shopFunctionsF::renderVmSubLayout($this->productsLayout, [
			'products' => $this->products,
			'currency' => $this->currency,
			'products_per_row' => $this->perRow,
			'showRating' => $this->showRating,
		]);
	}

	return;
}

$hasProducts = !empty($this->products);
$hasSearch = $this->showsearch || $this->keyword !== false;
$formatPagination = static function (string $links): string {
	$links = trim($links);

	if ($links === '') {
		return '';
	}

	if (preg_match('/<a\b(?=[^>]*\btitle="1")(?=[^>]*\bhref="([^"]+)")[^>]*>/i', $links, $firstPageLink)) {
		$firstPageUrl = $firstPageLink[1];
		$separator = str_contains($firstPageUrl, '?') ? '&amp;' : '?';
		$resetPageUrl = $firstPageUrl . $separator . 'limitstart=0';
		$links = str_replace('href="' . $firstPageUrl . '"', 'href="' . $resetPageUrl . '"', $links);
	}

	$links = str_replace('<ul>', '<ul class="pagination pagination-sm flex-wrap align-items-center gap-1 m-0">', $links);
	$links = preg_replace('/<li([^>]*)class="([^"]*)"/', '<li$1class="$2 page-item"', $links);
	$links = preg_replace('/<li(?![^>]*class=)([^>]*)>/', '<li$1 class="page-item">', $links);
	$links = preg_replace('/class="[^"]*\bpagenav\b[^"]*"/', 'class="page-link"', $links);
	$links = str_replace('class="page-link"', 'class="page-link rounded-2"', $links);
	$links = str_replace(
		'<span class="page-link rounded-2">',
		'<span class="page-link rounded-2 text-body-secondary bg-body-tertiary">',
		$links
	);

	return '<nav class="d-flex align-items-center" aria-label="Page navigation">' . $links . '</nav>';
};
?>

<div class="jet-vm-category category-view">
	<header class="jet-vm-category__header text-center">
		<?php if ($this->show_store_desc && !empty($this->vendor->vendor_store_desc)) : ?>
			<div class="vm-vendor-store-desc mb-4">
				<?php echo $this->vendor->vendor_store_desc; ?>
			</div>
		<?php endif; ?>

		<?php if (!empty($this->category->category_name)) : ?>
			<h1 class="vm-category-title fw-semibold mb-3">
				<?php echo vmText::_($this->category->category_name); ?>
			</h1>
		<?php endif; ?>

		<?php if ($this->showcategory_desc && empty($this->keyword)) : ?>
			<?php if (!empty($this->category->category_description)) : ?>
				<div class="vm-category-description text-start">
					<?php echo $this->category->category_description; ?>
				</div>
			<?php endif; ?>

			<?php if (!empty($this->manu_descr)) : ?>
				<div class="vm-manufacturer-description mx-auto mt-3">
					<?php echo $this->manu_descr; ?>
				</div>
			<?php endif; ?>
		<?php endif; ?>
	</header>

	<?php if ($this->showcategory && empty($this->keyword) && !empty($this->category->has_children)) : ?>
		<section class="jet-vm-category__children mb-4 mb-lg-5">
			<?php echo ShopFunctionsF::renderVmSubLayout('categories', [
				'categories' => $this->category->children,
				'categories_per_row' => $this->categories_per_row,
			]); ?>
		</section>
	<?php endif; ?>

	<?php if ($hasProducts || $hasSearch) : ?>
		<div class="browse-view">
			<?php if ($hasSearch) : ?>
				<?php $categoryId = vRequest::getInt('virtuemart_category_id', 0); ?>

				<div class="virtuemart_search card border-0 shadow-sm mb-4">
					<div class="card-body">
						<form class="row g-3 align-items-end" action="<?php echo Route::_('index.php?option=com_virtuemart&view=category&limitstart=0', false); ?>" method="get">
							<?php if (!empty($this->searchCustomList)) : ?>
								<div class="vm-search-custom-list col-12">
									<?php echo $this->searchCustomList; ?>
								</div>
							<?php endif; ?>

							<?php if (!empty($this->searchCustomValuesAr)) : ?>
								<div class="vm-search-custom-values col-12">
									<div class="row g-2 align-items-end">
										<?php echo shopFunctionsF::renderVmSubLayout('searchcustomvalues', [
											'searchcustomvalues' => $this->searchCustomValuesAr,
										]); ?>

										<?php if (count($this->searchCustomValuesAr) > 1) : ?>
											<div class="col-12 col-md-auto">
												<div class="form-check mb-1">
													<?php echo VmHtml::checkbox('combineTags', $this->combineTags, 1, 0, 'class="form-check-input"', 'combineTags'); ?>
													<label class="form-check-label" for="combineTags">
														<?php echo vmText::_('COM_VM_COMBINETAGS'); ?>
													</label>
												</div>
											</div>
										<?php endif; ?>
									</div>
								</div>
							<?php endif; ?>

							<div class="col-12 col-lg">
								<label class="form-label visually-hidden" for="vm-category-keyword">
									<?php echo vmText::_('COM_VIRTUEMART_SEARCH'); ?>
								</label>
								<div class="input-group">
									<input
										id="vm-category-keyword"
										name="keyword"
										class="form-control"
										type="text"
										value="<?php echo vRequest::vmSpecialChars($this->keyword); ?>"
										placeholder="<?php echo vmText::_('COM_VIRTUEMART_SEARCH'); ?>"
									>
									<button class="btn btn-primary" type="submit">
										<?php echo vmText::_('COM_VIRTUEMART_SEARCH'); ?>
									</button>
								</div>
							</div>

							<div class="col-12">
								<p class="vm-search-descr small text-muted mb-0">
									<?php echo vmText::_('COM_VM_SEARCH_DESC'); ?>
								</p>
							</div>

							<input type="hidden" name="view" value="category">
							<input type="hidden" name="option" value="com_virtuemart">
							<input type="hidden" name="virtuemart_category_id" value="<?php echo $categoryId; ?>">
							<input type="hidden" name="Itemid" value="<?php echo $this->Itemid; ?>">
						</form>
					</div>
				</div>

				<?php
				vmJsApi::addJScript('sendFormChange', 'jQuery(document).ready(function($) {
					$(".changeSendForm")
						.off("change", Virtuemart.sendCurrForm)
						.on("change", Virtuemart.sendCurrForm);
				})');
				?>
			<?php endif; ?>

			<?php if ($hasProducts && !empty($this->orderByList)) : ?>
			<div class="orderby-displaynumber card border-0 shadow-sm mb-4">
				<div class="card-body py-3">
					<?php
					// Temporarily hide VirtueMart's composite category ordering control.
					// It sorts by manual category position before product name, so its label is misleading.
					?>
					<?php if (!empty($this->orderByList['manufacturer'])) : ?>
						<div class="row g-3 align-items-end">
							<div class="col-12 col-md-4">
								<?php echo $this->orderByList['manufacturer']; ?>
							</div>
						</div>
					<?php endif; ?>

					<div class="vm-toolbar-controls d-flex flex-column flex-xl-row align-items-xl-center gap-3<?php echo !empty($this->orderByList['manufacturer']) ? ' border-top mt-3 pt-3' : ''; ?>">
							<div class="vm-results-controls d-flex flex-wrap align-items-center gap-2">
								<span class="small text-muted">
									<?php echo $this->vmPagination->getResultsCounter(); ?>
								</span>
								<?php echo str_replace('inputbox', 'form-select form-select-sm w-auto', $this->vmPagination->getLimitBox($this->category->limit_list_step)); ?>
							</div>

							<?php if ($this->vmPagination->getPagesCounter() !== null) : ?>
								<div class="vm-pagination vm-pagination-top float-none d-flex flex-wrap align-items-center gap-2 ms-xl-auto">
									<span class="vm-page-counter float-none d-inline-flex align-items-center small text-body-secondary py-1 px-2">
										<?php echo $this->vmPagination->getPagesCounter(); ?>
									</span>
									<?php echo $formatPagination($this->vmPagination->getPagesLinks()); ?>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php endif; ?>

			<?php if ($hasProducts) : ?>
				<?php
				if ($this->fallback) {
					$product = $this->products;
					$this->products = [$product];
					vmdebug('Refallback');
				}

				echo shopFunctionsF::renderVmSubLayout($this->productsLayout, [
					'products' => $this->products,
					'currency' => $this->currency,
					'products_per_row' => $this->perRow,
					'showRating' => $this->showRating,
				]);
				?>

				<?php if (!empty($this->orderByList) && $this->vmPagination->getPagesCounter() !== null) : ?>
					<div class="vm-pagination vm-pagination-bottom float-none card border-0 shadow-sm mt-5">
						<div class="card-body py-3 d-flex flex-column flex-lg-row gap-2 justify-content-between align-items-lg-center">
							<span class="vm-page-counter float-none d-inline-flex align-items-center small text-body-secondary py-1 px-2">
								<?php echo $this->vmPagination->getPagesCounter(); ?>
							</span>
							<?php echo $formatPagination($this->vmPagination->getPagesLinks()); ?>
						</div>
					</div>
				<?php endif; ?>
			<?php elseif ($this->keyword !== false) : ?>
				<div class="alert alert-info">
					<?php echo vmText::_('COM_VIRTUEMART_NO_RESULT') . ($this->keyword ? ' : (' . vRequest::vmSpecialChars($this->keyword) . ')' : ''); ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
</div>
