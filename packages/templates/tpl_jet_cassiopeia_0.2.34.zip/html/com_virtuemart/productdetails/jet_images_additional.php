<?php

/**
 *
 * Show the Jet Cassiopeia additional product images
 *
 * @package	VirtueMart
 * @subpackage
 * @author Max Milbers, Valerie Isaksen

 * @link https://virtuemart.net
 * @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * @version $Id: default_images.php 7784 2014-03-25 00:18:44Z Milbo $
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

?>
<div class="jet-gallery-thumbnails col-2 d-flex flex-column p-0 m-0" data-jet-gallery-thumbnails>
	<button class="jet-gallery-thumbnails__button" type="button" data-jet-gallery-previous aria-label="Immagini precedenti" hidden>
		<span aria-hidden="true">&#9650;</span>
	</button>

	<div class="jet-gallery-thumbnails__viewport" data-jet-gallery-viewport>
		<div class="additional-images d-flex flex-column align-items-stretch gap-2 p-0 m-0">
			<?php
			$start_image = 0;
			for ($i = $start_image; $i < count($this->product->images); $i++) {
				$image = $this->product->images[$i];
				$descr = '';
				?>
				<div class="w-100" data-jet-gallery-thumbnail>
					<div class="ratio ratio-1x1 overflow-hidden bg-body-tertiary">
						<?php
						$alt = $image->file_description ?: $image->file_meta;
						echo '<a href="' . htmlspecialchars($image->file_url, ENT_QUOTES, 'UTF-8') . '"'
							. ' class="product-image d-block w-100 h-100" data-jet-gallery-item'
							. ' data-pswp-alt="' . htmlspecialchars($alt, ENT_QUOTES, 'UTF-8') . '">';
						echo $image->displayMediaThumb('class="w-100 h-100 object-fit-cover m-0"', false, '', true, $descr);
						echo '</a>';
						?>
					</div>
				</div>
			<?php
			}
			?>
		</div>
	</div>

	<button class="jet-gallery-thumbnails__button" type="button" data-jet-gallery-next aria-label="Immagini successive" hidden>
		<span aria-hidden="true">&#9660;</span>
	</button>
</div>
