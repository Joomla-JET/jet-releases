<?php

defined('_JEXEC') or die;

require __DIR__ . '/jet_images_additional.php';
