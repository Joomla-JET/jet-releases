<?php

/**
 *
 * Show the Jet Cassiopeia main product image
 *
 * @package	VirtueMart
 * @subpackage
 * @author Max Milbers, Valerie Isaksen

 * @link https://virtuemart.net
 * @copyright Copyright (c) 2004 - 2010 VirtueMart Team. All rights reserved.
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL, see LICENSE.php
 * VirtueMart is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * @version $Id: default_images.php 10649 2022-05-05 14:29:44Z Milbo $
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');

if (!empty($this->product->images)) {
	$image = reset($this->product->images);
	$width = VmConfig::get('img_width_full', 0);
	$height = VmConfig::get('img_height_full', 0);

	if(!empty($image) and is_object($image)){
		?>
		<div class="main-image col position-relative d-flex flex-column align-items-center justify-content-center overflow-hidden p-0"<?php echo $height ? ' style="min-height:' . $height . 'px"' : '' ?>>
			<?php
			if(!empty($width) or !empty($height)){
				echo $image->displayMediaThumb('class="img-fluid w-100 h-auto"', true, 'class="d-block w-100" data-jet-gallery-main', true, true, false, $width, $height);
			} else {
				echo $image->displayMediaFull('class="img-fluid w-100 h-auto"', true, 'class="d-block w-100" data-jet-gallery-main');
			}
			?>
		</div>
		<?php
	}
}
?>
