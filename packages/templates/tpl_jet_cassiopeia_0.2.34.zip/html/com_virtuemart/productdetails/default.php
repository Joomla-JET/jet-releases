<?php

/**
 * Default product layout provided by Jet Cassiopeia.
 */

defined('_JEXEC') or die;

require __DIR__ . '/jet.php';
