<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\Registry\Registry;

return static function (Registry $params): string {
    $variables = [];
    $bodySize = $params->get('bodysize');
    $paragraphSize = $params->get('paragraphFontSize');
    $paragraphLineHeight = $params->get('paragraphLineHeight');

    if ($bodySize !== null && $bodySize !== '' && is_numeric($bodySize)) {
        $variables[] = '--body-font-size: ' . max(0.75, min(2.5, (float) $bodySize)) . 'rem;';
    }

    if ($paragraphSize !== null && $paragraphSize !== '' && is_numeric($paragraphSize)) {
        $variables[] = '--jet-paragraph-font-size: ' . max(0.75, min(2, (float) $paragraphSize)) . 'rem;';
    }

    if ($paragraphLineHeight !== null && $paragraphLineHeight !== '' && is_numeric($paragraphLineHeight)) {
        $variables[] = '--jet-paragraph-line-height: ' . max(1, min(2.5, (float) $paragraphLineHeight)) . ';';
    }

    for ($level = 1; $level <= 6; $level++) {
        $size = $params->get('h' . $level . 'size');
        $weight = $params->get('h' . $level . 'weight');
        $lineHeight = $params->get('h' . $level . 'lineheight');

        if ($size !== null && $size !== '' && is_numeric($size)) {
            $variables[] = '--h' . $level . 'size: ' . max(0.5, min(8, (float) $size)) . 'rem;';
        }

        if ($weight !== null && $weight !== '' && is_numeric($weight)) {
            $normalisedWeight = (int) $weight;

            if ($normalisedWeight >= 100 && $normalisedWeight <= 900 && $normalisedWeight % 100 === 0) {
                $variables[] = '--h' . $level . 'weight: ' . $normalisedWeight . ';';
            }
        }

        if ($lineHeight !== null && $lineHeight !== '' && is_numeric($lineHeight)) {
            $variables[] = '--h' . $level . 'lineheight: ' . max(0.8, min(3, (float) $lineHeight)) . ';';
        }
    }

    return implode("\n        ", $variables);
};
