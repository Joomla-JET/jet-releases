<?php

/**
 * JET package installer, embedded in each independently installable package.
 *
 * The build supplies the exact versioned ownership graph in managed-extensions.json.
 * Joomla installs the children; this script validates adoption and reconciles ownership
 * and update channels without changing extension settings or application data.
 */

declare(strict_types=1);

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

defined('_JEXEC') or die;

return new class () implements ServiceProviderInterface {
    /** Register a fresh installer with Joomla's database service. */
    public function register(Container $container): void
    {
        $container->set(
            InstallerScriptInterface::class,
            static fn (Container $container): InstallerScriptInterface => new class ($container->get(DatabaseInterface::class)) implements InstallerScriptInterface {
                /** @var list<array{element: string, type: string, folder: string, client_id: int, version: string, parent: ?string}> */
                private array $extensions = [];

                /** Receive services from the installer container instead of global factories. */
                public function __construct(private readonly DatabaseInterface $db)
                {
                }

                /** Let Joomla perform the actual child installation. */
                public function install(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Let Joomla preserve existing extension records during an upgrade. */
                public function update(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** The package manifest delegates removal, including data, to its children. */
                public function uninstall(InstallerAdapter $adapter): bool
                {
                    return true;
                }

                /** Reject unsupported runtimes, downgrades and foreign ownership before any child changes. */
                public function preflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type === 'uninstall') {
                        return true;
                    }

                    if (version_compare(PHP_VERSION, '8.3.0', '<') || version_compare(JVERSION, '6.0.0', '<')) {
                        throw new RuntimeException('JET packages require Joomla 6 and PHP 8.3 or later.');
                    }

                    $file = $adapter->getParent()->getPath('source') . '/managed-extensions.json';

                    if (!is_file($file) || !is_readable($file)) {
                        throw new RuntimeException('JET package ownership metadata is missing or unreadable.');
                    }

                    try {
                        $metadata = json_decode((string) file_get_contents($file), true, 512, JSON_THROW_ON_ERROR);
                    } catch (JsonException $error) {
                        throw new RuntimeException('JET package ownership metadata is invalid.', 0, $error);
                    }

                    $extensions = is_array($metadata) ? ($metadata['extensions'] ?? null) : null;
                    if (!is_array($extensions) || !array_is_list($extensions) || !$extensions) {
                        throw new RuntimeException('JET package ownership metadata is invalid.');
                    }
                    foreach ($extensions as $extension) {
                        if (!is_array($extension) || !isset($extension['element'], $extension['type'], $extension['folder'], $extension['client_id'], $extension['version'])
                            || !array_key_exists('parent', $extension)
                            || !is_string($extension['element']) || $extension['element'] === ''
                            || !is_string($extension['type']) || !is_string($extension['folder'])
                            || !is_int($extension['client_id']) || !is_string($extension['version']) || $extension['version'] === ''
                            || ($extension['parent'] !== null && !is_string($extension['parent']))) {
                            throw new RuntimeException('JET package ownership metadata is invalid.');
                        }
                    }
                    $this->extensions = $extensions;

                    if ($this->extensions[0]['element'] !== 'pkg_' . (string) $adapter->getManifest()->packagename) {
                        throw new RuntimeException('JET package ownership metadata does not match its manifest.');
                    }

                    $installed = $this->installedExtensions();

                    foreach ($this->extensions as $extension) {
                        $current = $installed[$this->key($extension)] ?? null;

                        if ($current === null) {
                            continue;
                        }

                        $cache   = json_decode($current->manifest_cache, true);
                        $version = $cache['version'] ?? '';

                        if ($version === '' || version_compare($version, $extension['version'], '>')) {
                            throw new RuntimeException('JET refuses a downgrade or an unknown installed version: ' . $extension['element']);
                        }

                        $owner = $extension['parent'] === null ? null : ($installed['package:' . $extension['parent'] . '::0'] ?? null);

                        if ((int) $current->package_id !== 0 && (int) $current->package_id !== (int) ($owner->extension_id ?? 0)) {
                            throw new RuntimeException('JET extension belongs to another package; update it through its owner: ' . $extension['element']);
                        }
                    }

                    return true;
                }

                /** Restore the declared hierarchy and remove obsolete standalone update associations. */
                public function postflight(string $type, InstallerAdapter $adapter): bool
                {
                    if ($type === 'uninstall') {
                        return true;
                    }

                    $installed = $this->installedExtensions();
                    $managedIds = [];

                    $this->db->transactionStart();

                    try {
                        foreach ($this->extensions as $extension) {
                            $current = $installed[$this->key($extension)] ?? null;

                            if ($current === null) {
                                throw new RuntimeException('JET constituent was not installed: ' . $extension['element']);
                            }

                            if ($extension['parent'] === null) {
                                continue;
                            }

                            $id           = (int) $current->extension_id;
                            $managedIds[] = $id;
                            $owner        = $installed['package:' . $extension['parent'] . '::0'] ?? null;

                            // A containing package is stored only after its children finish installing.
                            // Its own postflight will establish this outer relationship once it exists.
                            if ($owner === null && $extension === $this->extensions[0]) {
                                continue;
                            }

                            if ($owner === null) {
                                throw new RuntimeException('JET containing package is missing: ' . $extension['parent']);
                            }

                            $ownerId = (int) $owner->extension_id;
                            $query = $this->db->createQuery()
                                ->update($this->db->quoteName('#__extensions'))
                                ->set($this->db->quoteName('package_id') . ' = :owner')
                                ->where($this->db->quoteName('extension_id') . ' = :id')
                                ->bind(':owner', $ownerId, ParameterType::INTEGER)
                                ->bind(':id', $id, ParameterType::INTEGER);
                            $this->db->setQuery($query)->execute();
                        }

                        // Nested PackageAdapter listeners also see descendant installs and can flatten
                        // package_id. The loop above deliberately restores every edge of the graph.
                        $this->removeStandaloneUpdates($managedIds);
                        $this->db->transactionCommit();
                    } catch (Throwable $error) {
                        $this->db->transactionRollback();
                        throw new RuntimeException('JET package reconciliation failed: ' . $error->getMessage(), 0, $error);
                    }

                    return true;
                }

                /** Load all relevant identities, including an outer package, in one database query. */
                private function installedExtensions(): array
                {
                    $elements = array_column($this->extensions, 'element');

                    foreach ($this->extensions as $extension) {
                        if ($extension['parent'] !== null) {
                            $elements[] = $extension['parent'];
                        }
                    }

                    $elements = array_values(array_unique($elements));
                    $query = $this->db->createQuery()
                        ->select($this->db->quoteName(['extension_id', 'element', 'type', 'folder', 'client_id', 'package_id', 'manifest_cache']))
                        ->from($this->db->quoteName('#__extensions'))
                        ->whereIn($this->db->quoteName('element'), $elements, ParameterType::STRING);
                    $result = [];

                    foreach ($this->db->setQuery($query)->loadObjectList() as $row) {
                        $key = $this->key((array) $row);

                        if (isset($result[$key])) {
                            throw new RuntimeException('JET found duplicate installed extension identities: ' . $row->element);
                        }

                        $result[$key] = $row;
                    }

                    return $result;
                }

                /** Include folder and client so similarly named plugins cannot be confused. */
                private function key(array $extension): string
                {
                    return implode(':', [$extension['type'], $extension['element'], $extension['folder'], $extension['client_id']]);
                }

                /** Remove only managed associations; shared update sites must remain usable by other extensions. */
                private function removeStandaloneUpdates(array $ids): void
                {
                    if (!$ids) {
                        return;
                    }

                    $db = $this->db;
                    $query = $db->createQuery()
                        ->select('DISTINCT ' . $db->quoteName('update_site_id'))
                        ->from($db->quoteName('#__update_sites_extensions'))
                        ->whereIn($db->quoteName('extension_id'), $ids);
                    $sites = array_map('intval', $db->setQuery($query)->loadColumn());

                    foreach (['#__update_sites_extensions', '#__updates'] as $table) {
                        $query = $db->createQuery()->delete($db->quoteName($table))
                            ->whereIn($db->quoteName('extension_id'), $ids);
                        $db->setQuery($query)->execute();
                    }

                    if (!$sites) {
                        return;
                    }

                    $references = $db->createQuery()->select($db->quoteName('update_site_id'))
                        ->from($db->quoteName('#__update_sites_extensions'));
                    $query = $db->createQuery()->select($db->quoteName('update_site_id'))
                        ->from($db->quoteName('#__update_sites'))
                        ->whereIn($db->quoteName('update_site_id'), $sites)
                        ->where($db->quoteName('update_site_id') . ' NOT IN (' . $references . ')');
                    $orphans = array_map('intval', $db->setQuery($query)->loadColumn());

                    if (!$orphans) {
                        return;
                    }

                    foreach (['#__updates', '#__update_sites'] as $table) {
                        $query = $db->createQuery()->delete($db->quoteName($table))
                            ->whereIn($db->quoteName('update_site_id'), $orphans);
                        $db->setQuery($query)->execute();
                    }
                }
            }
        );
    }
};
