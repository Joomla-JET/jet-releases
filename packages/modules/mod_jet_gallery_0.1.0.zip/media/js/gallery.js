import PhotoSwipeLightbox from './photoswipe-lightbox.esm.min.js';

document.querySelectorAll('[data-jet-gallery]').forEach((gallery) => {
	const lightbox = new PhotoSwipeLightbox({
		gallery: gallery.querySelector('[data-gallery-grid]'),
		children: '[data-gallery-item]',
		pswpModule: () => import('./photoswipe.esm.min.js'),
	});

	lightbox.init();

	gallery.querySelectorAll('[data-gallery-filter]').forEach((filter) => {
		filter.addEventListener('click', () => {
			const selected = filter.dataset.galleryFilter;

			gallery.querySelectorAll('[data-gallery-filter]').forEach((button) => {
				const active = button === filter;
				button.classList.toggle('is-active', active);
				button.setAttribute('aria-pressed', active ? 'true' : 'false');
			});

			gallery.querySelectorAll('[data-gallery-item]').forEach((item) => {
				item.hidden = selected !== '*' && item.dataset.category !== selected;
			});
		});
	});
});