<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Uri\Uri;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var Joomla\Registry\Registry $params */
/** @var object $module */
/** @var array{images: array<int, array<string, mixed>>, categories: array<int, array{key: string, label: string}>} $gallery */

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_gallery');
$wa->useStyle('mod_jet_gallery.styles');
$wa->useScript('mod_jet_gallery.gallery');

$layout = in_array((string) $params->get('layout_type', 'card'), ['card', 'masonry'], true) ? (string) $params->get('layout_type', 'card') : 'card';
$columns = max(1, min(6, (int) $params->get('columns', 4)));
$ratio = in_array((string) $params->get('thumb_ratio', 'square'), ['square', 'landscape', 'portrait', 'natural'], true) ? (string) $params->get('thumb_ratio', 'square') : 'square';
$galleryId = 'jet-gallery-' . (int) $module->id;
$assetBase = rtrim(Uri::root(), '/') . '/media/mod_jet_gallery';
?>
<link rel="stylesheet" href="<?= htmlspecialchars($assetBase . '/css/photoswipe.css', ENT_QUOTES, 'UTF-8') ?>">
<link rel="stylesheet" href="<?= htmlspecialchars($assetBase . '/css/gallery.css', ENT_QUOTES, 'UTF-8') ?>">
<script type="module" src="<?= htmlspecialchars($assetBase . '/js/gallery.js', ENT_QUOTES, 'UTF-8') ?>"></script>
<div id="<?= htmlspecialchars($galleryId, ENT_QUOTES, 'UTF-8') ?>" class="mod-jet-gallery mod-jet-gallery--<?= $layout ?> mod-jet-gallery--ratio-<?= $ratio ?> <?= htmlspecialchars(trim((string) $params->get('moduleclass_sfx', '')), ENT_QUOTES, 'UTF-8') ?>" style="--jet-gallery-columns: <?= $columns ?>" data-jet-gallery>
	<?php if ((bool) $params->get('show_filters', true) && $gallery['categories'] !== []) : ?>
		<nav class="mod-jet-gallery__filters" aria-label="<?= htmlspecialchars(Text::_('MOD_JET_GALLERY_FILTER_LABEL'), ENT_QUOTES, 'UTF-8') ?>">
			<button type="button" class="mod-jet-gallery__filter is-active" data-gallery-filter="*" aria-pressed="true"><?= htmlspecialchars(Text::_('MOD_JET_GALLERY_ALL'), ENT_QUOTES, 'UTF-8') ?></button>
			<?php foreach ($gallery['categories'] as $category) : ?>
				<button type="button" class="mod-jet-gallery__filter" data-gallery-filter="<?= htmlspecialchars($category['key'], ENT_QUOTES, 'UTF-8') ?>" aria-pressed="false"><?= htmlspecialchars($category['label'], ENT_QUOTES, 'UTF-8') ?></button>
			<?php endforeach; ?>
		</nav>
	<?php endif; ?>

	<div class="mod-jet-gallery__grid" data-gallery-grid>
		<?php foreach ($gallery['images'] as $image) : ?>
			<a class="mod-jet-gallery__item" href="<?= htmlspecialchars($image['src'], ENT_QUOTES, 'UTF-8') ?>" data-gallery-item data-category="<?= htmlspecialchars($image['category'], ENT_QUOTES, 'UTF-8') ?>" data-pswp-width="<?= (int) $image['width'] ?>" data-pswp-height="<?= (int) $image['height'] ?>" data-pswp-caption="<?= htmlspecialchars($image['description'], ENT_QUOTES, 'UTF-8') ?>">
				<img src="<?= htmlspecialchars($image['src'], ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($image['alt'], ENT_QUOTES, 'UTF-8') ?>" loading="lazy" decoding="async">
				<?php if ($image['title'] !== '' || $image['description'] !== '') : ?>
					<span class="mod-jet-gallery__caption">
						<?php if ($image['title'] !== '') : ?><strong><?= htmlspecialchars($image['title'], ENT_QUOTES, 'UTF-8') ?></strong><?php endif; ?>
						<?php if ($image['description'] !== '') : ?><span><?= htmlspecialchars($image['description'], ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
					</span>
				<?php endif; ?>
			</a>
		<?php endforeach; ?>
	</div>
</div>