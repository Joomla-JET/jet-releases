<?php

declare(strict_types=1);

namespace Joomla\Module\JetGallery\Site\Helper;

defined('_JEXEC') or die;

use Joomla\CMS\Uri\Uri;
use Joomla\Registry\Registry;

final class GalleryHelper
{
	private const IMAGE_EXTENSIONS = ['avif', 'gif', 'jpeg', 'jpg', 'png', 'webp'];

	/**
	 * @return array{images: array<int, array<string, mixed>>, categories: array<int, array{key: string, label: string}>}
	 */
	public function getGallery(Registry $params): array
	{
		$root = realpath(JPATH_ROOT . '/images');
		$selected = trim((string) $params->get('source_folder', 'images'), "/\\");
		$folder = realpath(JPATH_ROOT . '/' . $selected);

		if ($root === false || $folder === false || !$this->isWithin($folder, $root)) {
			return ['images' => [], 'categories' => []];
		}

		$metadata = $this->decodeParameterMetadata($params);
		if ($metadata === []) {
			$metadata = $this->readMetadata($folder);
		}
		$images = [];
		$categories = [];
		$categoryKeys = [];

		$iterator = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator($folder, \FilesystemIterator::SKIP_DOTS)
		);

		foreach ($iterator as $file) {
			if (!$file->isFile() || !in_array(strtolower($file->getExtension()), self::IMAGE_EXTENSIONS, true)) {
				continue;
			}

			$absolutePath = $file->getPathname();
			$relativePath = ltrim(str_replace('\\', '/', substr($absolutePath, strlen($folder))), '/');
			$directory = dirname($relativePath);
			$category = $directory === '.' ? '' : $directory;

			if ($category !== '' && !isset($categoryKeys[$category])) {
				$categoryKeys[$category] = true;
				$categories[] = ['key' => $category, 'label' => str_replace('/', ' / ', $category)];
			}

			$details = is_array($metadata[$relativePath] ?? null) ? $metadata[$relativePath] : [];
			$dimensions = @getimagesize($absolutePath);
			$images[] = [
				'src' => $this->toUrl($selected . '/' . $relativePath),
				'width' => (int) ($dimensions[0] ?? 1),
				'height' => (int) ($dimensions[1] ?? 1),
				'category' => $category,
				'title' => trim((string) ($details['title'] ?? '')),
				'description' => trim((string) ($details['description'] ?? '')),
				'alt' => trim((string) ($details['alt'] ?? $this->fallbackTitle($file->getFilename()))),
			];
		}

		usort($images, static fn (array $first, array $second): int => strnatcasecmp($first['src'], $second['src']));

		return ['images' => $images, 'categories' => $categories];
	}

	private function readMetadata(string $folder): array
	{
		$metadataFile = $folder . '/jet-gallery.json';

		if (!is_file($metadataFile)) {
			return [];
		}

		$data = json_decode((string) file_get_contents($metadataFile), true);

		return is_array($data) ? $data : [];
	}

	private function decodeParameterMetadata(Registry $params): array
	{
		$value = $params->get('gallery_metadata', '');
		$decoded = json_decode(is_string($value) ? $value : '', true);

		return is_array($decoded) ? $decoded : [];
	}

	private function isWithin(string $path, string $root): bool
	{
		return $path === $root || str_starts_with($path, $root . DIRECTORY_SEPARATOR);
	}

	private function toUrl(string $path): string
	{
		$segments = array_map('rawurlencode', explode('/', str_replace('\\', '/', ltrim($path, '/'))));

		return rtrim(Uri::root(), '/') . '/' . implode('/', $segments);
	}

	private function fallbackTitle(string $filename): string
	{
		return trim(str_replace(['_', '-'], ' ', pathinfo($filename, PATHINFO_FILENAME)));
	}
}