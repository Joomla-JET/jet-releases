<?php

declare(strict_types=1);

namespace Joomla\Module\JetGallery\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
	use HelperFactoryAwareTrait;

	protected function getLayoutData(): array|false
	{
		$data = parent::getLayoutData();
		$gallery = $this->getHelperFactory()->getHelper('GalleryHelper')->getGallery($data['params']);

		if ($gallery['images'] === []) {
			return false;
		}

		$data['gallery'] = $gallery;

		return $data;
	}
}