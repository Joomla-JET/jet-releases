<?php

declare(strict_types=1);

namespace Joomla\Module\JetGallery\Site\Field;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\CMS\Uri\Uri;

final class GallerymetadataField extends FormField
{
	protected $type = 'Gallerymetadata';

	protected function getInput(): string
	{
		$folder = trim((string) $this->form->getValue((string) $this->element['source'], 'params'), "/\\");
		$root = realpath(JPATH_ROOT . '/images');
		$path = realpath(JPATH_ROOT . '/' . $folder);
		$metadata = $this->decodeValue((string) $this->value);
		$rows = [];

		if ($root !== false && $path !== false && ($path === $root || str_starts_with($path, $root . DIRECTORY_SEPARATOR))) {
			$iterator = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($path, \FilesystemIterator::SKIP_DOTS));

			foreach ($iterator as $file) {
				if (!$file->isFile() || !in_array(strtolower($file->getExtension()), ['avif', 'gif', 'jpeg', 'jpg', 'png', 'webp'], true)) {
					continue;
				}

				$relative = ltrim(str_replace('\\', '/', substr($file->getPathname(), strlen($path))), '/');
				$details = is_array($metadata[$relative] ?? null) ? $metadata[$relative] : [];
				$rows[] = [
					'path' => $relative,
					'title' => (string) ($details['title'] ?? ''),
					'description' => (string) ($details['description'] ?? ''),
					'alt' => (string) ($details['alt'] ?? ''),
				];
			}
		}

		if ($rows === []) {
			return '<p class="alert alert-info">' . htmlspecialchars((string) Factory::getApplication()->getLanguage()->_('MOD_JET_GALLERY_METADATA_EMPTY'), ENT_QUOTES, 'UTF-8') . '</p>';
		}

		$inputId = htmlspecialchars($this->id, ENT_QUOTES, 'UTF-8');
		$metadataJson = htmlspecialchars((string) json_encode(array_column($rows, null, 'path'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8');
		$folderUrl = rtrim(Uri::root(), '/') . '/' . trim($folder, "/\\");
		$html = '<div class="mod-jet-gallery-metadata" data-gallery-metadata-editor data-gallery-root="' . htmlspecialchars($folderUrl, ENT_QUOTES, 'UTF-8') . '">';
		$html .= '<p class="form-text">' . htmlspecialchars((string) Factory::getApplication()->getLanguage()->_('MOD_JET_GALLERY_METADATA_FIELDS_DESC'), ENT_QUOTES, 'UTF-8') . '</p>';
		$html .= '<input type="hidden" id="' . $inputId . '" name="' . htmlspecialchars($this->name, ENT_QUOTES, 'UTF-8') . '" value="' . $metadataJson . '" data-gallery-metadata-input>';

		foreach ($rows as $row) {
			$pathValue = htmlspecialchars($row['path'], ENT_QUOTES, 'UTF-8');
			$html .= '<fieldset class="mod-jet-gallery-metadata__item"><legend>' . $pathValue . '</legend><img src="' . htmlspecialchars($folderUrl . '/' . implode('/', array_map('rawurlencode', explode('/', $row['path']))), ENT_QUOTES, 'UTF-8') . '" alt="" loading="lazy">';
			$html .= '<div><label>' . htmlspecialchars((string) Factory::getApplication()->getLanguage()->_('MOD_JET_GALLERY_METADATA_TITLE'), ENT_QUOTES, 'UTF-8') . '<input type="text" value="' . htmlspecialchars($row['title'], ENT_QUOTES, 'UTF-8') . '" data-metadata-key="' . $pathValue . '" data-metadata-field="title"></label>';
			$html .= '<label>' . htmlspecialchars((string) Factory::getApplication()->getLanguage()->_('MOD_JET_GALLERY_METADATA_DESCRIPTION'), ENT_QUOTES, 'UTF-8') . '<textarea rows="2" data-metadata-key="' . $pathValue . '" data-metadata-field="description">' . htmlspecialchars($row['description'], ENT_QUOTES, 'UTF-8') . '</textarea></label>';
			$html .= '<label>' . htmlspecialchars((string) Factory::getApplication()->getLanguage()->_('MOD_JET_GALLERY_METADATA_ALT'), ENT_QUOTES, 'UTF-8') . '<input type="text" value="' . htmlspecialchars($row['alt'], ENT_QUOTES, 'UTF-8') . '" data-metadata-key="' . $pathValue . '" data-metadata-field="alt"></label></div></fieldset>';
		}

		$html .= '<script>document.querySelectorAll("[data-gallery-metadata-editor]").forEach((editor) => { const hidden = editor.querySelector("[data-gallery-metadata-input]"); const update = () => { const data = {}; editor.querySelectorAll("[data-metadata-key]").forEach((field) => { const key = field.dataset.metadataKey; data[key] ??= {}; data[key][field.dataset.metadataField] = field.value; }); hidden.value = JSON.stringify(data); }; editor.querySelectorAll("[data-metadata-key]").forEach((field) => field.addEventListener("input", update)); });</script></div>';

		return $html;
	}

	private function decodeValue(string $value): array
	{
		$decoded = json_decode($value, true);

		return is_array($decoded) ? $decoded : [];
	}
}