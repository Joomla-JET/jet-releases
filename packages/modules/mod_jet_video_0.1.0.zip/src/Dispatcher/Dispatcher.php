<?php

declare(strict_types=1);

namespace Joomla\Module\JetVideo\Site\Dispatcher;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;

defined('_JEXEC') or die;

final class Dispatcher extends AbstractModuleDispatcher
{
	protected function getLayoutData(): array
	{
		$data    = parent::getLayoutData();
		$videoId = $this->extractVideoId((string) $data['params']->get('video_url', ''));

		$data['embedUrl'] = $videoId === ''
			? ''
			: 'https://www.youtube-nocookie.com/embed/' . rawurlencode($videoId);

		return $data;
	}

	private function extractVideoId(string $url): string
	{
		$url = trim($url);

		if ($url === '') {
			return '';
		}

		$parts = parse_url($url);

		if (!is_array($parts) || !isset($parts['host'])) {
			return '';
		}

		$host      = strtolower(rtrim((string) $parts['host'], '.'));
		$path      = trim((string) ($parts['path'] ?? ''), '/');
		$segments  = $path === '' ? [] : explode('/', $path);
		$videoId   = '';
		$youtubeHosts = [
			'youtube.com',
			'www.youtube.com',
			'm.youtube.com',
			'music.youtube.com',
			'youtube-nocookie.com',
			'www.youtube-nocookie.com',
		];

		if ($host === 'youtu.be' || $host === 'www.youtu.be') {
			$videoId = $segments[0] ?? '';
		} elseif (in_array($host, $youtubeHosts, true)) {
			if (($segments[0] ?? '') === 'watch') {
				parse_str((string) ($parts['query'] ?? ''), $query);
				$videoId = is_string($query['v'] ?? null) ? $query['v'] : '';
			} elseif (in_array($segments[0] ?? '', ['embed', 'shorts', 'live'], true)) {
				$videoId = $segments[1] ?? '';
			}
		}

		return preg_match('/^[A-Za-z0-9_-]{11}$/D', $videoId) === 1 ? $videoId : '';
	}
}
