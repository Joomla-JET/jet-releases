<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var Joomla\Registry\Registry $params */
/** @var string $embedUrl */

if ($embedUrl === '') {
	return;
}

$app->getDocument()
	->getWebAssetManager()
	->registerAndUseStyle(
		'mod_jet_video.style',
		'mod_jet_video/video.css',
		['version' => 'auto']
	);

$moduleClass = trim('mod-jet-video ' . (string) $params->get('moduleclass_sfx', ''));
?>
<div class="<?= htmlspecialchars($moduleClass, ENT_COMPAT, 'UTF-8') ?>">
	<iframe
		class="mod-jet-video__frame"
		src="<?= htmlspecialchars($embedUrl, ENT_COMPAT, 'UTF-8') ?>"
		title="<?= htmlspecialchars(Text::_('MOD_JET_VIDEO_IFRAME_TITLE'), ENT_COMPAT, 'UTF-8') ?>"
		loading="lazy"
		referrerpolicy="strict-origin-when-cross-origin"
		allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
		allowfullscreen
	></iframe>
</div>
