<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Field;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ModulelayoutField;

defined('_JEXEC') or die;

final class JetMenuLayoutField extends ModulelayoutField
{
	protected $type = 'JetMenuLayout';

	protected function getInput()
	{
		$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
		$wa->getRegistry()->addExtensionRegistryFile('mod_jet_menu');
		$wa->useScript('mod_jet_menu.admin-layout');

		return parent::getInput();
	}
}
