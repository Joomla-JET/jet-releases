<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Field;

use Joomla\CMS\Form\Field\NumberField;

defined('_JEXEC') or die;

final class HeaderVerticalOffsetField extends NumberField
{
	use HorizontalHeaderAwareTrait;

	protected $type = 'HeaderVerticalOffset';

	protected function getInput(): string
	{
		if ($this->isHorizontalHeaderEnabled()) {
			return parent::getInput();
		}

		$this->disabled = true;

		return $this->preserveDisabledValue(parent::getInput());
	}
}
