<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Field;

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;
use Joomla\Registry\Registry;
use Throwable;

defined('_JEXEC') or die;

trait HorizontalHeaderAwareTrait
{
	private function isHorizontalHeaderEnabled(): bool
	{
		try {
			$db = Factory::getContainer()->get(DatabaseInterface::class);
			$query = $db->getQuery(true)
				->select([
					$db->quoteName('template'),
					$db->quoteName('params'),
				])
				->from($db->quoteName('#__template_styles'))
				->where($db->quoteName('client_id') . ' = 0')
				->where($db->quoteName('home') . ' = ' . $db->quote('1'));

			$style = $db->setQuery($query, 0, 1)->loadObject();

			if ($style === null || $style->template !== 'jet_cassiopeia') {
				return false;
			}

			return (int) (new Registry($style->params))->get('horizontalHeader', 0) === 1;
		} catch (Throwable) {
			return false;
		}
	}

	private function preserveDisabledValue(string $input): string
	{
		return $input . sprintf(
			'<input type="hidden" name="%s" value="%s">',
			htmlspecialchars($this->name, ENT_QUOTES, 'UTF-8'),
			htmlspecialchars((string) $this->value, ENT_QUOTES, 'UTF-8')
		);
	}
}
