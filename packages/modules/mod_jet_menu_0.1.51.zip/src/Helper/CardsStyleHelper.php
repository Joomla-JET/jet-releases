<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Helper;

use Joomla\Registry\Registry;

defined('_JEXEC') or die;

final class CardsStyleHelper
{
	/** Build only validated, module-scoped overrides; empty values use the CSS defaults. */
	public static function getStyle(Registry $params): string
	{
		$variables = [];

		$colours = [
			'text_color'       => 'ink',
			'background'       => 'surface',
			'hover_text_color' => 'hover-ink',
			'hover_background' => 'hover-surface',
			'border_color'     => 'line',
			'accent_color'     => 'accent',
			'image_background' => 'image-surface',
		];

		foreach ($colours as $param => $variable) {
			$value = trim((string) $params->get('cards_' . $param, ''));

			if (preg_match('/\A#(?:[0-9a-f]{3}|[0-9a-f]{6})\z/i', $value)) {
				$variables[] = '--jet-menu-cards-' . $variable . ': ' . $value;
			}
		}

		$numbers = [
			'columns_desktop' => ['columns-desktop', 1, 6, ''],
			'columns_tablet'  => ['columns-tablet', 1, 4, ''],
			'columns_mobile'  => ['columns-mobile', 1, 2, ''],
			'gap'            => ['gap', 0, 64, 'px'],
			'padding'        => ['padding', 0, 64, 'px'],
			'radius'         => ['radius', 0, 64, 'px'],
			'border_width'   => ['border-width', 0, 4, 'px'],
			'image_height'   => ['image-height', 80, 600, 'px'],
			'font_size'      => ['font-size', 0, 48, 'px'],
		];

		foreach ($numbers as $param => [$variable, $min, $max, $unit]) {
			$value = $params->get('cards_' . $param);

			if ($value === null || $value === '' || !is_numeric($value)) {
				continue;
			}

			$value = max($min, min($max, (int) $value));

			if ($param === 'font_size' && $value === 0) {
				continue;
			}

			$variables[] = '--jet-menu-cards-' . $variable . ': ' . $value . $unit;
		}

		$choices = [
			'image_fit'   => ['image-fit', ['contain', 'cover']],
			'text_align'  => ['text-align', ['start', 'center', 'end']],
			'font_weight' => ['font-weight', ['300', '400', '500', '600', '700']],
		];

		foreach ($choices as $param => [$variable, $allowed]) {
			$value = (string) $params->get('cards_' . $param, '');

			if (in_array($value, $allowed, true)) {
				$variables[] = '--jet-menu-cards-' . $variable . ': ' . $value;
			}
		}

		$zoomAmount = (int) $params->get('cards_image_zoom_amount', 8);
		$zoomAmount = max(1, min(30, $zoomAmount));
		$zoomScale  = (int) $params->get('cards_image_zoom', 1) === 1
			? 1 + ($zoomAmount / 100)
			: 1;

		$variables[] = '--jet-menu-cards-image-zoom: ' . rtrim(rtrim(number_format($zoomScale, 2, '.', ''), '0'), '.');

		return implode('; ', $variables);
	}
}
