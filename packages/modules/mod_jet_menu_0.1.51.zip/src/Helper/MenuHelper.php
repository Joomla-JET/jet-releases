<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Helper;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\CMS\Cache\CacheControllerFactoryInterface;
use Joomla\CMS\Cache\Controller\OutputController;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Router\Route;
use Joomla\Registry\Registry;

defined('_JEXEC') or die;

final class MenuHelper
{
	public function getItems(Registry &$params, CMSApplicationInterface $app): array
	{
		$menu   = $app->getMenu();
		$base   = $this->getBaseItem($params, $app);
		$levels = $app->getIdentity()->getAuthorisedViewLevels();

		asort($levels);

		$cacheKey = 'jet_menu_items' . $params . implode(',', $levels) . '.' . $base->id;

		/** @var OutputController $cache */
		$cache = Factory::getContainer()->get(CacheControllerFactoryInterface::class)
			->createCacheController('output', ['defaultgroup' => 'mod_jet_menu']);

		if ($cache->contains($cacheKey)) {
			return $cache->get($cacheKey);
		}

		$path           = $base->tree;
		$start          = (int) $params->get('startLevel', 1);
		$end            = (int) $params->get('endLevel', 0);
		$showAll        = (int) $params->get('showAllChildren', 1);
		$items          = $menu->getItems('menutype', $params->get('menutype'));
		$hiddenParents  = [];
		$lastItem       = 0;

		if ($items) {
			$inputVars = $app->getInput()->getArray();

			foreach ($items as $i => $item) {
				$item->parent = false;
				$itemParams   = $item->getParams();

				if (isset($items[$lastItem]) && $items[$lastItem]->id == $item->parent_id && (int) $itemParams->get('menu_show', 1) === 1) {
					$items[$lastItem]->parent = true;
				}

				if (
					($start && $start > $item->level)
					|| ($end && $item->level > $end)
					|| (!$showAll && $item->level > 1 && !in_array($item->parent_id, $path))
					|| ($start > 1 && !in_array($item->tree[$start - 2], $path))
				) {
					unset($items[$i]);
					continue;
				}

				if (((int) $itemParams->get('menu_show', 1) === 0) || in_array($item->parent_id, $hiddenParents)) {
					$hiddenParents[] = $item->id;
					unset($items[$i]);
					continue;
				}

				$item->current = true;

				foreach ($item->query as $key => $value) {
					if (!isset($inputVars[$key]) || $inputVars[$key] !== $value) {
						$item->current = false;
						break;
					}
				}

				$item->deeper     = false;
				$item->shallower  = false;
				$item->level_diff = 0;

				if (isset($items[$lastItem])) {
					$items[$lastItem]->deeper     = $item->level > $items[$lastItem]->level;
					$items[$lastItem]->shallower  = $item->level < $items[$lastItem]->level;
					$items[$lastItem]->level_diff = $items[$lastItem]->level - $item->level;
				}

				$lastItem     = $i;
				$item->active = false;
				$item->flink  = $item->link;

				switch ($item->type) {
					case 'separator':
					case 'heading':
						break;

					case 'url':
						if (str_starts_with($item->link, 'index.php?') && !str_contains($item->link, 'Itemid=')) {
							$item->flink = $item->link . '&Itemid=' . $item->id;
						}
						break;

					case 'alias':
						$item->flink = 'index.php?Itemid=' . $itemParams->get('aliasoptions');

						if (Multilanguage::isEnabled()) {
							$newItem = $app->getMenu()->getItem((int) $itemParams->get('aliasoptions'));

							if ($newItem !== null && $newItem->language && $newItem->language !== '*') {
								$item->flink .= '&lang=' . $newItem->language;
							}
						}
						break;

					default:
						$item->flink = 'index.php?Itemid=' . $item->id;
						break;
				}

				if (str_contains($item->flink, 'index.php?') && strcasecmp(substr($item->flink, 0, 4), 'http')) {
					$item->flink = Route::_($item->flink, true, $itemParams->get('secure'));
				} else {
					$item->flink = Route::_($item->flink);
				}

				$item->title          = htmlspecialchars($item->title, ENT_COMPAT, 'UTF-8', false);
				$item->menu_icon      = htmlspecialchars((string) $itemParams->get('menu_icon_css', ''), ENT_COMPAT, 'UTF-8', false);
				$item->anchor_css     = htmlspecialchars((string) $itemParams->get('menu-anchor_css', ''), ENT_COMPAT, 'UTF-8', false);
				$item->anchor_title   = htmlspecialchars((string) $itemParams->get('menu-anchor_title', ''), ENT_COMPAT, 'UTF-8', false);
				$item->anchor_rel     = htmlspecialchars((string) $itemParams->get('menu-anchor_rel', ''), ENT_COMPAT, 'UTF-8', false);
				$item->menu_image     = htmlspecialchars((string) $itemParams->get('menu_image', ''), ENT_COMPAT, 'UTF-8', false);
				$item->menu_image_css = htmlspecialchars((string) $itemParams->get('menu_image_css', ''), ENT_COMPAT, 'UTF-8', false);
			}

			if (isset($items[$lastItem])) {
				$items[$lastItem]->deeper     = ($start ?: 1) > $items[$lastItem]->level;
				$items[$lastItem]->shallower  = ($start ?: 1) < $items[$lastItem]->level;
				$items[$lastItem]->level_diff = $items[$lastItem]->level - ($start ?: 1);
			}
		}

		$cache->store($items, $cacheKey);

		return $items ?: [];
	}

	public function getBaseItem(Registry &$params, CMSApplicationInterface $app): object
	{
		$base = $params->get('base') ? $app->getMenu()->getItem($params->get('base')) : false;

		return $base ?: $this->getActiveItem($app);
	}

	public function getActiveItem(CMSApplicationInterface $app): object
	{
		return $app->getMenu()->getActive() ?: $this->getDefaultItem($app);
	}

	public function getDefaultItem(CMSApplicationInterface $app): object
	{
		if (Multilanguage::isEnabled()) {
			return $app->getMenu()->getDefault($app->getLanguage()->getTag());
		}

		return $app->getMenu()->getDefault();
	}
}
