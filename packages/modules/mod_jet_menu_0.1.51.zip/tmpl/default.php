<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;
use Joomla\Filter\OutputFilter;
use Joomla\Registry\Registry;
use Joomla\Utilities\ArrayHelper;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var Registry $params */
/** @var array $list */
/** @var int $active_id */
/** @var int $default_id */
/** @var array $path */
/** @var int $showAll */
/** @var string $class_sfx */

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_menu');
$wa->useStyle('mod_jet_menu.flyout')
	->useScript('mod_jet_menu.flyout');

$styleVars = [];

$hexToRgba = static function (string $hex, float $alpha): ?string {
	$hex = ltrim(trim($hex), '#');

	if (strlen($hex) === 3) {
		$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
	}

	if (strlen($hex) !== 6 || !ctype_xdigit($hex)) {
		return null;
	}

	$red   = hexdec(substr($hex, 0, 2));
	$green = hexdec(substr($hex, 2, 2));
	$blue  = hexdec(substr($hex, 4, 2));

	return 'rgba(' . $red . ', ' . $green . ', ' . $blue . ', ' . number_format($alpha, 2, '.', '') . ')';
};

$colorParams = [
	'accent_color'      => '--jet-menu-accent',
	'accent_text_color' => '--jet-menu-accent-color',
	'top_text_color'    => '--jet-menu-link-color',
	'panel_background'  => '--jet-menu-panel-bg',
	'panel_text_color'  => '--jet-menu-panel-color',
];

foreach ($colorParams as $paramName => $cssVar) {
	$value = trim((string) $params->get($paramName, ''));

	if ($value !== '') {
		$styleVars[] = $cssVar . ': ' . htmlspecialchars($value, ENT_COMPAT, 'UTF-8') . ';';
	}
}

$panelBackground = trim((string) $params->get('panel_background', '#212529'));
$panelOpacity    = max(0, min(100, (int) $params->get('panel_opacity', 100)));
$panelRgba       = $hexToRgba($panelBackground, $panelOpacity / 100);
$mobilePanelOpacity = max(0, min(100, (int) $params->get('mobile_panel_opacity', 100)));
$mobilePanelRgba = $hexToRgba($panelBackground, $mobilePanelOpacity / 100);

if ($panelRgba !== null) {
	$styleVars[] = '--jet-menu-panel-bg-effective: ' . $panelRgba . ';';
}

if ($mobilePanelRgba !== null) {
	$styleVars[] = '--jet-menu-mobile-panel-bg-effective: ' . $mobilePanelRgba . ';';
}

$accentColor = trim((string) $params->get('accent_color', ''));

if ($accentColor !== '') {
	$escapedAccent = htmlspecialchars($accentColor, ENT_COMPAT, 'UTF-8');
	$styleVars[] = '--jet-menu-link-hover-bg: ' . $escapedAccent . ';';
	$styleVars[] = '--jet-menu-panel-hover-bg: ' . $escapedAccent . ';';
	$styleVars[] = '--jet-menu-panel-active-border: ' . $escapedAccent . ';';
}

$accentTextColor = trim((string) $params->get('accent_text_color', '#ffffff'));

if ($accentTextColor !== '') {
	$escapedAccentText = htmlspecialchars($accentTextColor, ENT_COMPAT, 'UTF-8');
	$styleVars[] = '--jet-menu-link-hover-color: ' . $escapedAccentText . ';';
	$styleVars[] = '--jet-menu-panel-hover-color: ' . $escapedAccentText . ';';
}

$topFontSize    = max(0, min(48, (int) $params->get('top_font_size', 0)));
$childFontSize  = max(0, min(48, (int) $params->get('child_font_size', 0)));
$topFontWeight  = (int) $params->get('top_font_weight', 700);
$childFontWeight = (int) $params->get('child_font_weight', 400);
$topItemGap     = max(0, min(64, (int) $params->get('top_item_gap', 4)));
$childItemGap   = max(0, min(64, (int) $params->get('child_item_gap', 6)));
$topPaddingX    = max(0, min(64, (int) $params->get('top_padding_x', 6)));
$topPaddingY    = max(0, min(64, (int) $params->get('top_padding_y', 12)));
$childPaddingX  = max(0, min(64, (int) $params->get('child_padding_x', 15)));
$childPaddingY  = max(0, min(64, (int) $params->get('child_padding_y', 11)));
$panelGap       = max(0, min(64, (int) $params->get('panel_gap', 6)));
$panelMinWidth  = max(160, min(800, (int) $params->get('panel_min_width', 270)));
$panelRadius    = max(0, min(64, (int) $params->get('panel_radius', 6)));
$topItemRadius  = max(0, min(64, (int) $params->get('top_item_radius', 0)));
$headerVerticalOffset = max(-128, min(128, (int) $params->get('header_vertical_offset', 0)));

$topFontWeight   = in_array($topFontWeight, [300, 400, 500, 600, 700], true) ? $topFontWeight : 700;
$childFontWeight = in_array($childFontWeight, [300, 400, 500, 600, 700], true) ? $childFontWeight : 400;

$styleVars[]   = '--jet-menu-top-font-size: ' . ($topFontSize === 0 ? 'inherit' : $topFontSize . 'px') . ';';
$styleVars[]   = '--jet-menu-child-font-size: ' . ($childFontSize === 0 ? 'inherit' : $childFontSize . 'px') . ';';
$styleVars[]   = '--jet-menu-top-font-weight: ' . $topFontWeight . ';';
$styleVars[]   = '--jet-menu-child-font-weight: ' . $childFontWeight . ';';
$styleVars[]   = '--jet-menu-top-text-transform: ' . ((int) $params->get('top_text_uppercase', 0) === 1 ? 'uppercase' : 'none') . ';';
$styleVars[]   = '--jet-menu-child-text-transform: ' . ((int) $params->get('child_text_uppercase', 0) === 1 ? 'uppercase' : 'none') . ';';
$styleVars[]   = '--jet-menu-top-item-gap: ' . $topItemGap . 'px;';
$styleVars[]   = '--jet-menu-child-item-gap: ' . $childItemGap . 'px;';
$styleVars[]   = '--jet-menu-top-link-padding-x: ' . $topPaddingX . 'px;';
$styleVars[]   = '--jet-menu-top-link-padding-y: ' . $topPaddingY . 'px;';
$styleVars[]   = '--jet-menu-panel-link-padding-x: ' . $childPaddingX . 'px;';
$styleVars[]   = '--jet-menu-panel-link-padding-y: ' . $childPaddingY . 'px;';
$styleVars[]   = '--jet-menu-panel-gap: ' . $panelGap . 'px;';
$styleVars[]   = '--jet-menu-panel-min-width: ' . $panelMinWidth . 'px;';
$styleVars[]   = '--jet-menu-panel-border-radius: ' . $panelRadius . 'px;';
$styleVars[]   = '--jet-menu-top-item-border-radius: ' . $topItemRadius . 'px;';
$styleVars[]   = '--jet-menu-header-offset: ' . $headerVerticalOffset . 'px;';

$topActiveStyle = (string) $params->get('top_active_style', 'pill');
$topActiveStyle = in_array($topActiveStyle, ['none', 'pill', 'line'], true) ? $topActiveStyle : 'pill';
$headerVerticalAlignment = (string) $params->get('header_vertical_alignment', 'default');
$headerVerticalAlignment = in_array($headerVerticalAlignment, ['default', 'start', 'center', 'end', 'custom'], true)
	? $headerVerticalAlignment
	: 'default';

$attributes = [
	'class'             => trim('mod-menu mod-jet-menu mod-list nav ' . $class_sfx),
	'data-active-style' => $topActiveStyle,
	'data-header-vertical-align' => $headerVerticalAlignment,
	'data-align'        => in_array($params->get('top_alignment', 'start'), ['start', 'center', 'end'], true)
		? $params->get('top_alignment', 'start')
		: 'start',
];

$tagId = trim((string) $params->get('tag_id', ''));
$attributes['id'] = $tagId !== '' ? $tagId : 'jet-menu-' . (int) $module->id;

if ($styleVars) {
	$attributes['style'] = implode(' ', $styleVars);
}

$start = (int) $params->get('startLevel', 1);
$mobileToggleLabel = Text::_('MOD_JET_MENU_TOGGLE_LABEL');
$mobileToggleColor = trim((string) $params->get('mobile_toggle_color', ''));
$mobileToggleStyle = $mobileToggleColor !== ''
	? '--jet-menu-toggle-color: ' . htmlspecialchars($mobileToggleColor, ENT_COMPAT, 'UTF-8') . ';'
	: '';
$mobileDisplayMode = (string) $params->get('mobile_display_mode', 'flow');
$mobileDisplayMode = in_array($mobileDisplayMode, ['flow', 'floating'], true) ? $mobileDisplayMode : 'flow';

$renderLink = static function (object $item, int $activeId): string {
	$itemParams = $item->getParams();
	$attributes = [
		'class' => trim('nav-link ' . ($item->anchor_css ?: '')),
	];

	if ($item->anchor_title) {
		$attributes['title'] = $item->anchor_title;
	}

	if ($item->anchor_rel) {
		$attributes['rel'] = $item->anchor_rel;
	}

	if ($item->id == $activeId) {
		$attributes['aria-current'] = $item->current ? 'page' : 'location';
	}

	$linktype = $item->title;

	if ($item->menu_icon) {
		if ($itemParams->get('menu_text', 1)) {
			$linktype = '<span class="p-2 ' . $item->menu_icon . '" aria-hidden="true"></span>' . $item->title;
		} else {
			$linktype = '<span class="p-2 ' . $item->menu_icon . '" aria-hidden="true"></span><span class="visually-hidden">' . $item->title . '</span>';
		}
	} elseif ($item->menu_image) {
		$imageAttributes = [];

		if ($item->menu_image_css) {
			$imageAttributes['class'] = $item->menu_image_css;
		}

		$linktype = HTMLHelper::_('image', $item->menu_image, '', $imageAttributes);
		$linktype .= '<span class="image-title' . ($itemParams->get('menu_text', 1) ? '' : ' visually-hidden') . '">' . $item->title . '</span>';
	}

	if ($item->type === 'separator') {
		return '<span class="mod-jet-menu__separator separator nav-link">' . $linktype . '</span>';
	}

	if ($item->type === 'heading') {
		return '<span class="mod-jet-menu__heading nav-header nav-link">' . $linktype . '</span>';
	}

	if ($item->browserNav == 1) {
		$attributes['target'] = '_blank';
		$attributes['rel']    = trim(($attributes['rel'] ?? '') . ' noopener noreferrer');
	} elseif ($item->browserNav == 2) {
		$options = 'toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes';
		$attributes['onclick'] = "window.open(this.href, 'targetWindow', '" . $options . "'); return false;";
	}

	return HTMLHelper::link(
		OutputFilter::ampReplace(htmlspecialchars($item->flink, ENT_COMPAT, 'UTF-8', false)),
		$linktype,
		$attributes
	);
};

?>
<nav
	class="mod-jet-menu-navigation"
	data-jet-menu-navigation
	data-mobile-layout="<?= $mobileDisplayMode ?>"
	aria-label="<?= htmlspecialchars($mobileToggleLabel, ENT_QUOTES, 'UTF-8') ?>"
	<?php if ($mobileToggleStyle !== '') : ?>style="<?= $mobileToggleStyle ?>"<?php endif; ?>
>
	<button
		class="mod-jet-menu-toggle"
		type="button"
		aria-controls="<?= htmlspecialchars($attributes['id'], ENT_QUOTES, 'UTF-8') ?>"
		aria-expanded="false"
		aria-label="<?= htmlspecialchars($mobileToggleLabel, ENT_QUOTES, 'UTF-8') ?>"
		hidden
	>
		<span class="mod-jet-menu-toggle__icon" aria-hidden="true"><span></span><span></span><span></span></span>
		<span class="visually-hidden"><?= htmlspecialchars($mobileToggleLabel, ENT_QUOTES, 'UTF-8') ?></span>
	</button>
<ul <?= ArrayHelper::toString($attributes) ?>>
<?php foreach ($list as $item) {
	if (!$showAll && $item->level > $start) {
		continue;
	}

	$itemParams = $item->getParams();
	$class      = [];
	$class[]    = 'item-' . $item->id . ' level-' . ($item->level - $start + 1);

	if ($item->id == $default_id) {
		$class[] = 'default';
	}

	if ($item->id == $active_id || ($item->type === 'alias' && $itemParams->get('aliasoptions') == $active_id)) {
		$class[] = 'current';
	}

	if (in_array($item->id, $path)) {
		$class[] = 'active';
	} elseif ($item->type === 'alias') {
		$aliasToId = $itemParams->get('aliasoptions');

		if (count($path) > 0 && $aliasToId == $path[count($path) - 1]) {
			$class[] = 'active';
		} elseif (in_array($aliasToId, $path)) {
			$class[] = 'alias-parent-active';
		}
	}

	if ($item->type === 'separator') {
		$class[] = 'divider';
	}

	if ($showAll) {
		if ($item->deeper) {
			$class[] = 'deeper';
		}

		if ($item->parent) {
			$class[] = 'parent';
		}
	}

	echo '<li class="' . implode(' ', $class) . '">';
	echo $renderLink($item, $active_id);

	switch (true) :
		case $showAll && $item->deeper:
			echo '<ul>';
			break;

		case $item->shallower:
			echo '</li>';
			echo str_repeat('</ul></li>', $item->level_diff);
			break;

		default:
			echo '</li>';
			break;
	endswitch;
}
?></ul>
</nav>
