<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\Filter\OutputFilter;
use Joomla\Module\JetMenu\Site\Helper\CardsStyleHelper;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var array $list */
/** @var int $active_id */
/** @var array $path */
/** @var Joomla\Registry\Registry $params */
/** @var object $module */

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_menu');
$wa->useStyle('mod_jet_menu.cards');

$start = (int) $params->get('startLevel', 1);
$items = array_filter(
	$list,
	static fn (object $item): bool => (int) $item->level === $start
);

$label = trim((string) $module->title);
$style = CardsStyleHelper::getStyle($params);
$tagId = trim((string) $params->get('tag_id', '')) ?: 'jet-menu-' . (int) $module->id;
$gridClass = trim('mod-jet-menu-cards__grid ' . (string) $params->get('class_sfx', ''));
$showImages = (int) $params->get('cards_show_images', 1) === 1;
?>
<nav class="mod-jet-menu-cards" aria-label="<?= htmlspecialchars($label, ENT_COMPAT, 'UTF-8') ?>"<?php if ($style !== '') : ?> style="<?= htmlspecialchars($style, ENT_COMPAT, 'UTF-8') ?>"<?php endif; ?>>
	<ul id="<?= htmlspecialchars($tagId, ENT_COMPAT, 'UTF-8') ?>" class="<?= htmlspecialchars($gridClass, ENT_COMPAT, 'UTF-8') ?>">
		<?php foreach ($items as $item) : ?>
			<?php
			$itemParams = $item->getParams();
			$isCurrent  = $item->id == $active_id
				|| ($item->type === 'alias' && $itemParams->get('aliasoptions') == $active_id);
			$isActive   = $isCurrent || in_array($item->id, $path, true);
			$classes    = ['mod-jet-menu-cards__item', 'item-' . (int) $item->id];

			if ($isCurrent) {
				$classes[] = 'current';
			}

			if ($isActive) {
				$classes[] = 'active';
			}

			$linkAttributes = [
				'class' => trim('mod-jet-menu-cards__link ' . ($item->anchor_css ?: '')),
			];

			if ($isCurrent) {
				$linkAttributes['aria-current'] = $item->current ? 'page' : 'location';
			}

			if ($item->anchor_rel) {
				$linkAttributes['rel'] = $item->anchor_rel;
			}

			if ($item->browserNav == 1) {
				$linkAttributes['target'] = '_blank';
				$linkAttributes['rel']    = trim(($linkAttributes['rel'] ?? '') . ' noopener noreferrer');
			}

			$link = OutputFilter::ampReplace(htmlspecialchars($item->flink, ENT_COMPAT, 'UTF-8', false));
			$isStatic = in_array($item->type, ['separator', 'heading'], true);
			?>
			<li class="<?= implode(' ', $classes) ?>">
				<?php if ($isStatic) : ?>
					<span class="mod-jet-menu-cards__link mod-jet-menu-cards__link--static">
				<?php else : ?>
					<a href="<?= $link ?>"<?php foreach ($linkAttributes as $name => $value) : ?> <?= $name ?>="<?= htmlspecialchars((string) $value, ENT_COMPAT, 'UTF-8') ?>"<?php endforeach; ?>>
				<?php endif; ?>

				<?php if ($showImages && $item->menu_image) : ?>
					<span class="mod-jet-menu-cards__media">
						<?= HTMLHelper::_('image', $item->menu_image, '', ['class' => $item->menu_image_css, 'loading' => 'lazy']) ?>
					</span>
				<?php endif; ?>

				<span class="mod-jet-menu-cards__body">
					<span class="mod-jet-menu-cards__title"><?= $item->title ?></span>
				</span>

				<?php if ($isStatic) : ?>
					</span>
				<?php else : ?>
					</a>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>
