document.addEventListener('DOMContentLoaded', () => {
	const desktopQuery = window.matchMedia('(min-width: 992px)');
	const reducedMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
	const menus = document.querySelectorAll('.mod-jet-menu');

	menus.forEach((menu) => {
		let closeTimer = 0;
		let layers = [];
		const navigation = menu.closest('[data-jet-menu-navigation]');
		const mobileToggle = navigation?.querySelector(':scope > .mod-jet-menu-toggle');
		const panelAnimations = new Map();
		const portal = document.createElement('div');

		const stopPanelAnimations = () => {
			panelAnimations.forEach((animation, panel) => {
				animation.cancel();
				panel.classList.remove('is-mobile-animating');
				panel.inert = false;
			});
			panelAnimations.clear();
		};

		// Measure real heights so long labels and nested accordions remain fluid.
		const transitionMobilePanels = (update) => {
			const animate = !desktopQuery.matches
				&& navigation?.dataset.mobileLayout === 'flow'
				&& !reducedMotionQuery.matches;
			const panels = [menu, ...menu.querySelectorAll('ul')];
			const measure = (panel) => {
				const height = panel.getBoundingClientRect().height;
				return { height, marginTop: height ? parseFloat(getComputedStyle(panel).marginTop) || 0 : 0 };
			};
			const before = animate ? panels.map(measure) : [];
			stopPanelAnimations();
			update();
			if (!animate) return;

			const after = panels.map(measure);
			panels.forEach((panel, index) => {
				const from = before[index];
				const to = after[index];
				if (Math.abs(from.height - to.height) < 1) return;
				panel.classList.add('is-mobile-animating');
				panel.inert = to.height === 0;
				const animation = panel.animate([
					{ height: `${from.height}px`, marginTop: `${from.marginTop}px` },
					{ height: `${to.height}px`, marginTop: `${to.marginTop}px` },
				], { duration: 280, easing: 'cubic-bezier(0.4, 0, 0.2, 1)' });
				panelAnimations.set(panel, animation);
				animation.onfinish = () => {
					panel.classList.remove('is-mobile-animating');
					panel.inert = false;
					panelAnimations.delete(panel);
				};
			});
		};

		portal.className = 'mod-jet-menu-portal';
		portal.hidden = true;
		document.body.appendChild(portal);

		const syncPortalTheme = () => {
			const styles = window.getComputedStyle(menu);

			[
				'--jet-menu-accent',
				'--jet-menu-accent-color',
				'--jet-menu-panel-bg',
				'--jet-menu-panel-bg-effective',
				'--jet-menu-panel-color',
				'--jet-menu-panel-hover-bg',
				'--jet-menu-panel-hover-color',
				'--jet-menu-panel-active-border',
				'--jet-menu-panel-min-width',
				'--jet-menu-panel-max-width',
				'--jet-menu-panel-shadow',
				'--jet-menu-panel-border-radius',
				'--jet-menu-panel-gap',
				'--jet-menu-child-font-size',
				'--jet-menu-child-font-weight',
				'--jet-menu-child-text-transform',
				'--jet-menu-child-item-gap',
				'--jet-menu-panel-link-padding-y',
				'--jet-menu-panel-link-padding-x',
				'--jet-menu-transition',
			].forEach((property) => {
				const value = styles.getPropertyValue(property);

				if (value) {
					portal.style.setProperty(property, value);
				}
			});
		};

		const scheduleClose = () => {
			window.clearTimeout(closeTimer);
			closeTimer = window.setTimeout(closeAll, 180);
		};

		const cancelClose = () => {
			window.clearTimeout(closeTimer);
		};

		const closeAll = () => {
			layers.forEach((layer) => layer.remove());
			layers = [];
			portal.hidden = true;
			menu.querySelectorAll('.is-hover').forEach((item) => item.classList.remove('is-hover'));
		};

		const closeMobileItems = (root = menu) => {
			const openItems = [
				...(root.matches?.('li.is-open') ? [root] : []),
				...root.querySelectorAll('li.is-open'),
			];

			openItems.forEach((item) => {
				item.classList.remove('is-open');

				const toggle = [...item.children].find((child) => child.matches('a, .mod-jet-menu__heading, .mod-jet-menu__separator'));

				if (toggle) {
					toggle.setAttribute('aria-expanded', 'false');
				}
			});
		};

		const setMobileMenuOpen = (requestedOpen, restoreFocus = false) => {
			if (!navigation || !mobileToggle) {
				return;
			}

			const isOpen = !desktopQuery.matches && requestedOpen;

			transitionMobilePanels(() => {
				navigation.classList.toggle('is-mobile-open', isOpen);
				if (!isOpen) closeMobileItems();
			});
			mobileToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');

			if (desktopQuery.matches) {
				menu.removeAttribute('aria-hidden');
			} else {
				menu.setAttribute('aria-hidden', isOpen ? 'false' : 'true');
			}

			if (!isOpen) {
				if (restoreFocus) {
					mobileToggle.focus();
				}
			}
		};

		if (navigation && mobileToggle) {
			navigation.classList.add('is-mobile-ready');
			mobileToggle.hidden = false;
			setMobileMenuOpen(false);

			mobileToggle.addEventListener('click', () => {
				setMobileMenuOpen(!navigation.classList.contains('is-mobile-open'));
			});

			document.addEventListener('click', (event) => {
				if (!desktopQuery.matches
					&& navigation.classList.contains('is-mobile-open')
					&& !navigation.contains(event.target)) {
					setMobileMenuOpen(false);
				}
			});
		}

		const trimLayers = (level) => {
			layers.slice(level).forEach((layer) => layer.remove());
			layers = layers.slice(0, level);
		};

		const clampPosition = (layer, left, top) => {
			const margin = 8;
			const rect = layer.getBoundingClientRect();
			const maxLeft = window.innerWidth - rect.width - margin;
			const maxTop = window.innerHeight - rect.height - margin;

			return {
				left: Math.max(margin, Math.min(left, maxLeft)),
				top: Math.max(margin, Math.min(top, maxTop)),
			};
		};

		const positionLayer = (layer, anchor, level) => {
			const rect = anchor.getBoundingClientRect();

			layer.style.left = '0px';
			layer.style.top = '0px';
			layer.style.visibility = 'hidden';

			requestAnimationFrame(() => {
				const margin = 8;
				const childItemGap = Number.parseFloat(getComputedStyle(portal).getPropertyValue('--jet-menu-child-item-gap')) || 0;
				const panelGap = Number.parseFloat(getComputedStyle(portal).getPropertyValue('--jet-menu-panel-gap')) || 0;
				const layerRect = layer.getBoundingClientRect();
				let left = level === 0 ? rect.left : rect.right + panelGap;
				let top = level === 0 ? rect.bottom + childItemGap : rect.top;
				let opensLeft = false;

				if (level === 0) {
					if (left + layerRect.width > window.innerWidth - margin) {
						left = rect.right - layerRect.width;
						opensLeft = true;
					}
				} else if (left + layerRect.width > window.innerWidth - margin) {
					left = rect.left - layerRect.width - panelGap;
					opensLeft = true;
				}

				const pos = clampPosition(layer, left, top);
				layer.classList.toggle('is-left', opensLeft);
				layer.style.left = `${pos.left}px`;
				layer.style.top = `${pos.top}px`;
				layer.style.visibility = 'visible';
			});
		};

		const cloneMenuItemContent = (sourceItem) => {
			const content = [...sourceItem.children].find((child) => child.matches('a, .mod-jet-menu__heading, .mod-jet-menu__separator'));

			return content ? content.cloneNode(true) : document.createTextNode(sourceItem.textContent.trim());
		};

		const openLayer = (sourceList, anchor, level = 0) => {
			if (!desktopQuery.matches || !sourceList) {
				return;
			}

			cancelClose();
			syncPortalTheme();
			trimLayers(level);
			portal.hidden = false;

			const layer = document.createElement('ul');
			layer.className = 'mod-jet-menu-panel';
			layer.dataset.level = String(level);

			[...sourceList.children].forEach((sourceItem) => {
				if (!(sourceItem instanceof HTMLElement) || sourceItem.tagName !== 'LI') {
					return;
				}

				const childList = [...sourceItem.children].find((child) => child.tagName === 'UL');
				const item = document.createElement('li');
				item.className = sourceItem.className;

				if (childList) {
					item.classList.add('parent');
				}

				item.appendChild(cloneMenuItemContent(sourceItem));

				item.addEventListener('mouseenter', () => {
					cancelClose();
					layer.querySelectorAll(':scope > li.is-hover').forEach((hovered) => hovered.classList.remove('is-hover'));
					item.classList.add('is-hover');

					if (childList) {
						openLayer(childList, item, level + 1);
					} else {
						trimLayers(level + 1);
					}
				});

				item.addEventListener('focusin', () => {
					if (childList) {
						openLayer(childList, item, level + 1);
					}
				});

				layer.appendChild(item);
			});

			layer.addEventListener('mouseenter', cancelClose);
			layer.addEventListener('mouseleave', scheduleClose);
			layer.addEventListener('focusin', cancelClose);
			layer.addEventListener('focusout', scheduleClose);

			portal.appendChild(layer);
			layers[level] = layer;
			positionLayer(layer, anchor, level);
		};

		menu.querySelectorAll(':scope > li').forEach((item) => {
			const childList = [...item.children].find((child) => child.tagName === 'UL');
			const trigger = [...item.children].find((child) => child.matches('a, .mod-jet-menu__heading, .mod-jet-menu__separator'));

			item.addEventListener('mouseenter', () => {
				cancelClose();
				menu.querySelectorAll(':scope > li.is-hover').forEach((hovered) => hovered.classList.remove('is-hover'));

				if (childList) {
					item.classList.add('is-hover');
					openLayer(childList, trigger || item, 0);
				} else {
					closeAll();
				}
			});

			item.addEventListener('focusin', () => {
				menu.querySelectorAll(':scope > li.is-hover').forEach((hovered) => hovered.classList.remove('is-hover'));

				if (childList) {
					item.classList.add('is-hover');
					openLayer(childList, trigger || item, 0);
				} else {
					closeAll();
				}
			});
		});

		menu.querySelectorAll('li').forEach((item) => {
			const childList = [...item.children].find((child) => child.tagName === 'UL');
			const toggle = [...item.children].find((child) => child.matches('a, .mod-jet-menu__heading, .mod-jet-menu__separator'));

			if (childList && toggle) {
				toggle.setAttribute('aria-haspopup', 'true');
				toggle.setAttribute('aria-expanded', 'false');

				toggle.addEventListener('click', (event) => {
					if (desktopQuery.matches) {
						return;
					}

					const isOpen = item.classList.contains('is-open');
					const href = toggle.getAttribute('href') || '';
					const isNavigableLink = toggle.tagName === 'A' && href !== '' && href !== '#';

					if (isOpen && isNavigableLink) {
						return;
					}

					event.preventDefault();

					transitionMobilePanels(() => {
						[...item.parentElement.children].forEach((sibling) => {
							if (sibling !== item) {
								closeMobileItems(sibling);
							}
						});

						item.classList.toggle('is-open', !isOpen);
						toggle.setAttribute('aria-expanded', item.classList.contains('is-open') ? 'true' : 'false');
					});
				});
			}
		});

		menu.addEventListener('mouseenter', cancelClose);
		menu.addEventListener('mouseleave', scheduleClose);
		menu.addEventListener('focusout', scheduleClose);
		menu.addEventListener('click', (event) => {
			if (!desktopQuery.matches && !event.defaultPrevented && event.target.closest('a')) {
				setMobileMenuOpen(false);
			}
		});
		window.addEventListener('resize', () => {
			stopPanelAnimations();
			closeAll();

			if (desktopQuery.matches) {
				closeMobileItems();
			}

			setMobileMenuOpen(navigation?.classList.contains('is-mobile-open') ?? false);
		});

		desktopQuery.addEventListener('change', () => {
			stopPanelAnimations();
			closeAll();
			closeMobileItems();
			setMobileMenuOpen(false);
		});
		reducedMotionQuery.addEventListener('change', stopPanelAnimations);
		window.addEventListener('scroll', closeAll, true);
		document.addEventListener('keydown', (event) => {
			if (event.key === 'Escape') {
				closeAll();
				setMobileMenuOpen(false, navigation?.classList.contains('is-mobile-open') ?? false);
			}
		});
	});
});
