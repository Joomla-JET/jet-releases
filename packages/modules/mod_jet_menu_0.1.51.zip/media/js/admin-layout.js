/* Keep the existing Joomla tabs intact and only hide layout-specific options. */
const initialise = async () => {
  const selector = document.querySelector('.js-jet-menu-layout');
  if (!selector) return;

  await customElements.whenDefined('joomla-tab');
  const tabs = selector.closest('joomla-tab');
  if (!tabs || typeof tabs.activateTab !== 'function') return;

  const modes = new Map();
  tabs.querySelectorAll('.jet-menu-options-default, .jet-menu-options-cards').forEach((fieldset) => {
    const panel = fieldset.closest('joomla-tab-element');
    if (panel) modes.set(panel, fieldset.classList.contains('jet-menu-options-cards'));
  });

  const update = () => {
    const cards = selector.value === '_:cards';
    let activeHidden = false;

    modes.forEach((isCards, panel) => {
      const hidden = cards !== isCards;
      activeHidden ||= hidden && panel.hasAttribute('active');
      panel.classList.toggle('d-none', hidden);
      panel.inert = hidden;
      // Bootstrap's d-none also survives Joomla's tab/accordion breakpoint changes.
      tabs.querySelectorAll('button[aria-controls]').forEach((button) => {
        if (button.getAttribute('aria-controls') === panel.id) {
          button.classList.toggle('d-none', hidden);
          button.inert = hidden;
        }
      });
    });

    if (activeHidden) {
      const fallback = [...tabs.children].find((panel) => panel.matches('joomla-tab-element:not(.d-none)'));
      if (fallback) tabs.activateTab(fallback, false);
    }
  };

  // Joomla's arrow navigation includes hidden tabs; navigate only visible buttons.
  tabs.addEventListener('keyup', (event) => {
    if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)
      || event.altKey || event.metaKey) return;

    const buttons = [...tabs.querySelectorAll('button[aria-controls]')]
      .filter((button) => button.closest('joomla-tab') === tabs && button.getClientRects().length > 0);
    const index = buttons.indexOf(document.activeElement);
    if (index < 0) return;

    const direction = ['ArrowLeft', 'ArrowUp'].includes(event.key) ? -1 : 1;
    const next = buttons[(index + direction + buttons.length) % buttons.length];
    event.stopImmediatePropagation();
    event.preventDefault();
    if (tabs.getAttribute('view') === 'tabs') next.click();
    next.focus();
  }, true);

  selector.addEventListener('change', update);
  update();
};

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initialise, { once: true });
} else {
  initialise();
}
