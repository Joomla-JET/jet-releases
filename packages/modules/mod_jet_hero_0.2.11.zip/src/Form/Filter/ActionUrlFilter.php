<?php

declare(strict_types=1);

namespace Joomla\Module\JetHero\Site\Form\Filter;

defined('_JEXEC') or die;

use Joomla\CMS\Form\Filter\UrlFilter;
use Joomla\CMS\Form\Form;
use Joomla\Registry\Registry;

final class ActionUrlFilter extends UrlFilter
{
	public function filter(
		\SimpleXMLElement $element,
		mixed $value,
		mixed $group = null,
		?Registry $input = null,
		?Form $form = null
	): mixed
	{
		if (is_string($value)) {
			$value = trim($value);

			if (str_starts_with($value, '#')) {
				return preg_match('/\A#[^\x00-\x20\x7F]+\z/uD', $value) === 1 ? $value : false;
			}
		}

		return parent::filter($element, $value, $group, $input, $form);
	}
}
