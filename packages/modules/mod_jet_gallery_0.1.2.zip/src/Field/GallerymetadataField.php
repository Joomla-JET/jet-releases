<?php

declare(strict_types=1);

namespace Joomla\Module\JetGallery\Site\Field;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\FormField;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Layout\FileLayout;
use Joomla\Module\JetGallery\Site\Support\ImageRepository;

final class GallerymetadataField extends FormField
{
	private const MAX_EDITABLE_IMAGES = 500;

	protected $type = 'Gallerymetadata';

	protected function getInput(): string
	{
		$images = new ImageRepository();
		$folder = $images->resolveFolder(
			(string) $this->form->getValue((string) $this->element['source'], 'params')
		);
		$metadata = $this->decodeValue((string) $this->value);
		$rows = [];

		if ($folder !== null) {
			$files = $images->findImages($folder['path'], self::MAX_EDITABLE_IMAGES + 1);

			if (count($files) > self::MAX_EDITABLE_IMAGES) {
				return $this->renderMessage(
					Text::sprintf('MOD_JET_GALLERY_METADATA_TOO_MANY', self::MAX_EDITABLE_IMAGES),
					(string) $this->value,
					'warning'
				);
			}

			foreach ($files as $naturalOrder => $file) {
				$relative = $file['relativePath'];
				$details = is_array($metadata[$relative] ?? null) ? $metadata[$relative] : [];
				$rows[] = [
					'path' => $relative,
					'src' => $images->toUrl($folder['publicPath'], $relative),
					'title' => (string) ($details['title'] ?? ''),
					'description' => (string) ($details['description'] ?? ''),
					'alt' => (string) ($details['alt'] ?? ''),
					'ordering' => is_numeric($details['ordering'] ?? null) ? (int) $details['ordering'] : PHP_INT_MAX,
					'naturalOrder' => $naturalOrder,
				];
			}
		}

		if ($rows === []) {
			return $this->renderMessage(Text::_('MOD_JET_GALLERY_METADATA_EMPTY'), (string) $this->value);
		}

		usort(
			$rows,
			static fn (array $first, array $second): int => [$first['ordering'], $first['naturalOrder']] <=> [$second['ordering'], $second['naturalOrder']]
		);

		$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
		$wa->getRegistry()->addExtensionRegistryFile('mod_jet_gallery');
		$wa->useStyle('mod_jet_gallery.metadata');
		$wa->useScript('mod_jet_gallery.metadata');

		return (new FileLayout('metadata', dirname(__DIR__, 2) . '/layouts/field'))->render([
			'id' => (string) ($this->id ?: 'jform_params_gallery_metadata'),
			'name' => (string) $this->name,
			'rows' => $rows,
		]);
	}

	private function decodeValue(string $value): array
	{
		$decoded = json_decode($value, true);

		return is_array($decoded) ? $decoded : [];
	}

	private function renderMessage(string $message, string $value, string $type = 'info'): string
	{
		$escape = static fn (string $text): string => htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
		$id = (string) ($this->id ?: 'jform_params_gallery_metadata');

		return '<input type="hidden" id="' . $escape($id) . '" name="'
			. $escape((string) $this->name) . '" value="' . $escape($value) . '">'
			. '<p class="alert alert-' . $escape($type) . '">' . $escape($message) . '</p>';
	}
}
