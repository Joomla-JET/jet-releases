<?php

declare(strict_types=1);

namespace Joomla\Module\JetGallery\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

/** Prepare data for the JET gallery module layout. */
final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;

    /** Prepare validated module data and suppress output when its content is empty. */
    protected function getLayoutData(): array|false
    {
        $data = parent::getLayoutData();
        $gallery = $this->getHelperFactory()->getHelper('GalleryHelper')->getGallery($data['params']);

        if ($gallery['images'] === []) {
            return false;
        }

        $data['gallery'] = $gallery;

        return $data;
    }
}