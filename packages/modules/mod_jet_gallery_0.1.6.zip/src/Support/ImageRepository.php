<?php

declare(strict_types=1);

namespace Joomla\Module\JetGallery\Site\Support;

defined('_JEXEC') or die;

use Joomla\CMS\Uri\Uri;

/** Resolve and enumerate image assets inside the site's public images directory. */
final class ImageRepository
{
    private const EXTENSIONS = ['avif', 'gif', 'jpeg', 'jpg', 'png', 'webp'];

    /**
     * Resolve a selected folder without allowing traversal outside images.
     *
     * @return array{path: string, publicPath: string}|null
     */
    public function resolveFolder(string $selected): ?array
    {
        $root = realpath(JPATH_ROOT . '/images');
        $selected = trim(str_replace('\\', '/', $selected), '/');

        if ($selected === '') {
            return null;
        }

        $publicPath = $selected === 'images'
            ? 'images'
            : (str_starts_with($selected, 'images/') ? $selected : 'images/' . $selected);
        $path = realpath(JPATH_ROOT . '/' . $publicPath);

        if ($root === false || $path === false || !is_dir($path) || !$this->isWithin($path, $root)) {
            return null;
        }

        return ['path' => $path, 'publicPath' => $publicPath];
    }

    /**
     * Find image candidates without following file or directory symlinks.
     *
     * @return array<int, array{absolutePath: string, filename: string, relativePath: string}>
     */
    public function findImages(string $folder, ?int $limit = null): array
    {
        $images = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($folder, \FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if ($file->isLink() || !$file->isFile() || !in_array(strtolower($file->getExtension()), self::EXTENSIONS, true)) {
                continue;
            }

            $absolutePath = $file->getPathname();
            $images[] = [
                'absolutePath' => $absolutePath,
                'filename' => $file->getFilename(),
                'relativePath' => ltrim(str_replace('\\', '/', substr($absolutePath, strlen($folder))), '/'),
            ];

            if ($limit !== null && count($images) >= $limit) {
                break;
            }
        }

        usort(
            $images,
            static fn (array $first, array $second): int => strnatcasecmp($first['relativePath'], $second['relativePath'])
        );

        return $images;
    }

    /** Encode each path segment while retaining the Joomla installation base URL. */
    public function toUrl(string $publicPath, string $relativePath = ''): string
    {
        $path = trim($publicPath . '/' . $relativePath, '/');
        $segments = array_map('rawurlencode', explode('/', $path));

        return rtrim(Uri::root(), '/') . '/' . implode('/', $segments);
    }

    /** Compare directory boundaries rather than accepting similar path prefixes. */
    private function isWithin(string $path, string $root): bool
    {
        return $path === $root || str_starts_with($path, $root . DIRECTORY_SEPARATOR);
    }
}
