<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

/** @var array<int, object> $items */
/** @var \Joomla\Registry\Registry $params */
/** @var object $module */
$moduleClass = trim('mod-jet-accordion accordion ' . (string) $params->get('moduleclass_sfx', ''));
$accordionId = 'mod-jet-accordion-' . (int) $module->id;

HTMLHelper::_('bootstrap.collapse');
?>
<div id="<?= $accordionId ?>" class="<?= htmlspecialchars($moduleClass, ENT_COMPAT, 'UTF-8') ?>">
    <?php foreach ($items as $index => $item) : ?>
        <?php
        $question   = htmlspecialchars($item->question, ENT_COMPAT, 'UTF-8');
        $answer     = $item->answer;
        $headingId  = 'mod-jet-accordion-' . $module->id . '-heading-' . $index;
        $collapseId = 'mod-jet-accordion-' . $module->id . '-collapse-' . $index;
        $expanded   = $index === 0;
        $showClass  = $expanded ? ' show' : '';
        ?>
        <div class="accordion-item">
            <h3 class="accordion-header" id="<?= $headingId ?>">
                <button
                    class="accordion-button<?= $expanded ? '' : ' collapsed' ?>"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#<?= $collapseId ?>"
                    aria-expanded="<?= $expanded ? 'true' : 'false' ?>"
                    aria-controls="<?= $collapseId ?>"
                >
                    <?= $question ?>
                </button>
            </h3>
            <div
                id="<?= $collapseId ?>"
                class="collapse<?= $showClass ?>"
                role="region"
                aria-labelledby="<?= $headingId ?>"
				data-bs-parent="#<?= $accordionId ?>"
            >
                <div class="accordion-body">
                    <?= $answer ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
