<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\RadioField;

final class JFormFieldModestyle extends RadioField
{
    protected function getInput(): string
    {
        try {
            Factory::getApplication()->getDocument()->getWebAssetManager()->addInlineStyle(
                '.modestyle{display:inline-flex;overflow:hidden;border-radius:.25rem}
                .modestyle input{position:absolute;opacity:0;pointer-events:none}
                .modestyle label{margin:0;padding:.35rem .85rem;color:#212529;background:#e9ecef;cursor:pointer}
                .modestyle label:hover{color:#000;background:#f8f9fa}
                .modestyle input:checked+label{color:#fff;background:#0d6efd}
                .modestyle input:focus-visible+label{outline:2px solid #86b7fe;outline-offset:-2px}'
            );
        } catch (Throwable) {
        }

        $html = ['<fieldset class="modestyle">'];

        foreach ($this->getOptions() as $i => $option) {
            $id      = htmlspecialchars($this->id . $i, ENT_COMPAT, 'UTF-8');
            $name    = htmlspecialchars($this->name, ENT_COMPAT, 'UTF-8');
            $value   = htmlspecialchars((string) $option->value, ENT_COMPAT, 'UTF-8');
            $text    = htmlspecialchars((string) $option->text, ENT_COMPAT, 'UTF-8');
            $checked = (string) $option->value === (string) $this->value ? ' checked' : '';

            $html[] = '<input type="radio" name="' . $name . '" id="' . $id . '" value="' . $value . '"' . $checked . '>';
            $html[] = '<label for="' . $id . '">' . $text . '</label>';
        }

        $html[] = '</fieldset>';

        return implode('', $html);
    }
}