<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Helper\ModuleHelper;

require_once __DIR__ . '/helper.php';

$images = ModJetCarouselHelper::normalizeImages($params->get('images'));

if ($images === []) {
	return;
}

$alt = ModJetCarouselHelper::getAltData($images);

$slug = trim((string) $params->get('carousel_id', ''));
$slug = strtolower($slug);
$slug = preg_replace('/\s+/', '_', $slug) ?? '';
$slug = preg_replace('/[^a-z0-9_]/', '', $slug) ?? '';
$slug = trim($slug, '_');

if ($slug === '') {
	$slug = isset($module->id) ? (string) $module->id : uniqid('', false);
}

$carouselId = 'jet_carousel_' . $slug;

static $usedCarouselIds = [];

if (isset($usedCarouselIds[$carouselId])) {
	$suffix = 2;

	while (isset($usedCarouselIds[$carouselId . '_' . $suffix])) {
		$suffix++;
	}

	$carouselId .= '_' . $suffix;
}

$usedCarouselIds[$carouselId] = true;

HTMLHelper::_('bootstrap.carousel', '#' . $carouselId, [
	'interval' => 5000,
	'ride'     => 'carousel',
	'pause'    => false,
	'wrap'     => true,
]);

$moduleclassSfx = trim((string) $params->get('moduleclass_sfx', ''));
$layout         = (string) $params->get('layout', 'default');

require ModuleHelper::getLayoutPath('mod_jet_carousel', $layout);