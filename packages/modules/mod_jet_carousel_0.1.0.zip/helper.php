<?php

declare(strict_types=1);

defined('_JEXEC') or die;

final class ModJetCarouselHelper
{
	/**
	 * Normalize Joomla subform data into a flat array of slide objects.
	 *
	 * @param mixed $rawImages
	 *
	 * @return array<int, object>
	 */
	public static function normalizeImages(mixed $rawImages): array
	{
		if ($rawImages === null || $rawImages === '') {
			return [];
		}

		if (is_object($rawImages)) {
			$rawImages = get_object_vars($rawImages);
		}

		if (!is_array($rawImages)) {
			return [];
		}

		$images = [];

		foreach ($rawImages as $image) {
			if (is_array($image)) {
				$image = (object) $image;
			}

			if (!is_object($image)) {
				continue;
			}

			if (!isset($image->image)) {
				continue;
			}

			$imagePath = trim((string) $image->image);

			if ($imagePath === '') {
				continue;
			}

			$image->image = $imagePath;
			$images[]     = $image;
		}

		return $images;
	}

	/**
	 * Builds fallback alt texts from image filenames.
	 *
	 * @param array<int, object> $images
	 *
	 * @return array<int, string>
	 */
	public static function getAltData(array $images): array
	{
		$alt = [];

		foreach ($images as $image) {
			$path = isset($image->image) ? trim((string) $image->image) : '';

			if ($path === '') {
				$alt[] = '';
				continue;
			}

			$filename = pathinfo($path, PATHINFO_FILENAME);
			$filename = str_replace(['_', '-'], ' ', $filename);

			$alt[] = trim($filename);
		}

		return $alt;
	}
}