<?php

declare(strict_types=1);

namespace Joomla\Module\JetHero\Site\Helper;

defined('_JEXEC') or die;

use Joomla\Registry\Registry;

final class HeroHelper
{
	/**
	 * @return array<string, mixed>
	 */
	public function getHero(Registry $params, int $moduleId): array
	{
		$heading = trim((string) $params->get('heading', ''));

		if ($heading === '') {
			return [];
		}

		$sectionId = preg_replace('/[^a-zA-Z0-9_-]+/', '-', trim((string) $params->get('section_id', ''))) ?? '';
		$sectionId = trim($sectionId, '-_') ?: 'mod-jet-hero-' . $moduleId;
		$focalX = $this->number($params->get('focal_x', 50), 0, 100, 50);
		$focalY = $this->number($params->get('focal_y', 50), 0, 100, 50);
		$focalMobileX = $this->number($params->get('focal_x_mobile', ''), 0, 100, $focalX);
		$focalMobileY = $this->number($params->get('focal_y_mobile', ''), 0, 100, $focalY);

		$hero = [
			'id'            => $sectionId,
			'title_id'      => $sectionId . '-title',
			'eyebrow'       => trim((string) $params->get('eyebrow', '')),
			'heading'       => $heading,
			'heading_level' => $this->choice((string) $params->get('heading_level', 'h2'), ['h1', 'h2', 'h3'], 'h2'),
			'body'          => trim((string) $params->get('body', '')),
			'image'         => trim((string) $params->get('image', '')),
			'image_mobile'  => trim((string) $params->get('image_mobile', '')),
			'image_alt'     => trim((string) $params->get('image_alt', '')),
			'image_loading' => $this->choice((string) $params->get('image_loading', 'eager'), ['eager', 'lazy'], 'eager'),
			'image_fit'     => $this->choice((string) $params->get('image_fit', 'cover'), ['cover', 'contain'], 'cover'),
			'image_position'=> $this->choice((string) $params->get('image_position', 'end'), ['start', 'end'], 'end'),
			'layout'        => $this->choice((string) $params->get('hero_layout', 'split'), ['split', 'cover', 'centered'], 'split'),
			'ratio'         => $this->choice((string) $params->get('column_ratio', 'equal'), ['equal', 'text-wide', 'image-wide'], 'equal'),
			'alignment'     => $this->choice((string) $params->get('alignment', 'start'), ['start', 'center', 'end'], 'start'),
			'content_width' => $this->choice((string) $params->get('content_width', 'module'), ['module', 'container'], 'module'),
			'vertical_alignment' => $this->choice((string) $params->get('vertical_alignment', 'center'), ['start', 'center', 'end'], 'center'),
			'content_style' => $this->choice((string) $params->get('content_style', 'plain'), ['plain', 'panel'], 'plain'),
			'theme'         => $this->choice((string) $params->get('theme', 'neutral'), ['inherit', 'neutral', 'dark'], 'neutral'),
			'spacing'       => $this->choice((string) $params->get('spacing', 'normal'), ['compact', 'normal', 'spacious'], 'normal'),
			'radius'        => $this->choice((string) $params->get('radius', 'large'), ['none', 'small', 'normal', 'large'], 'large'),
			'height_mode'   => $this->choice((string) $params->get('height_mode', 'standard'), ['auto', 'standard', 'fullscreen', 'custom'], 'standard'),
			'actions'       => array_values(array_filter([
				$this->action($params, 'primary'),
				$this->action($params, 'secondary'),
			])),
			'smooth_scroll' => (int) $params->get('smooth_scroll', 1) === 1,
		];

		$styles = [
			'--jet-hero-min-height: ' . $this->number($params->get('min_height', 420), 240, 900, 420) . 'px',
			'--jet-hero-focal-x: ' . $focalX . '%',
			'--jet-hero-focal-y: ' . $focalY . '%',
			'--jet-hero-focal-x-mobile: ' . $focalMobileX . '%',
			'--jet-hero-focal-y-mobile: ' . $focalMobileY . '%',
			'--jet-hero-overlay-opacity: ' . number_format($this->number($params->get('overlay', 48), 0, 90, 48) / 100, 2, '.', ''),
		];

		$titleSize = $this->decimal($params->get('title_size', ''), 0.5, 8);
		$titleWeight = trim((string) $params->get('title_weight', ''));
		$titleLineHeight = $this->decimal($params->get('title_line_height', ''), 0.8, 3);

		if ($titleSize !== null) {
			$styles[] = '--jet-hero-title-size: ' . $titleSize . 'rem';
		}

		if (preg_match('/\A[1-9]00\z/', $titleWeight)) {
			$styles[] = '--jet-hero-title-weight: ' . $titleWeight;
		}

		if ($titleLineHeight !== null) {
			$styles[] = '--jet-hero-title-line-height: ' . $titleLineHeight;
		}

		$colours = [
			'background_color'  => '--jet-hero-background',
			'text_color'        => '--jet-hero-color',
			'title_color'       => '--jet-hero-title-color',
			'accent_color'      => '--jet-hero-accent',
			'accent_text_color' => '--jet-hero-accent-color',
		];

		foreach ($colours as $parameter => $property) {
			$colour = trim((string) $params->get($parameter, ''));

			if (preg_match('/\A#(?:[0-9a-f]{3}|[0-9a-f]{6})\z/i', $colour)) {
				$styles[] = $property . ': ' . $colour;

				if ($parameter === 'text_color') {
					$styles[] = '--jet-hero-title-color: ' . $colour;
				} elseif ($parameter === 'accent_text_color') {
					$styles[] = '--jet-hero-accent-hover-color: ' . $colour;
				}
			}
		}

		$hero['style'] = implode('; ', $styles);

		return $hero;
	}

	/**
	 * @param array<int, string> $allowed
	 */
	private function choice(string $value, array $allowed, string $fallback): string
	{
		return in_array($value, $allowed, true) ? $value : $fallback;
	}

	private function number(mixed $value, int $min, int $max, int $fallback): int
	{
		$value = is_numeric($value) ? (int) $value : $fallback;

		return max($min, min($max, $value));
	}

	private function decimal(mixed $value, float $min, float $max): ?string
	{
		if ($value === '' || $value === null || !is_numeric($value)) {
			return null;
		}

		$value = max($min, min($max, (float) $value));

		return rtrim(rtrim(number_format($value, 2, '.', ''), '0'), '.');
	}

	/**
	 * @return array<string, string>|null
	 */
	private function action(Registry $params, string $name): ?array
	{
		$label = trim((string) $params->get($name . '_label', ''));
		$url   = trim((string) $params->get($name . '_url', ''));

		if ($label === '' || $url === '') {
			return null;
		}

		return [
			'label'  => $label,
			'url'    => $url,
			'style'  => $this->choice(
				(string) $params->get($name . '_style', $name === 'primary' ? 'primary' : 'outline-secondary'),
				['primary', 'secondary', 'outline-primary', 'outline-secondary', 'light', 'dark', 'link'],
				$name === 'primary' ? 'primary' : 'outline-secondary'
			),
			'target' => (string) $params->get($name . '_target', 'self') === 'blank' ? '_blank' : '_self',
		];
	}
}
