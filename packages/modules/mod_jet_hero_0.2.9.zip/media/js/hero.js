document.querySelectorAll('.mod-jet-hero').forEach((hero) => {
  hero.addEventListener('click', (event) => {
    const link = event.target.closest('a[data-jet-hero-scroll]');

    if (!link || event.defaultPrevented || event.button !== 0
      || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;

    const url = new URL(link.href, window.location.href);

    if (url.origin !== window.location.origin || url.pathname !== window.location.pathname
      || url.search !== window.location.search || !url.hash) return;

    let id;

    try {
      id = decodeURIComponent(url.hash.slice(1));
    } catch {
      return;
    }

    const target = document.getElementById(id);

    if (!target) return;

    event.preventDefault();

    const header = document.querySelector('.container-header');
    const headerIsFixed = header && ['fixed', 'sticky'].includes(getComputedStyle(header).position);
    const offset = (headerIsFixed ? header.getBoundingClientRect().height : 0) + 16;

    if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1');

    target.focus({ preventScroll: true });

    if (window.location.hash !== url.hash) history.pushState(null, '', url.hash);

    window.scrollTo({
      top: Math.max(0, window.scrollY + target.getBoundingClientRect().top - offset),
      behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth',
    });
  });
});
