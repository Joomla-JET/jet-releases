const heroes = [...document.querySelectorAll('.mod-jet-hero--height-fullscreen')];

if (heroes.length) {
  let frame = 0;

  const update = () => {
    cancelAnimationFrame(frame);

    frame = requestAnimationFrame(() => {
      heroes.forEach((hero) => {
        const offset = Math.max(0, Math.round(hero.getBoundingClientRect().top + window.scrollY));

        hero.style.setProperty('--jet-hero-viewport-offset', `${offset}px`);
      });
    });
  };

  const resizeObserver = 'ResizeObserver' in window ? new ResizeObserver(update) : null;

  if (resizeObserver) {
    heroes.forEach((hero) => {
      let current = hero;

      while (current && current !== document.body) {
        let sibling = current.previousElementSibling;

        while (sibling) {
          resizeObserver.observe(sibling);
          sibling = sibling.previousElementSibling;
        }

        current = current.parentElement;
      }
    });
  }

  update();
  window.addEventListener('load', update, { once: true });
  window.addEventListener('pageshow', update);
  window.addEventListener('resize', update, { passive: true });
  window.addEventListener('orientationchange', update, { passive: true });
}
