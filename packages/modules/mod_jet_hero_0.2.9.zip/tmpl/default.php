<?php

declare(strict_types=1);

defined('_JEXEC') or die;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var Joomla\Registry\Registry $params */
/** @var object $module */
/** @var array<string, mixed> $hero */

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_hero');
$wa->useStyle('mod_jet_hero.styles');

if ($hero['smooth_scroll']) {
	$wa->useScript('mod_jet_hero.scroll');
}

if ($hero['height_mode'] === 'fullscreen') {
	$wa->useScript('mod_jet_hero.viewport');
}

$classes = [
	'mod-jet-hero',
	'mod-jet-hero--layout-' . $hero['layout'],
	'mod-jet-hero--theme-' . $hero['theme'],
	'mod-jet-hero--spacing-' . $hero['spacing'],
	'mod-jet-hero--radius-' . $hero['radius'],
	'mod-jet-hero--height-' . $hero['height_mode'],
	'mod-jet-hero--align-' . $hero['alignment'],
	'mod-jet-hero--content-width-' . $hero['content_width'],
	'mod-jet-hero--vertical-' . $hero['vertical_alignment'],
	'mod-jet-hero--content-' . $hero['content_style'],
	'mod-jet-hero--fit-' . $hero['image_fit'],
	'mod-jet-hero--ratio-' . $hero['ratio'],
	'mod-jet-hero--image-' . $hero['image_position'],
	$hero['image'] === '' ? 'mod-jet-hero--no-image' : 'mod-jet-hero--has-image',
	trim((string) $params->get('moduleclass_sfx', '')),
];

$hero['class'] = implode(' ', array_filter($classes));
$layoutFile    = __DIR__ . '/layouts/' . $hero['layout'] . '.php';

require $layoutFile;
