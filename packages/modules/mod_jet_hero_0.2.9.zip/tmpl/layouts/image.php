<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;

if ($hero['image'] === '') {
	return;
}

$image      = HTMLHelper::cleanImageURL($hero['image']);
$mobileImage = $hero['image_mobile'] !== '' ? HTMLHelper::cleanImageURL($hero['image_mobile']) : null;
$attributes = $image->attributes ?? [];
$width      = isset($attributes['width']) && (int) $attributes['width'] > 0 ? (int) $attributes['width'] : null;
$height     = isset($attributes['height']) && (int) $attributes['height'] > 0 ? (int) $attributes['height'] : null;
?>
<div class="mod-jet-hero__media">
	<picture>
		<?php if ($mobileImage !== null) : ?>
			<source media="(max-width: 991.98px)" srcset="<?= htmlspecialchars($mobileImage->url, ENT_COMPAT, 'UTF-8') ?>">
		<?php endif; ?>
	<img
		class="mod-jet-hero__image"
		src="<?= htmlspecialchars($image->url, ENT_COMPAT, 'UTF-8') ?>"
		alt="<?= htmlspecialchars($hero['image_alt'], ENT_COMPAT, 'UTF-8') ?>"
		loading="<?= $hero['image_loading'] ?>"
		decoding="async"
		<?php if ($hero['image_loading'] === 'eager') : ?>fetchpriority="high"<?php endif; ?>
		<?php if ($width !== null && $height !== null) : ?>width="<?= $width ?>" height="<?= $height ?>"<?php endif; ?>
	>
	</picture>
</div>
