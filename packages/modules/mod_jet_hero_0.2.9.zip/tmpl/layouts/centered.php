<?php

declare(strict_types=1);

defined('_JEXEC') or die;

$imageFirst = $hero['image_position'] === 'start';
?>
<section
	id="<?= htmlspecialchars($hero['id'], ENT_COMPAT, 'UTF-8') ?>"
	class="<?= htmlspecialchars($hero['class'], ENT_COMPAT, 'UTF-8') ?>"
	style="<?= htmlspecialchars($hero['style'], ENT_COMPAT, 'UTF-8') ?>"
	aria-labelledby="<?= htmlspecialchars($hero['title_id'], ENT_COMPAT, 'UTF-8') ?>"
>
	<div class="mod-jet-hero__centered-inner">
		<div class="mod-jet-hero__centered-content<?= $imageFirst ? ' order-2' : '' ?>">
			<?php require __DIR__ . '/content.php'; ?>
		</div>
		<?php if ($hero['image'] !== '') : ?>
			<div class="<?= $imageFirst ? 'order-1' : 'order-2' ?>">
				<?php require __DIR__ . '/image.php'; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
