<?php

declare(strict_types=1);

defined('_JEXEC') or die;
?>
<section
	id="<?= htmlspecialchars($hero['id'], ENT_COMPAT, 'UTF-8') ?>"
	class="<?= htmlspecialchars($hero['class'], ENT_COMPAT, 'UTF-8') ?>"
	style="<?= htmlspecialchars($hero['style'], ENT_COMPAT, 'UTF-8') ?>"
	aria-labelledby="<?= htmlspecialchars($hero['title_id'], ENT_COMPAT, 'UTF-8') ?>"
>
	<?php require __DIR__ . '/image.php'; ?>
	<div class="mod-jet-hero__overlay" aria-hidden="true"></div>
	<div class="mod-jet-hero__cover-content">
		<?php require __DIR__ . '/content.php'; ?>
	</div>
</section>
