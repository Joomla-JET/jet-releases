<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Router\Route;

$headingTag = $hero['heading_level'];
?>
<div class="mod-jet-hero__content">
	<?php if ($hero['eyebrow'] !== '') : ?>
		<p class="mod-jet-hero__eyebrow"><?= htmlspecialchars($hero['eyebrow'], ENT_COMPAT, 'UTF-8') ?></p>
	<?php endif; ?>

	<<?= $headingTag ?> id="<?= htmlspecialchars($hero['title_id'], ENT_COMPAT, 'UTF-8') ?>" class="mod-jet-hero__title">
		<?= htmlspecialchars($hero['heading'], ENT_COMPAT, 'UTF-8') ?>
	</<?= $headingTag ?>>

	<?php if ($hero['body'] !== '') : ?>
		<div class="mod-jet-hero__body"><?= $hero['body'] ?></div>
	<?php endif; ?>

	<?php if ($hero['actions'] !== []) : ?>
		<div class="mod-jet-hero__actions">
			<?php foreach ($hero['actions'] as $action) : ?>
				<?php
				$actionClasses = ['btn', 'btn-' . $action['style']];

				if ($action['style'] === 'primary') {
					$actionClasses[] = 'mod-jet-hero__action--accent';
				} elseif ($action['style'] === 'outline-primary') {
					$actionClasses[] = 'mod-jet-hero__action--accent-outline';
				}
				?>
				<a
					class="<?= implode(' ', $actionClasses) ?>"
					href="<?= htmlspecialchars((string) Route::_($action['url'], false), ENT_COMPAT, 'UTF-8') ?>"
					target="<?= $action['target'] ?>"
					<?php if ($action['target'] === '_blank') : ?>rel="noopener noreferrer"<?php endif; ?>
					<?php if ($hero['smooth_scroll']) : ?>data-jet-hero-scroll<?php endif; ?>
				>
					<?= htmlspecialchars($action['label'], ENT_COMPAT, 'UTF-8') ?>
				</a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>
