<?php

declare(strict_types=1);

defined('_JEXEC') or die;

$columns = $hero['image'] === '' ? ['content' => 'col-12', 'image' => ''] : [
	'equal'      => ['content' => 'col-lg-6', 'image' => 'col-lg-6'],
	'text-wide'  => ['content' => 'col-lg-7', 'image' => 'col-lg-5'],
	'image-wide' => ['content' => 'col-lg-5', 'image' => 'col-lg-7'],
][$hero['ratio']];
$imageFirst = $hero['image_position'] === 'start';
?>
<section
	id="<?= htmlspecialchars($hero['id'], ENT_COMPAT, 'UTF-8') ?>"
	class="<?= htmlspecialchars($hero['class'], ENT_COMPAT, 'UTF-8') ?>"
	style="<?= htmlspecialchars($hero['style'], ENT_COMPAT, 'UTF-8') ?>"
	aria-labelledby="<?= htmlspecialchars($hero['title_id'], ENT_COMPAT, 'UTF-8') ?>"
>
	<div class="row g-0 align-items-stretch">
		<div class="<?= $columns['content'] ?> d-flex align-items-center<?= $imageFirst ? ' order-lg-2' : '' ?>">
			<?php require __DIR__ . '/content.php'; ?>
		</div>
		<?php if ($hero['image'] !== '') : ?>
			<div class="<?= $columns['image'] ?> mod-jet-hero__media-column<?= $imageFirst ? ' order-lg-1' : '' ?>">
				<?php require __DIR__ . '/image.php'; ?>
			</div>
		<?php endif; ?>
	</div>
</section>
