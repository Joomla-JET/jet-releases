<?php

declare(strict_types=1);

namespace Joomla\Module\JetMap\Site\Dispatcher;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;

defined('_JEXEC') or die;

final class Dispatcher extends AbstractModuleDispatcher
{
	protected function getLayoutData(): array
	{
		$data  = parent::getLayoutData();
		$query = trim((string) $data['params']->get('query', ''));
		$minHeight = (int) $data['params']->get('min_height', 450);
		$minHeight = max(200, min(2000, $minHeight));

		$data['query']     = $query;
		$data['minHeight'] = $minHeight;
		$data['mapUrl']    = $query === ''
			? ''
			: 'https://www.google.com/maps?q=' . rawurlencode($query) . '&amp;output=embed';

		return $data;
	}
}
