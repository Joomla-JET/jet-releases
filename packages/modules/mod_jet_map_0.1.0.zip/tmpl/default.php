<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var Joomla\Registry\Registry $params */
/** @var string $mapUrl */
/** @var string $query */
/** @var int $minHeight */

if ($mapUrl === '') {
	return;
}

$app->getDocument()
	->getWebAssetManager()
	->registerAndUseStyle(
		'mod_jet_map.style',
		'mod_jet_map/map.css',
		['version' => 'auto']
	);

$moduleClass = trim('mod-jet-map ' . (string) $params->get('moduleclass_sfx', ''));
$title       = Text::sprintf('MOD_JET_MAP_IFRAME_TITLE', $query);
?>
<div
	class="<?= htmlspecialchars($moduleClass, ENT_COMPAT, 'UTF-8') ?>"
	style="min-height: <?= $minHeight ?>px"
>
	<iframe
		class="mod-jet-map__frame"
		src="<?= $mapUrl ?>"
		title="<?= htmlspecialchars($title, ENT_COMPAT, 'UTF-8') ?>"
		width="100%"
		height="<?= $minHeight ?>"
		loading="lazy"
		referrerpolicy="no-referrer-when-downgrade"
		allowfullscreen
	></iframe>
</div>
