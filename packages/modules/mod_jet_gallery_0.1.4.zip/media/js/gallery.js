import PhotoSwipeLightbox from './photoswipe-lightbox.esm.min.js';

document.querySelectorAll('[data-jet-gallery]').forEach((gallery) => {
	let lightbox;

	const initLightbox = () => {
		lightbox?.destroy();
		lightbox = new PhotoSwipeLightbox({
			gallery: gallery.querySelector('[data-gallery-grid]'),
			children: '[data-gallery-item]:not([hidden])',
			pswpModule: () => import('./photoswipe.esm.min.js'),
		});

		lightbox.on('uiRegister', () => {
			lightbox.pswp.ui.registerElement({
				name: 'jet-gallery-caption',
				order: 9,
				isButton: false,
				appendTo: 'root',
				html: '',
				onInit: (element, photoswipe) => {
					element.classList.add('mod-jet-gallery__lightbox-caption');

					const updateCaption = () => {
						const source = photoswipe.currSlide?.data?.element;
						const titleText = source?.dataset.pswpTitle?.trim() ?? '';
						const descriptionText = source?.dataset.pswpDescription?.trim() ?? '';

						element.replaceChildren();
						element.hidden = titleText === '' && descriptionText === '';

						if (titleText !== '') {
							const title = document.createElement('strong');
							title.className = 'mod-jet-gallery__lightbox-title';
							title.textContent = titleText;
							element.append(title);
						}

						if (descriptionText !== '') {
							const description = document.createElement('span');
							description.className = 'mod-jet-gallery__lightbox-description';
							description.textContent = descriptionText;
							element.append(description);
						}
					};

					photoswipe.on('change', updateCaption);
					updateCaption();
				},
			});
		});

		lightbox.init();
	};

	const selectFilter = (selected) => {
		gallery.querySelectorAll('[data-gallery-filter]').forEach((button) => {
			const active = button.dataset.galleryFilter === selected;
			button.classList.toggle('active', active);
			button.setAttribute('aria-pressed', active ? 'true' : 'false');
		});

		gallery.querySelectorAll('[data-gallery-item]').forEach((item) => {
			item.hidden = selected !== '*' && item.dataset.category !== selected;
		});

		gallery.querySelectorAll('[data-gallery-category-label]').forEach((category) => {
			category.hidden = selected !== '*';
		});

		initLightbox();
	};

	gallery.querySelectorAll('[data-gallery-filter]').forEach((filter) => {
		filter.addEventListener('click', () => {
			selectFilter(filter.dataset.galleryFilter);
		});
	});

	const initialFilter = gallery.querySelector('[data-gallery-filter][aria-pressed="true"]')?.dataset.galleryFilter ?? '*';
	selectFilter(initialFilter);
});
