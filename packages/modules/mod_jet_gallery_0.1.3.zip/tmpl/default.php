<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var Joomla\Registry\Registry $params */
/** @var object $module */
/** @var array{images: array<int, array<string, mixed>>, categories: array<int, array{key: string, label: string}>} $gallery */

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_gallery');
$wa->useStyle('mod_jet_gallery.styles');
$wa->useScript('mod_jet_gallery.gallery');

$storedLayout = in_array((string) $params->get('layout_type', 'card'), ['card', 'masonry', 'portfolio'], true)
	? (string) $params->get('layout_type', 'card')
	: 'card';
$layout = match ($storedLayout) {
	'masonry' => 'masonry',
	'portfolio' => 'card',
	default => 'default',
};
$columns = max(1, min(6, (int) $params->get('columns', 4)));
$ratio = in_array((string) $params->get('thumb_ratio', 'square'), ['square', 'landscape', 'portrait', 'natural'], true) ? (string) $params->get('thumb_ratio', 'square') : 'square';
$galleryId = 'jet-gallery-' . (int) $module->id;
$filtersEnabled = (bool) $params->get('show_filters', true) && count($gallery['categories']) > 1;
$allFilterPosition = (string) $params->get('all_filter_position', 'last') === 'first' ? 'first' : 'last';
$initialFilter = $filtersEnabled && $allFilterPosition === 'last' ? $gallery['categories'][0]['key'] : '*';
$showCategories = $initialFilter === '*';
?>
<div id="<?= htmlspecialchars($galleryId, ENT_QUOTES, 'UTF-8') ?>" class="mod-jet-gallery mod-jet-gallery--<?= $layout ?> mod-jet-gallery--ratio-<?= $ratio ?> <?= htmlspecialchars(trim((string) $params->get('moduleclass_sfx', '')), ENT_QUOTES, 'UTF-8') ?>" style="--jet-gallery-columns: <?= $columns ?>" data-jet-gallery>
	<?php if ($filtersEnabled) : ?>
		<nav class="mod-jet-gallery__filters" aria-label="<?= htmlspecialchars(Text::_('MOD_JET_GALLERY_FILTER_LABEL'), ENT_QUOTES, 'UTF-8') ?>">
			<?php if ($allFilterPosition === 'first') : ?>
				<button type="button" class="mod-jet-gallery__filter btn btn-outline-secondary active" data-gallery-filter="*" aria-pressed="true"><?= htmlspecialchars(Text::_('MOD_JET_GALLERY_ALL'), ENT_QUOTES, 'UTF-8') ?></button>
			<?php endif; ?>
			<?php foreach ($gallery['categories'] as $category) : ?>
				<?php $active = $category['key'] === $initialFilter; ?>
				<button type="button" class="mod-jet-gallery__filter btn btn-outline-secondary<?= $active ? ' active' : '' ?>" data-gallery-filter="<?= htmlspecialchars($category['key'], ENT_QUOTES, 'UTF-8') ?>" aria-pressed="<?= $active ? 'true' : 'false' ?>"><?= htmlspecialchars($category['label'], ENT_QUOTES, 'UTF-8') ?></button>
			<?php endforeach; ?>
			<?php if ($allFilterPosition === 'last') : ?>
				<button type="button" class="mod-jet-gallery__filter btn btn-outline-secondary" data-gallery-filter="*" aria-pressed="false"><?= htmlspecialchars(Text::_('MOD_JET_GALLERY_ALL'), ENT_QUOTES, 'UTF-8') ?></button>
			<?php endif; ?>
		</nav>
	<?php endif; ?>

	<div class="mod-jet-gallery__grid" data-gallery-grid>
		<?php foreach ($gallery['images'] as $image) : ?>
			<?php $hidden = $initialFilter !== '*' && $image['category'] !== $initialFilter; ?>
			<a class="mod-jet-gallery__item" href="<?= htmlspecialchars($image['src'], ENT_QUOTES, 'UTF-8') ?>" data-gallery-item data-category="<?= htmlspecialchars($image['category'], ENT_QUOTES, 'UTF-8') ?>" data-pswp-width="<?= (int) $image['width'] ?>" data-pswp-height="<?= (int) $image['height'] ?>" data-pswp-title="<?= htmlspecialchars($image['title'], ENT_QUOTES, 'UTF-8') ?>" data-pswp-description="<?= htmlspecialchars($image['description'], ENT_QUOTES, 'UTF-8') ?>"<?= $hidden ? ' hidden' : '' ?>>
				<?php if ($layout === 'card') : ?>
					<span class="mod-jet-gallery__media">
						<img src="<?= htmlspecialchars($image['src'], ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($image['alt'], ENT_QUOTES, 'UTF-8') ?>" loading="lazy" decoding="async">
					</span>
					<span class="mod-jet-gallery__body">
						<?php if ($image['categoryLabel'] !== '') : ?><span class="mod-jet-gallery__category" data-gallery-category-label<?= $showCategories ? '' : ' hidden' ?>><?= htmlspecialchars($image['categoryLabel'], ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
						<?php if ($image['title'] !== '') : ?><strong class="mod-jet-gallery__title"><?= htmlspecialchars($image['title'], ENT_QUOTES, 'UTF-8') ?></strong><?php endif; ?>
						<?php if ($image['description'] !== '') : ?><span class="mod-jet-gallery__description"><?= htmlspecialchars($image['description'], ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
					</span>
				<?php else : ?>
					<img src="<?= htmlspecialchars($image['src'], ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($image['alt'], ENT_QUOTES, 'UTF-8') ?>" loading="lazy" decoding="async">
					<?php if ($image['title'] !== '' || $image['description'] !== '') : ?>
						<span class="mod-jet-gallery__caption">
							<?php if ($image['title'] !== '') : ?><strong><?= htmlspecialchars($image['title'], ENT_QUOTES, 'UTF-8') ?></strong><?php endif; ?>
							<?php if ($image['description'] !== '') : ?><span><?= htmlspecialchars($image['description'], ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?>
						</span>
					<?php endif; ?>
				<?php endif; ?>
			</a>
		<?php endforeach; ?>
	</div>
</div>
