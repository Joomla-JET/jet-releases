<?php

declare(strict_types=1);

namespace Joomla\Module\JetAccordion\Site\Helper;

defined('_JEXEC') or die;

use Joomla\Registry\Registry;

/** Normalize repeatable question and answer fields for JET Accordion. */
final class AccordionHelper
{
    /**
     * Normalize and return the items required by this layout.
     *
     * @return array<int, object{question: string, answer: string}>
     */
    public function getItems(Registry $params): array
    {
        $rawItems = $params->get('items');

        if (is_object($rawItems)) {
            $rawItems = get_object_vars($rawItems);
        }

        if (!is_array($rawItems)) {
            return [];
        }

        $items = [];

        foreach ($rawItems as $rawItem) {
            $item = is_array($rawItem) ? (object) $rawItem : $rawItem;

            if (!is_object($item)) {
                continue;
            }

            $question = trim((string) ($item->question ?? ''));
            $answer   = trim((string) ($item->answer ?? ''));

            if ($question === '' || $answer === '') {
                continue;
            }

            $items[] = (object) [
                'question' => $question,
                'answer'   => $answer,
            ];
        }

        return $items;
    }
}
