<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Extension\Service\Provider\HelperFactory;
use Joomla\CMS\Extension\Service\Provider\Module;
use Joomla\CMS\Extension\Service\Provider\ModuleDispatcherFactory;
use Joomla\DI\Container;
use Joomla\DI\ServiceProviderInterface;

return new class () implements ServiceProviderInterface {
    /** Register extension services in Joomla's dependency injection container. */
    public function register(Container $container): void
    {
        $container->registerServiceProvider(new ModuleDispatcherFactory('\\Joomla\\Module\\JetCarousel'));
        $container->registerServiceProvider(new HelperFactory('\\Joomla\\Module\\JetCarousel\\Site\\Helper'));
        $container->registerServiceProvider(new Module());
    }
};
