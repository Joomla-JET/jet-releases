<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Helper;

use Joomla\CMS\Application\CMSApplicationInterface;
use Joomla\Module\Menu\Site\Helper\MenuHelper as CoreMenuHelper;
use Joomla\Registry\Registry;

defined('_JEXEC') or die;

/** Reuse Joomla's menu filtering, routing, language handling and cache for JET layouts. */
final class MenuHelper
{
    private ?CoreMenuHelper $core = null;

    /** Return menu items prepared by the core module, including authorized view levels. */
    public function getItems(Registry &$params, CMSApplicationInterface $app): array
    {
        return $this->helper($app)->getItems($params, $app);
    }

    /** Resolve the configured base menu item or the active item. */
    public function getBaseItem(Registry &$params, CMSApplicationInterface $app): object
    {
        return $this->helper($app)->getBaseItem($params, $app);
    }

    /** Resolve the active menu item or the language default. */
    public function getActiveItem(CMSApplicationInterface $app): object
    {
        return $this->helper($app)->getActiveItem($app);
    }

    /** Resolve the default menu item for the current content language. */
    public function getDefaultItem(CMSApplicationInterface $app): object
    {
        return $this->helper($app)->getDefaultItem($app);
    }

    /** Boot the installed core module to register its namespace before creating its helper. */
    private function helper(CMSApplicationInterface $app): CoreMenuHelper
    {
        if ($this->core === null) {
            $app->bootModule('mod_menu', 'site');
            $this->core = new CoreMenuHelper();
        }

        return $this->core;
    }
}
