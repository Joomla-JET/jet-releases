<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Field;

use Joomla\CMS\Form\Field\ListField;
use Joomla\CMS\Language\Text;

defined('_JEXEC') or die;

/** Preserve menu alignment when the active template disables this option. */
final class HeaderVerticalAlignmentField extends ListField
{
    use HorizontalHeaderAwareTrait;

    protected $type = 'HeaderVerticalAlignment';

    /** Render the field input and any assets required by its editor. */
    protected function getInput(): string
    {
        if ($this->isHorizontalHeaderEnabled()) {
            return parent::getInput();
        }

        $this->disabled = true;

        return $this->preserveDisabledValue(parent::getInput())
            . '<div class="alert alert-warning mt-2 mb-0" role="alert">'
            . Text::_('MOD_JET_MENU_HEADER_ALIGNMENT_WARNING')
            . '</div>';
    }
}
