<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Field;

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\ModulelayoutField;

defined('_JEXEC') or die;

/** Register assets required to configure JET menu layouts. */
final class JetMenuLayoutField extends ModulelayoutField
{
    protected $type = 'JetMenuLayout';

    /** Render the field input and any assets required by its editor. */
    protected function getInput()
    {
        $wa = Factory::getApplication()->getDocument()->getWebAssetManager();
        $wa->getRegistry()->addExtensionRegistryFile('mod_jet_menu');
        $wa->useScript('mod_jet_menu.admin-layout');

        return parent::getInput();
    }
}
