<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Field;

use Joomla\CMS\Form\Field\NumberField;

defined('_JEXEC') or die;

/** Preserve the configured menu offset when its input is disabled. */
final class HeaderVerticalOffsetField extends NumberField
{
    use HorizontalHeaderAwareTrait;

    protected $type = 'HeaderVerticalOffset';

    /** Render the field input and any assets required by its editor. */
    protected function getInput(): string
    {
        if ($this->isHorizontalHeaderEnabled()) {
            return parent::getInput();
        }

        $this->disabled = true;

        return $this->preserveDisabledValue(parent::getInput());
    }
}
