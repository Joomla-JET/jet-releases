<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\HTML\HTMLHelper;

/** @var array<int, object> $items */
/** @var \Joomla\Registry\Registry $params */
/** @var object $module */
$appearance = (string) $params->get('appearance', 'default');
$density    = (string) $params->get('density', 'normal');
$radius     = (string) $params->get('radius', 'normal');
$icon       = (string) $params->get('icon', 'chevron');
$behavior   = (string) $params->get('behavior', 'default');
$questionUppercase = (bool) $params->get('question_uppercase', 0);
$questionBold = (bool) $params->get('question_bold', 0);

$appearanceClasses = [
    'default' => '',
    'flush'   => 'accordion-flush mod-jet-accordion--flush',
    'cards'   => 'mod-jet-accordion--cards',
];
$densityClasses = [
    'compact'     => 'mod-jet-accordion--density-compact',
    'normal'      => 'mod-jet-accordion--density-normal',
    'comfortable' => 'mod-jet-accordion--density-comfortable',
];
$radiusClasses = [
    'none'   => 'mod-jet-accordion--radius-none',
    'small'  => 'mod-jet-accordion--radius-small',
    'normal' => 'mod-jet-accordion--radius-normal',
    'large'  => 'mod-jet-accordion--radius-large',
];
$iconClasses = [
    'chevron'    => '',
    'plus_minus' => 'mod-jet-accordion--icon-plus-minus',
];

if (!isset($appearanceClasses[$appearance])) {
    $appearance = 'default';
}

if (!isset($densityClasses[$density])) {
    $density = 'normal';
}

if (!isset($radiusClasses[$radius])) {
    $radius = 'normal';
}

if (!isset($iconClasses[$icon])) {
    $icon = 'chevron';
}

if (!in_array($behavior, ['default', 'multiple', 'all_open'], true)) {
    $behavior = 'default';
}

$moduleClass = trim(implode(' ', array_filter([
    'mod-jet-accordion',
    'accordion',
    $appearanceClasses[$appearance],
    $densityClasses[$density],
    $radiusClasses[$radius],
    $iconClasses[$icon],
    $questionUppercase ? 'mod-jet-accordion--question-uppercase' : '',
    (string) $params->get('moduleclass_sfx', ''),
])));
$accordionId     = 'mod-jet-accordion-' . (int) $module->id;
$independentItems = $behavior !== 'default';
$expandAll        = $behavior === 'all_open';
$openFirst        = (bool) $params->get('open_first', 0);
$colorParameters  = [
    'accent_color'            => '--jet-accordion-accent',
    'active_background_color' => '--jet-accordion-active-bg',
    'active_text_color'        => '--jet-accordion-active-color',
];
$styleDeclarations = [];

foreach ($colorParameters as $parameter => $property) {
    $color = trim((string) $params->get($parameter, ''));

    if (preg_match('/^#[0-9a-f]{6}$/i', $color)) {
        $styleDeclarations[] = $property . ': ' . $color;
    }
}

$inlineStyle = implode('; ', $styleDeclarations);
$wa = Factory::getApplication()->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_accordion');
$wa->useStyle('mod_jet_accordion.styles');

HTMLHelper::_('bootstrap.collapse');
?>
<div
    id="<?= $accordionId ?>"
    class="<?= htmlspecialchars($moduleClass, ENT_COMPAT, 'UTF-8') ?>"
    <?php if ($inlineStyle !== '') : ?>style="<?= htmlspecialchars($inlineStyle, ENT_COMPAT, 'UTF-8') ?>"<?php endif; ?>
>
    <?php foreach ($items as $index => $item) : ?>
        <?php
        $question   = htmlspecialchars($item->question, ENT_COMPAT, 'UTF-8');
        $answer     = $item->answer;
        $headingId  = 'mod-jet-accordion-' . $module->id . '-heading-' . $index;
        $collapseId = 'mod-jet-accordion-' . $module->id . '-collapse-' . $index;
        $expanded   = $expandAll || ($openFirst && $index === 0);
        $showClass  = $expanded ? ' show' : '';
        ?>
        <div class="accordion-item">
            <h3 class="accordion-header" id="<?= $headingId ?>">
                <button
                    class="accordion-button<?= $expanded ? '' : ' collapsed' ?><?= $questionBold ? ' fw-bold' : '' ?>"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#<?= $collapseId ?>"
                    aria-expanded="<?= $expanded ? 'true' : 'false' ?>"
                    aria-controls="<?= $collapseId ?>"
                >
                    <?= $question ?>
                </button>
            </h3>
            <div
                id="<?= $collapseId ?>"
				class="accordion-collapse collapse<?= $showClass ?>"
				role="region"
				aria-labelledby="<?= $headingId ?>"
				<?php if (!$independentItems) : ?>data-bs-parent="#<?= $accordionId ?>"<?php endif; ?>
            >
                <div class="accordion-body">
                    <?= $answer ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
