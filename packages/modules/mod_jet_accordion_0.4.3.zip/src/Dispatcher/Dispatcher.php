<?php

declare(strict_types=1);

namespace Joomla\Module\JetAccordion\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
	use HelperFactoryAwareTrait;

	protected function getLayoutData(): array|false
	{
		$data          = parent::getLayoutData();
		$data['items'] = $this->getHelperFactory()
			->getHelper('AccordionHelper')
			->getItems($data['params']);

		return $data['items'] === [] ? false : $data;
	}
}
