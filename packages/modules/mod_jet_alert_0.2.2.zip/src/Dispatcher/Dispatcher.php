<?php

declare(strict_types=1);

namespace Joomla\Module\JetAlert\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
	use HelperFactoryAwareTrait;

	protected function getLayoutData(): array|false
	{
		$data          = parent::getLayoutData();
		$sourceContent = trim((string) $data['module']->content);

		if ($sourceContent === '') {
			return false;
		}

		$content = $sourceContent;

		if ((bool) $data['params']->get('prepare_content', 1)) {
			$content = HTMLHelper::_('content.prepare', $content, '', 'mod_jet_alert.content');
		}

		$helper                  = $this->getHelperFactory()->getHelper('AlertHelper');
		$moduleId                = (int) $data['module']->id;
		$data['module']->content = $content;
		$data['alertId']         = 'mod-jet-alert-' . $moduleId;
		$data['alertOptions']    = $helper->getOptions($data['params']);
		$data['fingerprint']     = $helper->getFingerprint(
			(string) $data['module']->title,
			$sourceContent,
			$data['params']
		);

		return $data;
	}
}
