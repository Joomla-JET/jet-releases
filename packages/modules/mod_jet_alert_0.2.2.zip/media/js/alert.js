import {
	getDelay,
	markAsShown,
	onDocumentReady,
	shouldShow,
} from './state.js';

const showAlert = (element) => new Promise((resolve) => {
	window.setTimeout(() => {
		if (!window.bootstrap?.Modal) {
			resolve();
			return;
		}

		document.body.appendChild(element);

		const modal = window.bootstrap.Modal.getOrCreateInstance(element, {
			backdrop: element.dataset.jetAlertBackdrop === 'static' ? 'static' : true,
			keyboard: element.dataset.jetAlertKeyboard !== 'false',
			focus: true,
		});
		const dismissingAction = element.querySelector('[data-jet-alert-dismiss]');

		dismissingAction?.addEventListener('click', () => modal.hide(), { once: true });

		element.addEventListener('shown.bs.modal', () => markAsShown(element), { once: true });
		element.addEventListener('hidden.bs.modal', () => {
			modal.dispose();
			resolve();
		}, { once: true });

		modal.show();
	}, getDelay(element));
});

const initialise = async () => {
	const alerts = [...document.querySelectorAll('[data-jet-alert-modal]')].filter(shouldShow);

	for (const alert of alerts) {
		await showAlert(alert);
	}
};

onDocumentReady(initialise);
