const DAY_IN_MILLISECONDS = 86400000;

const getStorage = (frequency) => {
	if (frequency === 'session') {
		return window.sessionStorage;
	}

	if (frequency === 'day' || frequency === 'once') {
		return window.localStorage;
	}

	return null;
};

const readRecord = (storage, key) => {
	try {
		const value = storage?.getItem(key);

		return value ? JSON.parse(value) : null;
	} catch {
		return null;
	}
};

const writeRecord = (storage, key, fingerprint) => {
	try {
		storage?.setItem(key, JSON.stringify({
			fingerprint,
			shownAt: Date.now(),
		}));
	} catch {
		// Storage can be unavailable in private or restricted browsing contexts.
	}
};

export const shouldShow = (element) => {
	const frequency = element.dataset.jetAlertFrequency;

	if (frequency === 'always') {
		return true;
	}

	const record = readRecord(getStorage(frequency), element.dataset.jetAlertStorageKey);

	if (!record || record.fingerprint !== element.dataset.jetAlertFingerprint) {
		return true;
	}

	return frequency === 'day' && Date.now() - Number(record.shownAt || 0) >= DAY_IN_MILLISECONDS;
};

export const markAsShown = (element) => {
	const frequency = element.dataset.jetAlertFrequency;

	if (frequency === 'always') {
		return;
	}

	writeRecord(
		getStorage(frequency),
		element.dataset.jetAlertStorageKey,
		element.dataset.jetAlertFingerprint,
	);
};

export const getDelay = (element) => Math.max(
	0,
	Number.parseInt(element.dataset.jetAlertDelay || '0', 10) || 0,
);

export const onDocumentReady = (callback) => {
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', callback, { once: true });
		return;
	}

	callback();
};
