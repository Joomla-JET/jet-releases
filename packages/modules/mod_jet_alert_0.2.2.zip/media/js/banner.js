import {
	getDelay,
	markAsShown,
	onDocumentReady,
	shouldShow,
} from './state.js';

const hideBanner = (element) => {
	element.classList.remove('show');

	const remove = () => element.remove();

	element.addEventListener('transitionend', remove, { once: true });
	window.setTimeout(remove, 250);
};

const showBanner = (element) => {
	window.setTimeout(() => {
		element.hidden = false;

		window.requestAnimationFrame(() => {
			element.classList.add('show');
			markAsShown(element);
		});

		element.querySelectorAll('[data-jet-alert-dismiss]').forEach((control) => {
			control.addEventListener('click', () => hideBanner(element), { once: true });
		});
	}, getDelay(element));
};

const initialise = () => {
	document.querySelectorAll('[data-jet-alert-banner]').forEach((element) => {
		if (shouldShow(element)) {
			showBanner(element);
		}
	});
};

onDocumentReady(initialise);
