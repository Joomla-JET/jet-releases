<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var Joomla\Registry\Registry $params */
/** @var object $module */
/** @var string $alertId */
/** @var string $fingerprint */
/** @var array<string, mixed> $alertOptions */

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_alert');
$wa->useScript('mod_jet_alert.banner');

$alignment = (string) $params->get('banner_alignment', 'start');
$alignment = in_array($alignment, ['start', 'center', 'end'], true) ? $alignment : 'start';
$tone      = $alertOptions['tone'] === 'none' ? 'light' : $alertOptions['tone'];
$dismissible = (bool) $params->get('banner_dismissible', 1);
$classes     = [
	'alert',
	'alert-' . $tone,
	'fade',
	'w-100',
	'mb-0',
	'text-' . $alignment,
	'mod-jet-alert',
	'mod-jet-alert--banner',
	(string) $params->get('moduleclass_sfx', ''),
];

if ($dismissible) {
	$classes[] = 'alert-dismissible';
}

$classes = trim(implode(' ', $classes));
$titleId = $alertId . '-title';
?>
<div
	id="<?= htmlspecialchars($alertId, ENT_COMPAT, 'UTF-8') ?>"
	class="<?= htmlspecialchars($classes, ENT_COMPAT, 'UTF-8') ?>"
	role="alert"
	aria-labelledby="<?= htmlspecialchars($titleId, ENT_COMPAT, 'UTF-8') ?>"
	data-jet-alert-banner
	data-jet-alert-frequency="<?= htmlspecialchars($alertOptions['frequency'], ENT_COMPAT, 'UTF-8') ?>"
	data-jet-alert-delay="<?= $alertOptions['delay'] ?>"
	data-jet-alert-fingerprint="<?= htmlspecialchars($fingerprint, ENT_COMPAT, 'UTF-8') ?>"
	data-jet-alert-storage-key="mod_jet_alert.<?= (int) $module->id ?>"
	hidden
>
	<h2 id="<?= htmlspecialchars($titleId, ENT_COMPAT, 'UTF-8') ?>" class="alert-heading h5">
		<?= htmlspecialchars((string) $module->title, ENT_COMPAT, 'UTF-8') ?>
	</h2>

	<div class="mod-jet-alert__content">
		<?= $module->content ?>
	</div>

	<?php if ($alertOptions['hasAction']) : ?>
		<a
			class="btn btn-<?= $alertOptions['actionStyle'] ?> btn-sm mt-2"
			href="<?= htmlspecialchars($alertOptions['actionUrl'], ENT_COMPAT, 'UTF-8') ?>"
			target="<?= $alertOptions['actionTarget'] ?>"
			<?php if ($alertOptions['actionTarget'] === '_blank') : ?> rel="noopener noreferrer"<?php endif; ?>
			<?php if ($alertOptions['actionDismiss']) : ?> data-jet-alert-dismiss<?php endif; ?>
		>
			<?= htmlspecialchars($alertOptions['actionLabel'], ENT_COMPAT, 'UTF-8') ?>
		</a>
	<?php endif; ?>

	<?php if ($dismissible) : ?>
		<button
			type="button"
			class="btn-close"
			data-jet-alert-dismiss
			aria-label="<?= htmlspecialchars(Text::_('JCLOSE'), ENT_COMPAT, 'UTF-8') ?>"
		></button>
	<?php endif; ?>
</div>
