<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var Joomla\Registry\Registry $params */
/** @var object $module */
/** @var string $alertId */
/** @var string $fingerprint */
/** @var array<string, mixed> $alertOptions */

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_alert');
$wa->useScript('mod_jet_alert.modal');

$tone = $alertOptions['tone'];

$allowedSizes = ['sm', 'default', 'lg', 'xl'];
$size         = (string) $params->get('size', 'default');
$size         = in_array($size, $allowedSizes, true) ? $size : 'default';

$frequency    = $alertOptions['frequency'];
$actionStyle  = $alertOptions['actionStyle'];
$actionLabel  = $alertOptions['actionLabel'];
$actionUrl    = $alertOptions['actionUrl'];
$actionTarget = $alertOptions['actionTarget'];
$hasAction    = $alertOptions['hasAction'];
$delay        = $alertOptions['delay'];
$backdrop     = (string) $params->get('backdrop', 'dismiss') === 'static' ? 'static' : 'true';
$keyboard     = (bool) $params->get('keyboard', 1);

$dialogClasses = ['modal-dialog'];

if ($size !== 'default') {
	$dialogClasses[] = 'modal-' . $size;
}

if ((bool) $params->get('centered', 1)) {
	$dialogClasses[] = 'modal-dialog-centered';
}

if ((bool) $params->get('scrollable', 1)) {
	$dialogClasses[] = 'modal-dialog-scrollable';
}

$headerClasses = ['modal-header'];

if ($tone !== 'none') {
	$headerClasses[] = 'text-bg-' . $tone;
}

$closeButtonClasses = ['btn-close'];

if (in_array($tone, ['primary', 'secondary', 'success', 'danger', 'dark'], true)) {
	$closeButtonClasses[] = 'btn-close-white';
}

$modalClasses = trim('modal fade mod-jet-alert ' . (string) $params->get('moduleclass_sfx', ''));
$titleId      = $alertId . '-title';
?>
<div
	id="<?= htmlspecialchars($alertId, ENT_COMPAT, 'UTF-8') ?>"
	class="<?= htmlspecialchars($modalClasses, ENT_COMPAT, 'UTF-8') ?>"
	tabindex="-1"
	aria-labelledby="<?= htmlspecialchars($titleId, ENT_COMPAT, 'UTF-8') ?>"
	aria-hidden="true"
	data-jet-alert-modal
	data-jet-alert-frequency="<?= htmlspecialchars($frequency, ENT_COMPAT, 'UTF-8') ?>"
	data-jet-alert-delay="<?= $delay ?>"
	data-jet-alert-fingerprint="<?= htmlspecialchars($fingerprint, ENT_COMPAT, 'UTF-8') ?>"
	data-jet-alert-storage-key="mod_jet_alert.<?= (int) $module->id ?>"
	data-jet-alert-backdrop="<?= $backdrop ?>"
	data-jet-alert-keyboard="<?= $keyboard ? 'true' : 'false' ?>"
>
	<div class="<?= implode(' ', $dialogClasses) ?>">
		<div class="modal-content">
			<div class="<?= implode(' ', $headerClasses) ?>">
				<h2 id="<?= htmlspecialchars($titleId, ENT_COMPAT, 'UTF-8') ?>" class="modal-title fs-5">
					<?= htmlspecialchars((string) $module->title, ENT_COMPAT, 'UTF-8') ?>
				</h2>
				<button
					type="button"
					class="<?= implode(' ', $closeButtonClasses) ?>"
					data-bs-dismiss="modal"
					aria-label="<?= htmlspecialchars(Text::_('JCLOSE'), ENT_COMPAT, 'UTF-8') ?>"
				></button>
			</div>

			<div class="modal-body">
				<?= $module->content ?>
			</div>

			<?php if ($hasAction) : ?>
				<div class="modal-footer">
					<a
						class="btn btn-<?= $actionStyle ?>"
						href="<?= htmlspecialchars($actionUrl, ENT_COMPAT, 'UTF-8') ?>"
						target="<?= $actionTarget ?>"
						<?php if ($actionTarget === '_blank') : ?> rel="noopener noreferrer"<?php endif; ?>
						<?php if ($alertOptions['actionDismiss']) : ?> data-jet-alert-dismiss<?php endif; ?>
					>
						<?= htmlspecialchars($actionLabel, ENT_COMPAT, 'UTF-8') ?>
					</a>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
