<?php

declare(strict_types=1);

defined('_JEXEC') or die;

final class ModJetAccordionHelper
{
	public static function normalizeItems(mixed $rawItems): array
	{
		if ($rawItems === null || $rawItems === '') {
			return [];
		}

		if (is_object($rawItems)) {
			$rawItems = get_object_vars($rawItems);
		}

		if (!is_array($rawItems)) {
			return [];
		}

		$items = [];

		foreach ($rawItems as $item) {
			if (is_array($item)) {
				$item = (object) $item;
			}

			if (!is_object($item)) {
				continue;
			}

			$question = isset($item->question) ? trim((string) $item->question) : '';
			$answer   = isset($item->answer) ? trim((string) $item->answer) : '';

			if ($question === '' || $answer === '') {
				continue;
			}

			$items[] = (object) [
				'question' => $question,
				'answer'   => $answer,
			];
		}

		return $items;
	}
}
