<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/** @var array<int, object> $items */
/** @var \Joomla\Registry\Registry $params */
/** @var object $module */
/** @var string $moduleclassSfx */

$moduleclassSfxEsc = htmlspecialchars($moduleclassSfx, ENT_COMPAT, 'UTF-8');
$accordionId       = 'mod-jet-accordion-' . $module->id;
$accordionIdEsc    = htmlspecialchars($accordionId, ENT_COMPAT, 'UTF-8');
?>
<div id="<?= $accordionIdEsc ?>" class="mod-jet-accordion <?= $moduleclassSfxEsc ?>">
    <?php foreach ($items as $index => $item) : ?>
        <?php
        $question   = htmlspecialchars($item->question, ENT_COMPAT, 'UTF-8');
        $answer     = $item->answer;
        $headingId  = 'mod-jet-accordion-' . $module->id . '-heading-' . $index;
        $collapseId = 'mod-jet-accordion-' . $module->id . '-collapse-' . $index;
        $expanded   = $index === 0;
        $showClass  = $expanded ? ' show' : '';
        ?>
        <div class="accordion-item border-bottom pb-2 mb-2">
            <h3 class="accordion-question h5 mb-0" id="<?= $headingId ?>">
                <button
                    class="btn btn-link text-decoration-none p-0 w-100 text-start collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#<?= $collapseId ?>"
                    aria-expanded="<?= $expanded ? 'true' : 'false' ?>"
                    aria-controls="<?= $collapseId ?>"
                >
                    <?= $question ?>
                </button>
            </h3>
            <div
                id="<?= $collapseId ?>"
                class="collapse<?= $showClass ?>"
                role="region"
                aria-labelledby="<?= $headingId ?>"
                data-bs-parent="#<?= $accordionIdEsc ?>"
            >
                <div class="accordion-content card card-body border-0">
                    <?= $answer ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
