<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

require_once __DIR__ . '/helper.php';

$items = ModJetAccordionHelper::normalizeItems($params->get('items'));

if ($items === []) {
	return;
}

$moduleclassSfx = trim((string) $params->get('moduleclass_sfx', ''));
$layout         = (string) $params->get('layout', 'default');

require ModuleHelper::getLayoutPath('mod_jet_accordion', $layout);
