for (const carousel of document.querySelectorAll('.mod-jet-carousel[data-jet-carousel-auto-ratio]')) {
	const image = carousel.querySelector('.mod-jet-carousel__media img');

	if (!image) {
		continue;
	}

	const setRatio = () => {
		if (image.naturalWidth > 0 && image.naturalHeight > 0) {
			carousel.style.setProperty('--jet-carousel-aspect-ratio', `${image.naturalWidth} / ${image.naturalHeight}`);
			carousel.removeAttribute('data-jet-carousel-auto-ratio');
		}
	};

	if (image.complete) {
		setRatio();
	} else {
		image.addEventListener('load', setRatio, { once: true });
	}
}
