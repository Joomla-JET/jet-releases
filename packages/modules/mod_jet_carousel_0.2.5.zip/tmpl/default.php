<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

/** @var array<int, object> $images */
/** @var array<int, string> $alt */
/** @var \Joomla\Registry\Registry $params */
/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var object $module */
/** @var string $carouselId */

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_carousel');
$wa->useStyle('mod_jet_carousel.style');

$itemCount     = count($images);
$hasIndicators = (bool) $params->get('indicators', true) && $itemCount > 1;
$hasControls   = (bool) $params->get('controls', true) && $itemCount > 1;
$mode          = (string) $params->get('mode', 'slide');
$mode          = in_array($mode, ['slide', 'fade'], true) ? $mode : 'slide';
$imageRatio    = (string) $params->get('image_ratio', 'first');
$ratioPresets  = ['21x9' => '21 / 9', '16x9' => '16 / 9', '4x3' => '4 / 3', '1x1' => '1 / 1'];
$imageAspectRatio = $ratioPresets[$imageRatio] ?? null;

if ($imageAspectRatio === null) {
	$firstImage = HTMLHelper::cleanImageURL((string) ($images[0]->image ?? ''));
	$width      = (int) ($firstImage->attributes['width'] ?? 0);
	$height     = (int) ($firstImage->attributes['height'] ?? 0);

	if ($width > 0 && $height > 0) {
		$imageAspectRatio = $width . ' / ' . $height;
	} else {
		$wa->useScript('mod_jet_carousel.ratio');
	}
}
$imageFit      = (string) $params->get('image_fit', 'cover');
$imageFit      = in_array($imageFit, ['cover', 'contain'], true) ? $imageFit : 'cover';
$eyebrow         = trim((string) $params->get('eyebrow', ''));
$eyebrowPosition = (string) $params->get('eyebrow_position', 'above');
$eyebrowPosition = in_array($eyebrowPosition, ['above', 'below'], true) ? $eyebrowPosition : 'above';

$carouselIdEsc       = htmlspecialchars($carouselId, ENT_COMPAT, 'UTF-8');
$carouselTargetEsc   = htmlspecialchars('#' . $carouselId, ENT_COMPAT, 'UTF-8');
$moduleclassSfxEsc   = htmlspecialchars(trim((string) $params->get('moduleclass_sfx', '')), ENT_COMPAT, 'UTF-8');
$carouselClassSuffix = $mode === 'fade' ? ' carousel-fade' : '';

HTMLHelper::_('bootstrap.carousel', '#' . $carouselId, [
	'interval' => 5000,
	'ride'     => 'carousel',
	'pause'    => false,
	'wrap'     => true,
]);
?>
<div class="mod-jet-carousel"
    <?php if ($imageAspectRatio !== null) : ?>
        style="--jet-carousel-aspect-ratio: <?= htmlspecialchars($imageAspectRatio, ENT_COMPAT, 'UTF-8') ?>"
    <?php else : ?>
        data-jet-carousel-auto-ratio
    <?php endif; ?>
>
    <?php if ($eyebrow !== '' && $eyebrowPosition === 'above') : ?>
        <small class="mod-jet-carousel__eyebrow d-block text-body-secondary mb-3"><?= htmlspecialchars($eyebrow, ENT_COMPAT, 'UTF-8') ?></small>
    <?php endif; ?>

    <div id="<?= $carouselIdEsc ?>" class="carousel slide<?= $carouselClassSuffix ?> <?= $moduleclassSfxEsc ?>" data-bs-ride="carousel">

    <?php if ($hasIndicators) : ?>
        <div class="carousel-indicators">
            <?php foreach ($images as $index => $image) : ?>
                <button
                        type="button"
                        data-bs-target="<?= $carouselTargetEsc ?>"
                        data-bs-slide-to="<?= (int) $index ?>"
                        class="<?= $index === 0 ? 'active' : '' ?>"
                        <?= $index === 0 ? 'aria-current="true"' : '' ?>
                        aria-label="<?= htmlspecialchars(Text::sprintf('MOD_JET_CAROUSEL_SLIDE_ARIA_LABEL', $index + 1), ENT_COMPAT, 'UTF-8') ?>"
                ></button>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="carousel-inner bg-body-secondary">
        <?php foreach ($images as $index => $image) : ?>
            <?php
            $imageSrc    = isset($image->image) ? trim((string) $image->image) : '';
            $imageLink   = isset($image->link) ? trim((string) $image->link) : '';
            $imageLinkTarget = ($image->link_target ?? '_self') === '_blank' ? '_blank' : '_self';
            $imageTitle  = isset($image->title) ? trim((string) $image->title) : '';
            $caption     = isset($image->caption) ? trim((string) $image->caption) : '';
            $customAlt   = isset($image->alt) ? trim((string) $image->alt) : '';
            $imageAlt    = $customAlt !== '' ? $customAlt : ($alt[$index] ?? '');
            $isFirstItem = $index === 0;
            ?>
            <div class="carousel-item <?= $isFirstItem ? 'active' : '' ?>">

                <div class="mod-jet-carousel__media">
                <?php if ($imageLink !== '') : ?>
                    <a class="d-block w-100 h-100"
                       href="<?= htmlspecialchars($imageLink, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>"
                       target="<?= $imageLinkTarget ?>"
                       <?php if ($imageLinkTarget === '_blank') : ?>rel="noopener noreferrer"<?php endif; ?>
                    >
                <?php endif; ?>

                <img
                        class="d-block w-100 h-100 object-fit-<?= $imageFit ?>"
                        src="<?= htmlspecialchars($imageSrc, ENT_COMPAT, 'UTF-8') ?>"
                        alt="<?= htmlspecialchars($imageAlt, ENT_COMPAT, 'UTF-8') ?>"
                        decoding="async"
                        <?= $isFirstItem ? 'fetchpriority="high"' : 'loading="lazy"' ?>
                >

                <?php if ($imageLink !== '') : ?>
                    </a>
                <?php endif; ?>
                </div>

                <?php if ($imageTitle !== '' || $caption !== '') : ?>
                    <div class="carousel-caption d-none d-md-block">
                        <?php if ($imageTitle !== '') : ?>
                            <h5 class="mod-jet-carousel__title"><?= htmlspecialchars($imageTitle, ENT_COMPAT, 'UTF-8') ?></h5>
                        <?php endif; ?>

                        <?php if ($caption !== '') : ?>
                            <p><?= htmlspecialchars($caption, ENT_COMPAT, 'UTF-8') ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            </div>
        <?php endforeach; ?>
    </div>

    <?php if ($hasControls) : ?>
        <button class="carousel-control-prev" type="button" data-bs-target="<?= $carouselTargetEsc ?>" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?= htmlspecialchars(Text::_('MOD_JET_CAROUSEL_PREVIOUS'), ENT_COMPAT, 'UTF-8') ?></span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="<?= $carouselTargetEsc ?>" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?= htmlspecialchars(Text::_('MOD_JET_CAROUSEL_NEXT'), ENT_COMPAT, 'UTF-8') ?></span>
        </button>
    <?php endif; ?>

    </div>

    <?php if ($eyebrow !== '' && $eyebrowPosition === 'below') : ?>
        <small class="mod-jet-carousel__eyebrow d-block text-body-secondary mt-2"><?= htmlspecialchars($eyebrow, ENT_COMPAT, 'UTF-8') ?></small>
    <?php endif; ?>
</div>
