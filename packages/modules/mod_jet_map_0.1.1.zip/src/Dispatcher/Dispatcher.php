<?php

declare(strict_types=1);

namespace Joomla\Module\JetMap\Site\Dispatcher;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;

defined('_JEXEC') or die;

final class Dispatcher extends AbstractModuleDispatcher
{
	protected function getLayoutData(): array|false
	{
		$data      = parent::getLayoutData();
		$query     = trim((string) $data['params']->get('query', ''));
		$minHeight = (int) $data['params']->get('min_height', 450);
		$minHeight = max(200, min(2000, $minHeight));

		if ($query === '') {
			return false;
		}

		$data['query']     = $query;
		$data['minHeight'] = $minHeight;
		$data['mapUrl']    = 'https://www.google.com/maps?q=' . rawurlencode($query) . '&output=embed';

		return $data;
	}
}
