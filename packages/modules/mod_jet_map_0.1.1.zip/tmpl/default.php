<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/** @var Joomla\CMS\Application\SiteApplication $app */
/** @var Joomla\Registry\Registry $params */
/** @var string $mapUrl */
/** @var string $query */
/** @var int $minHeight */

$wa = $app->getDocument()->getWebAssetManager();
$wa->getRegistry()->addExtensionRegistryFile('mod_jet_map');
$wa->useStyle('mod_jet_map.style');

$moduleClass = trim('mod-jet-map ' . (string) $params->get('moduleclass_sfx', ''));
$title       = Text::sprintf('MOD_JET_MAP_IFRAME_TITLE', $query);
?>
<div
	class="<?= htmlspecialchars($moduleClass, ENT_COMPAT, 'UTF-8') ?>"
	style="min-height: <?= $minHeight ?>px"
>
	<iframe
		class="mod-jet-map__frame"
		src="<?= htmlspecialchars($mapUrl, ENT_COMPAT, 'UTF-8') ?>"
		title="<?= htmlspecialchars($title, ENT_COMPAT, 'UTF-8') ?>"
		width="100%"
		height="<?= $minHeight ?>"
		loading="lazy"
		referrerpolicy="no-referrer-when-downgrade"
		allowfullscreen
	></iframe>
</div>
