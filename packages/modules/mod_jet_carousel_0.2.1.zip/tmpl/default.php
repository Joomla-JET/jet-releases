<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\HTML\HTMLHelper;
use Joomla\CMS\Language\Text;

/** @var array<int, object> $images */
/** @var array<int, string> $alt */
/** @var \Joomla\Registry\Registry $params */
/** @var object $module */
/** @var string $carouselId */

$itemCount     = count($images);
$hasIndicators = (bool) $params->get('indicators', true) && $itemCount > 1;
$hasControls   = (bool) $params->get('controls', true) && $itemCount > 1;
$mode          = (string) $params->get('mode', 'slide');
$mode          = in_array($mode, ['slide', 'fade'], true) ? $mode : 'slide';

$carouselIdEsc       = htmlspecialchars($carouselId, ENT_COMPAT, 'UTF-8');
$carouselTargetEsc   = htmlspecialchars('#' . $carouselId, ENT_COMPAT, 'UTF-8');
$moduleclassSfxEsc   = htmlspecialchars(trim((string) $params->get('moduleclass_sfx', '')), ENT_COMPAT, 'UTF-8');
$carouselClassSuffix = $mode === 'fade' ? ' carousel-fade' : '';

HTMLHelper::_('bootstrap.carousel', '#' . $carouselId, [
	'interval' => 5000,
	'ride'     => 'carousel',
	'pause'    => false,
	'wrap'     => true,
]);
?>
<div id="<?= $carouselIdEsc ?>" class="carousel slide<?= $carouselClassSuffix ?> <?= $moduleclassSfxEsc ?>" data-bs-ride="carousel">

    <?php if ($hasIndicators) : ?>
        <div class="carousel-indicators">
            <?php foreach ($images as $index => $image) : ?>
                <button
                        type="button"
                        data-bs-target="<?= $carouselTargetEsc ?>"
                        data-bs-slide-to="<?= (int) $index ?>"
                        class="<?= $index === 0 ? 'active' : '' ?>"
                        <?= $index === 0 ? 'aria-current="true"' : '' ?>
                        aria-label="<?= htmlspecialchars(Text::sprintf('MOD_JET_CAROUSEL_SLIDE_ARIA_LABEL', $index + 1), ENT_COMPAT, 'UTF-8') ?>"
                ></button>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <div class="carousel-inner">
        <?php foreach ($images as $index => $image) : ?>
            <?php
            $imageSrc    = isset($image->image) ? trim((string) $image->image) : '';
            $imageTitle  = isset($image->title) ? trim((string) $image->title) : '';
            $caption     = isset($image->caption) ? trim((string) $image->caption) : '';
            $customAlt   = isset($image->alt) ? trim((string) $image->alt) : '';
            $imageAlt    = $customAlt !== '' ? $customAlt : ($alt[$index] ?? '');
            $isFirstItem = $index === 0;
            ?>
            <div class="carousel-item <?= $isFirstItem ? 'active' : '' ?>">

                <img
                        class="d-block w-100"
                        src="<?= htmlspecialchars($imageSrc, ENT_COMPAT, 'UTF-8') ?>"
                        alt="<?= htmlspecialchars($imageAlt, ENT_COMPAT, 'UTF-8') ?>"
                        decoding="async"
                        <?= $isFirstItem ? 'fetchpriority="high"' : 'loading="lazy"' ?>
                >

                <?php if ($imageTitle !== '' || $caption !== '') : ?>
                    <div class="carousel-caption d-none d-md-block">
                        <?php if ($imageTitle !== '') : ?>
                            <h5><?= htmlspecialchars($imageTitle, ENT_COMPAT, 'UTF-8') ?></h5>
                        <?php endif; ?>

                        <?php if ($caption !== '') : ?>
                            <p><?= htmlspecialchars($caption, ENT_COMPAT, 'UTF-8') ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            </div>
        <?php endforeach; ?>
    </div>

    <?php if ($hasControls) : ?>
        <button class="carousel-control-prev" type="button" data-bs-target="<?= $carouselTargetEsc ?>" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?= htmlspecialchars(Text::_('MOD_JET_CAROUSEL_PREVIOUS'), ENT_COMPAT, 'UTF-8') ?></span>
        </button>

        <button class="carousel-control-next" type="button" data-bs-target="<?= $carouselTargetEsc ?>" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden"><?= htmlspecialchars(Text::_('MOD_JET_CAROUSEL_NEXT'), ENT_COMPAT, 'UTF-8') ?></span>
        </button>
    <?php endif; ?>

</div>
