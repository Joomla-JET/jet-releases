<?php

declare(strict_types=1);

namespace Joomla\Module\JetCarousel\Site\Helper;

defined('_JEXEC') or die;

use Joomla\Registry\Registry;

final class CarouselHelper
{
	/**
	 * @return array<int, object>
	 */
	public function getImages(Registry $params): array
	{
		$rawImages = $params->get('images');

		if (is_object($rawImages)) {
			$rawImages = get_object_vars($rawImages);
		}

		if (!is_array($rawImages)) {
			return [];
		}

		$images = [];

		foreach ($rawImages as $rawImage) {
			$image = is_array($rawImage) ? (object) $rawImage : $rawImage;

			if (!is_object($image)) {
				continue;
			}

			$imagePath = trim((string) ($image->image ?? ''));

			if ($imagePath === '') {
				continue;
			}

			$image->image = $imagePath;
			$images[]     = $image;
		}

		return $images;
	}

	/**
	 * @param array<int, object> $images
	 *
	 * @return array<int, string>
	 */
	public function getAltData(array $images): array
	{
		return array_map(
			static function (object $image): string {
				$filename = pathinfo((string) $image->image, PATHINFO_FILENAME);

				return trim(str_replace(['_', '-'], ' ', $filename));
			},
			$images
		);
	}

	public function getCarouselId(string $customId, int $moduleId): string
	{
		$slug = strtolower(trim($customId));
		$slug = preg_replace('/\s+/', '_', $slug) ?? '';
		$slug = preg_replace('/[^a-z0-9_]/', '', $slug) ?? '';
		$slug = trim($slug, '_');

		return 'jet_carousel_' . ($slug !== '' ? $slug : $moduleId);
	}
}
