<?php

declare(strict_types=1);

namespace Joomla\Module\JetCarousel\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
	use HelperFactoryAwareTrait;

	protected function getLayoutData(): array|false
	{
		$data   = parent::getLayoutData();
		$helper = $this->getHelperFactory()->getHelper('CarouselHelper');
		$images = $helper->getImages($data['params']);

		if ($images === []) {
			return false;
		}

		$data['images']     = $images;
		$data['alt']        = $helper->getAltData($images);
		$data['carouselId'] = $helper->getCarouselId(
			(string) $data['params']->get('carousel_id', ''),
			(int) $data['module']->id
		);

		return $data;
	}
}
