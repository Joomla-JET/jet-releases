<?php

declare(strict_types=1);

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;

/**
 * @var array{
 *     id: string,
 *     name: string,
 *     rows: array<int, array{
 *         path: string,
 *         src: string,
 *         title: string,
 *         description: string,
 *         alt: string,
 *         ordering: int,
 *         naturalOrder: int
 *     }>
 * } $displayData
 */

['id' => $id, 'name' => $name, 'rows' => $rows] = $displayData;

$escape = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
$metadata = [];

foreach ($rows as $ordering => $row) {
	$metadata[$row['path']] = [
		'title' => $row['title'],
		'description' => $row['description'],
		'alt' => $row['alt'],
		'ordering' => $ordering,
	];
}

$metadataJson = json_encode($metadata, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
?>
<div class="mod-jet-gallery-metadata" data-gallery-metadata-editor>
	<p class="form-text"><?= $escape(Text::_('MOD_JET_GALLERY_METADATA_FIELDS_DESC')) ?></p>
	<input type="hidden" id="<?= $escape($id) ?>" name="<?= $escape($name) ?>" value="<?= $escape((string) $metadataJson) ?>" data-gallery-metadata-input>

	<div class="mod-jet-gallery-metadata__toolbar">
		<div class="mod-jet-gallery-metadata__search input-group">
			<span class="input-group-text" aria-hidden="true"><span class="icon-search"></span></span>
			<label class="visually-hidden" for="<?= $escape($id . '-search') ?>"><?= $escape(Text::_('MOD_JET_GALLERY_METADATA_SEARCH_LABEL')) ?></label>
			<input class="form-control" id="<?= $escape($id . '-search') ?>" type="search" placeholder="<?= $escape(Text::_('MOD_JET_GALLERY_METADATA_SEARCH_PLACEHOLDER')) ?>" data-metadata-search>
		</div>
		<span class="badge bg-secondary" data-metadata-count><?= count($rows) ?></span>
		<div class="btn-group" role="group" aria-label="<?= $escape(Text::_('MOD_JET_GALLERY_METADATA_VIEW_ACTIONS')) ?>">
			<button class="btn btn-outline-secondary" type="button" data-metadata-expand><?= $escape(Text::_('MOD_JET_GALLERY_METADATA_EXPAND_ALL')) ?></button>
			<button class="btn btn-outline-secondary" type="button" data-metadata-collapse><?= $escape(Text::_('MOD_JET_GALLERY_METADATA_COLLAPSE_ALL')) ?></button>
		</div>
	</div>

	<div class="mod-jet-gallery-metadata__list" data-metadata-list>
		<?php foreach ($rows as $index => $row) : ?>
			<?php $fieldId = $id . '-' . $index; ?>
			<details class="mod-jet-gallery-metadata__item" data-metadata-item data-metadata-key="<?= $escape($row['path']) ?>">
				<summary class="mod-jet-gallery-metadata__summary">
					<button class="btn btn-sm btn-outline-secondary mod-jet-gallery-metadata__handle" type="button" title="<?= $escape(Text::_('MOD_JET_GALLERY_METADATA_MOVE')) ?>" aria-label="<?= $escape(Text::_('MOD_JET_GALLERY_METADATA_MOVE')) ?>" data-metadata-handle>
						<span class="icon-menu" aria-hidden="true"></span>
					</button>
					<button class="btn btn-outline-secondary mod-jet-gallery-metadata__thumb" type="button" title="<?= $escape(Text::_('MOD_JET_GALLERY_METADATA_PREVIEW')) ?>" data-metadata-preview data-preview-src="<?= $escape($row['src']) ?>">
						<img src="<?= $escape($row['src']) ?>" alt="" loading="lazy">
					</button>
					<span class="mod-jet-gallery-metadata__identity">
						<span class="mod-jet-gallery-metadata__path"><?= $escape($row['path']) ?></span>
						<span class="mod-jet-gallery-metadata__title-preview" data-metadata-title-preview><?= $escape($row['title']) ?></span>
					</span>
					<span class="mod-jet-gallery-metadata__actions">
						<button class="btn btn-sm btn-outline-secondary" type="button" title="<?= $escape(Text::_('MOD_JET_GALLERY_METADATA_MOVE_UP')) ?>" aria-label="<?= $escape(Text::_('MOD_JET_GALLERY_METADATA_MOVE_UP')) ?>" data-metadata-move="up"><span class="icon-arrow-up" aria-hidden="true"></span></button>
						<button class="btn btn-sm btn-outline-secondary" type="button" title="<?= $escape(Text::_('MOD_JET_GALLERY_METADATA_MOVE_DOWN')) ?>" aria-label="<?= $escape(Text::_('MOD_JET_GALLERY_METADATA_MOVE_DOWN')) ?>" data-metadata-move="down"><span class="icon-arrow-down" aria-hidden="true"></span></button>
					</span>
				</summary>
				<div class="mod-jet-gallery-metadata__fields row g-3 pt-3">
					<div class="col-12 col-xl-6">
						<label class="form-label" for="<?= $escape($fieldId . '-title') ?>"><?= $escape(Text::_('MOD_JET_GALLERY_METADATA_TITLE')) ?></label>
						<input class="form-control" id="<?= $escape($fieldId . '-title') ?>" type="text" value="<?= $escape($row['title']) ?>" data-metadata-field="title">
					</div>
					<div class="col-12 col-xl-6">
						<label class="form-label" for="<?= $escape($fieldId . '-alt') ?>"><?= $escape(Text::_('MOD_JET_GALLERY_METADATA_ALT')) ?></label>
						<input class="form-control" id="<?= $escape($fieldId . '-alt') ?>" type="text" value="<?= $escape($row['alt']) ?>" data-metadata-field="alt">
					</div>
					<div class="col-12">
						<label class="form-label" for="<?= $escape($fieldId . '-description') ?>"><?= $escape(Text::_('MOD_JET_GALLERY_METADATA_DESCRIPTION')) ?></label>
						<textarea class="form-control" id="<?= $escape($fieldId . '-description') ?>" rows="3" data-metadata-field="description"><?= $escape($row['description']) ?></textarea>
					</div>
				</div>
			</details>
		<?php endforeach; ?>
	</div>

	<dialog class="mod-jet-gallery-metadata__preview" data-metadata-preview-dialog>
		<div class="mod-jet-gallery-metadata__preview-header">
			<strong data-metadata-preview-title></strong>
			<button class="btn-close" type="button" aria-label="<?= $escape(Text::_('JCLOSE')) ?>" data-metadata-preview-close></button>
		</div>
		<img src="" alt="" data-metadata-preview-image>
	</dialog>
</div>
