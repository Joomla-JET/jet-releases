const getItems = (editor) => [...editor.querySelectorAll('[data-metadata-item]')];

const syncMetadata = (editor) => {
	const input = editor.querySelector('[data-gallery-metadata-input]');

	if (!input) return;

	const metadata = {};

	getItems(editor).forEach((item, ordering) => {
		const values = {};

		item.querySelectorAll('[data-metadata-field]').forEach((field) => {
			values[field.dataset.metadataField] = field.value;
		});

		metadata[item.dataset.metadataKey] = { ...values, ordering };
	});

	input.value = JSON.stringify(metadata);
};

const updateControls = (editor) => {
	const items = getItems(editor);

	items.forEach((item, index) => {
		const up = item.querySelector('[data-metadata-move="up"]');
		const down = item.querySelector('[data-metadata-move="down"]');

		if (up) up.disabled = index === 0;
		if (down) down.disabled = index === items.length - 1;
	});
};

const filterItems = (editor) => {
	const search = editor.querySelector('[data-metadata-search]');
	const count = editor.querySelector('[data-metadata-count]');
	const query = search?.value.trim().toLocaleLowerCase() ?? '';
	let visible = 0;

	getItems(editor).forEach((item) => {
		const values = [...item.querySelectorAll('[data-metadata-field]')]
			.map((field) => field.value)
			.join(' ');
		const matches = `${item.dataset.metadataKey} ${values}`.toLocaleLowerCase().includes(query);

		item.hidden = !matches;
		if (matches) visible += 1;
	});

	if (count) count.textContent = visible;
};

document.querySelectorAll('[data-gallery-metadata-editor]').forEach((editor) => {
	let draggedItem = null;

	updateControls(editor);

	editor.addEventListener('input', (event) => {
		if (event.target.matches('[data-metadata-search]')) {
			filterItems(editor);
			return;
		}

		if (!event.target.matches('[data-metadata-field]')) return;

		if (event.target.dataset.metadataField === 'title') {
			event.target.closest('[data-metadata-item]')
				?.querySelector('[data-metadata-title-preview]')
				?.replaceChildren(event.target.value);
		}

		syncMetadata(editor);
		filterItems(editor);
	});

	editor.addEventListener('click', (event) => {
		const button = event.target.closest('button');

		if (!button) return;

		if (button.closest('summary')) {
			event.preventDefault();
			event.stopPropagation();
		}

		if (button.matches('[data-metadata-expand], [data-metadata-collapse]')) {
			const open = button.matches('[data-metadata-expand]');
			getItems(editor).filter((item) => !item.hidden).forEach((item) => { item.open = open; });
			return;
		}

		if (button.matches('[data-metadata-move]')) {
			const item = button.closest('[data-metadata-item]');
			const sibling = button.dataset.metadataMove === 'up'
				? item.previousElementSibling
				: item.nextElementSibling;

			if (!sibling) return;

			if (button.dataset.metadataMove === 'up') {
				item.parentElement.insertBefore(item, sibling);
			} else {
				item.parentElement.insertBefore(sibling, item);
			}

			updateControls(editor);
			syncMetadata(editor);
			item.querySelector('[data-metadata-move]')?.focus();
			return;
		}

		if (button.matches('[data-metadata-preview]')) {
			const dialog = editor.querySelector('[data-metadata-preview-dialog]');
			const image = dialog?.querySelector('[data-metadata-preview-image]');
			const title = dialog?.querySelector('[data-metadata-preview-title]');
			const item = button.closest('[data-metadata-item]');

			if (!dialog || !image || !title || !item) return;

			image.src = button.dataset.previewSrc;
			image.alt = item.querySelector('[data-metadata-field="alt"]')?.value ?? '';
			title.textContent = item.dataset.metadataKey;
			dialog.showModal();
			return;
		}

		if (button.matches('[data-metadata-preview-close]')) {
			button.closest('dialog')?.close();
		}
	});

	editor.addEventListener('pointerdown', (event) => {
		const handle = event.target.closest('[data-metadata-handle]');
		const item = handle?.closest('[data-metadata-item]');

		if (item) item.draggable = true;
	});

	const cancelPendingDrag = (event) => {
		if (draggedItem) return;

		const item = event.target.closest('[data-metadata-item]');
		if (item) item.draggable = false;
	};

	editor.addEventListener('pointerup', cancelPendingDrag);
	editor.addEventListener('pointercancel', cancelPendingDrag);

	editor.addEventListener('dragstart', (event) => {
		draggedItem = event.target.closest('[data-metadata-item]');

		if (!draggedItem?.draggable) {
			event.preventDefault();
			return;
		}

		draggedItem.classList.add('is-dragging');
		event.dataTransfer.effectAllowed = 'move';
	});

	editor.addEventListener('dragover', (event) => {
		const target = event.target.closest('[data-metadata-item]');

		if (!draggedItem || !target || target === draggedItem) return;

		event.preventDefault();
		const insertAfter = event.clientY > target.getBoundingClientRect().top + target.offsetHeight / 2;
		target.parentElement.insertBefore(draggedItem, insertAfter ? target.nextElementSibling : target);
	});

	editor.addEventListener('drop', (event) => {
		if (!draggedItem) return;

		event.preventDefault();
		updateControls(editor);
		syncMetadata(editor);
	});

	editor.addEventListener('dragend', () => {
		if (!draggedItem) return;

		draggedItem.classList.remove('is-dragging');
		draggedItem.draggable = false;
		draggedItem = null;
		updateControls(editor);
		syncMetadata(editor);
	});
});
