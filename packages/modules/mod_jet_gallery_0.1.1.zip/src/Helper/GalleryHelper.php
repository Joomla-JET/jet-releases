<?php

declare(strict_types=1);

namespace Joomla\Module\JetGallery\Site\Helper;

defined('_JEXEC') or die;

use Joomla\Module\JetGallery\Site\Support\ImageRepository;
use Joomla\Registry\Registry;

final class GalleryHelper
{
	/**
	 * @return array{images: array<int, array<string, mixed>>, categories: array<int, array{key: string, label: string}>}
	 */
	public function getGallery(Registry $params): array
	{
		$imageRepository = new ImageRepository();
		$folder = $imageRepository->resolveFolder((string) $params->get('source_folder', ''));

		if ($folder === null) {
			return ['images' => [], 'categories' => []];
		}

		$metadata = $this->decodeParameterMetadata($params);
		if ($metadata === []) {
			$metadata = $this->readMetadata($folder['path']);
		}
		$images = [];
		$categories = [];
		$categoryKeys = [];

		foreach ($imageRepository->findImages($folder['path']) as $naturalOrder => $file) {
			$absolutePath = $file['absolutePath'];
			$relativePath = $file['relativePath'];
			$directory = dirname($relativePath);
			$category = $directory === '.' ? '' : $directory;

			if ($category !== '' && !isset($categoryKeys[$category])) {
				$categoryKeys[$category] = true;
				$categories[] = ['key' => $category, 'label' => str_replace('/', ' / ', $category)];
			}

			$details = is_array($metadata[$relativePath] ?? null) ? $metadata[$relativePath] : [];
			$dimensions = @getimagesize($absolutePath);
			$alt = trim((string) ($details['alt'] ?? ''));
			$images[] = [
				'src' => $imageRepository->toUrl($folder['publicPath'], $relativePath),
				'width' => (int) ($dimensions[0] ?? 1),
				'height' => (int) ($dimensions[1] ?? 1),
				'category' => $category,
				'title' => trim((string) ($details['title'] ?? '')),
				'description' => trim((string) ($details['description'] ?? '')),
				'alt' => $alt !== '' ? $alt : $this->fallbackTitle($file['filename']),
				'ordering' => is_numeric($details['ordering'] ?? null) ? (int) $details['ordering'] : PHP_INT_MAX,
				'naturalOrder' => $naturalOrder,
			];
		}

		usort(
			$images,
			static fn (array $first, array $second): int => [$first['ordering'], $first['naturalOrder']] <=> [$second['ordering'], $second['naturalOrder']]
		);

		foreach ($images as &$image) {
			unset($image['ordering'], $image['naturalOrder']);
		}
		unset($image);

		return ['images' => $images, 'categories' => $categories];
	}

	private function readMetadata(string $folder): array
	{
		$metadataFile = $folder . '/jet-gallery.json';

		if (!is_file($metadataFile)) {
			return [];
		}

		$data = json_decode((string) file_get_contents($metadataFile), true);

		return is_array($data) ? $data : [];
	}

	private function decodeParameterMetadata(Registry $params): array
	{
		$value = $params->get('gallery_metadata', '');
		$decoded = json_decode(is_string($value) ? $value : '', true);

		return is_array($decoded) ? $decoded : [];
	}

	private function fallbackTitle(string $filename): string
	{
		return trim(str_replace(['_', '-'], ' ', pathinfo($filename, PATHINFO_FILENAME)));
	}
}
