<?php

declare(strict_types=1);

namespace Joomla\Module\JetGallery\Site\Support;

defined('_JEXEC') or die;

use Joomla\CMS\Uri\Uri;

final class ImageRepository
{
	private const EXTENSIONS = ['avif', 'gif', 'jpeg', 'jpg', 'png', 'webp'];

	/**
	 * @return array{path: string, publicPath: string}|null
	 */
	public function resolveFolder(string $selected): ?array
	{
		$root = realpath(JPATH_ROOT . '/images');
		$selected = trim(str_replace('\\', '/', $selected), '/');
		$publicPath = $selected === '' || $selected === 'images'
			? 'images'
			: (str_starts_with($selected, 'images/') ? $selected : 'images/' . $selected);
		$path = realpath(JPATH_ROOT . '/' . $publicPath);

		if ($root === false || $path === false || !is_dir($path) || !$this->isWithin($path, $root)) {
			return null;
		}

		return ['path' => $path, 'publicPath' => $publicPath];
	}

	/**
	 * @return array<int, array{absolutePath: string, filename: string, relativePath: string}>
	 */
	public function findImages(string $folder): array
	{
		$images = [];
		$iterator = new \RecursiveIteratorIterator(
			new \RecursiveDirectoryIterator($folder, \FilesystemIterator::SKIP_DOTS)
		);

		foreach ($iterator as $file) {
			if (!$file->isFile() || !in_array(strtolower($file->getExtension()), self::EXTENSIONS, true)) {
				continue;
			}

			$absolutePath = $file->getPathname();
			$images[] = [
				'absolutePath' => $absolutePath,
				'filename' => $file->getFilename(),
				'relativePath' => ltrim(str_replace('\\', '/', substr($absolutePath, strlen($folder))), '/'),
			];
		}

		usort(
			$images,
			static fn (array $first, array $second): int => strnatcasecmp($first['relativePath'], $second['relativePath'])
		);

		return $images;
	}

	public function toUrl(string $publicPath, string $relativePath = ''): string
	{
		$path = trim($publicPath . '/' . $relativePath, '/');
		$segments = array_map('rawurlencode', explode('/', $path));

		return rtrim(Uri::root(), '/') . '/' . implode('/', $segments);
	}

	private function isWithin(string $path, string $root): bool
	{
		return $path === $root || str_starts_with($path, $root . DIRECTORY_SEPARATOR);
	}
}
