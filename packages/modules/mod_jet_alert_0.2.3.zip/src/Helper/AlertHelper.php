<?php

declare(strict_types=1);

namespace Joomla\Module\JetAlert\Site\Helper;

defined('_JEXEC') or die;

use Joomla\Registry\Registry;
use Joomla\CMS\Filter\InputFilter;

/** Normalize alert behavior and safe action options for JET Alert. */
final class AlertHelper
{
    /**
     * Normalize configured options and apply safe defaults.
     *
     * @return array{
     *     tone: string,
     *     frequency: string,
     *     delay: int,
     *     actionLabel: string,
     *     actionUrl: string,
     *     actionTarget: string,
     *     actionStyle: string,
     *     actionDismiss: bool,
     *     hasAction: bool
     * }
     */
    public function getOptions(Registry $params): array
    {
        $tone = $this->normaliseOption(
            (string) $params->get('tone', 'warning'),
            ['none', 'primary', 'secondary', 'success', 'danger', 'warning', 'info', 'light', 'dark'],
            'warning'
        );
        $frequency = $this->normaliseOption(
            (string) $params->get('frequency', 'session'),
            ['always', 'session', 'day', 'once'],
            'session'
        );
        $actionStyle = $this->normaliseOption(
            (string) $params->get('action_style', 'primary'),
            ['primary', 'secondary', 'success', 'danger', 'warning', 'info', 'light', 'dark'],
            'primary'
        );
        $actionLabel = trim((string) $params->get('action_label', ''));
        $actionUrl   = trim((string) $params->get('action_url', ''));
        $scheme = parse_url($actionUrl, PHP_URL_SCHEME);

        // Imported module parameters may bypass the administrator's URL form filter.
        if ($scheme === false || InputFilter::checkAttribute(['href', $actionUrl])
            || preg_match('/[\x00-\x20\x7F]/', $actionUrl)
            || ($scheme !== null && !in_array(strtolower($scheme), ['http', 'https', 'mailto', 'tel'], true))) {
            $actionUrl = '';
        }

        return [
            'tone'          => $tone,
            'frequency'     => $frequency,
            'delay'         => max(0, min(60000, (int) $params->get('delay', 300))),
            'actionLabel'   => $actionLabel,
            'actionUrl'     => $actionUrl,
            'actionTarget'  => (string) $params->get('action_target', 'self') === 'blank' ? '_blank' : '_self',
            'actionStyle'   => $actionStyle,
            'actionDismiss' => (bool) $params->get('action_dismiss', 1),
            'hasAction'     => $actionLabel !== '' && $actionUrl !== '',
        ];
    }

    /** Identify content and option changes for persisted dismissal state. */
    public function getFingerprint(string $title, string $content, Registry $params): string
    {
        return substr(hash('sha256', implode("\0", [
            $title,
            $content,
            $params->toString(),
        ])), 0, 16);
    }

    /**
     * Constrain a configured value to the supported choices.
     *
     * @param array<int, string> $allowed
     */
    private function normaliseOption(string $value, array $allowed, string $default): string
    {
        return in_array($value, $allowed, true) ? $value : $default;
    }
}
