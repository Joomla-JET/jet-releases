<?php

declare(strict_types=1);

namespace Joomla\Module\JetHero\Site\Dispatcher;

defined('_JEXEC') or die;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

/** Prepare data for the JET hero module layout. */
final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
    use HelperFactoryAwareTrait;

    /** Prepare validated module data and suppress output when its content is empty. */
    protected function getLayoutData(): array|false
    {
        $data         = parent::getLayoutData();
        $data['hero'] = $this->getHelperFactory()
            ->getHelper('HeroHelper')
            ->getHero($data['params'], (int) $data['module']->id);

        return $data['hero'] === [] ? false : $data;
    }
}
