document.addEventListener('DOMContentLoaded', () => {
	const desktopQuery = window.matchMedia('(min-width: 992px)');
	const menus = document.querySelectorAll('.mod-jet-menu');

	menus.forEach((menu) => {
		let closeTimer = 0;
		let layers = [];
		const portal = document.createElement('div');

		portal.className = 'mod-jet-menu-portal';
		portal.hidden = true;
		document.body.appendChild(portal);

		const syncPortalTheme = () => {
			const styles = window.getComputedStyle(menu);

			[
				'--jet-menu-accent',
				'--jet-menu-accent-color',
				'--jet-menu-panel-bg',
				'--jet-menu-panel-bg-effective',
				'--jet-menu-panel-color',
				'--jet-menu-panel-hover-bg',
				'--jet-menu-panel-hover-color',
				'--jet-menu-panel-active-border',
				'--jet-menu-panel-min-width',
				'--jet-menu-panel-max-width',
				'--jet-menu-panel-shadow',
				'--jet-menu-panel-border-radius',
				'--jet-menu-panel-link-padding-y',
				'--jet-menu-panel-link-padding-x',
				'--jet-menu-transition',
			].forEach((property) => {
				const value = styles.getPropertyValue(property);

				if (value) {
					portal.style.setProperty(property, value);
				}
			});
		};

		const scheduleClose = () => {
			window.clearTimeout(closeTimer);
			closeTimer = window.setTimeout(closeAll, 180);
		};

		const cancelClose = () => {
			window.clearTimeout(closeTimer);
		};

		const closeAll = () => {
			layers.forEach((layer) => layer.remove());
			layers = [];
			portal.hidden = true;
			menu.querySelectorAll('.is-hover').forEach((item) => item.classList.remove('is-hover'));
		};

		const closeMobileItems = (root = menu) => {
			const openItems = root.matches?.('li.is-open')
				? [root]
				: [...root.querySelectorAll('li.is-open')];

			openItems.forEach((item) => {
				item.classList.remove('is-open');

				const toggle = [...item.children].find((child) => child.matches('a, .mod-jet-menu__heading, .mod-jet-menu__separator'));

				if (toggle) {
					toggle.setAttribute('aria-expanded', 'false');
				}
			});
		};

		const trimLayers = (level) => {
			layers.slice(level).forEach((layer) => layer.remove());
			layers = layers.slice(0, level);
		};

		const clampPosition = (layer, left, top) => {
			const margin = 8;
			const rect = layer.getBoundingClientRect();
			const maxLeft = window.innerWidth - rect.width - margin;
			const maxTop = window.innerHeight - rect.height - margin;

			return {
				left: Math.max(margin, Math.min(left, maxLeft)),
				top: Math.max(margin, Math.min(top, maxTop)),
			};
		};

		const positionLayer = (layer, anchor, level) => {
			const rect = anchor.getBoundingClientRect();

			layer.style.left = '0px';
			layer.style.top = '0px';
			layer.style.visibility = 'hidden';

			requestAnimationFrame(() => {
				const margin = 8;
				const layerRect = layer.getBoundingClientRect();
				let left = level === 0 ? rect.left : rect.right;
				let top = level === 0 ? rect.bottom : rect.top;
				let opensLeft = false;

				if (level === 0) {
					if (left + layerRect.width > window.innerWidth - margin) {
						left = rect.right - layerRect.width;
						opensLeft = true;
					}
				} else if (left + layerRect.width > window.innerWidth - margin) {
					left = rect.left - layerRect.width;
					opensLeft = true;
				}

				const pos = clampPosition(layer, left, top);
				layer.classList.toggle('is-left', opensLeft);
				layer.style.left = `${pos.left}px`;
				layer.style.top = `${pos.top}px`;
				layer.style.visibility = 'visible';
			});
		};

		const cloneMenuItemContent = (sourceItem) => {
			const content = [...sourceItem.children].find((child) => child.matches('a, .mod-jet-menu__heading, .mod-jet-menu__separator'));

			return content ? content.cloneNode(true) : document.createTextNode(sourceItem.textContent.trim());
		};

		const openLayer = (sourceList, anchor, level = 0) => {
			if (!desktopQuery.matches || !sourceList) {
				return;
			}

			cancelClose();
			syncPortalTheme();
			trimLayers(level);
			portal.hidden = false;

			const layer = document.createElement('ul');
			layer.className = 'mod-jet-menu-panel';
			layer.dataset.level = String(level);

			[...sourceList.children].forEach((sourceItem) => {
				if (!(sourceItem instanceof HTMLElement) || sourceItem.tagName !== 'LI') {
					return;
				}

				const childList = [...sourceItem.children].find((child) => child.tagName === 'UL');
				const item = document.createElement('li');
				item.className = sourceItem.className;

				if (childList) {
					item.classList.add('parent');
				}

				item.appendChild(cloneMenuItemContent(sourceItem));

				item.addEventListener('mouseenter', () => {
					cancelClose();
					layer.querySelectorAll(':scope > li.is-hover').forEach((hovered) => hovered.classList.remove('is-hover'));
					item.classList.add('is-hover');

					if (childList) {
						openLayer(childList, item, level + 1);
					} else {
						trimLayers(level + 1);
					}
				});

				item.addEventListener('focusin', () => {
					if (childList) {
						openLayer(childList, item, level + 1);
					}
				});

				layer.appendChild(item);
			});

			layer.addEventListener('mouseenter', cancelClose);
			layer.addEventListener('mouseleave', scheduleClose);
			layer.addEventListener('focusin', cancelClose);
			layer.addEventListener('focusout', scheduleClose);

			portal.appendChild(layer);
			layers[level] = layer;
			positionLayer(layer, anchor, level);
		};

		menu.querySelectorAll(':scope > li').forEach((item) => {
			const childList = [...item.children].find((child) => child.tagName === 'UL');

			item.addEventListener('mouseenter', () => {
				cancelClose();
				menu.querySelectorAll(':scope > li.is-hover').forEach((hovered) => hovered.classList.remove('is-hover'));

				if (childList) {
					item.classList.add('is-hover');
					openLayer(childList, item, 0);
				} else {
					closeAll();
				}
			});

			item.addEventListener('focusin', () => {
				menu.querySelectorAll(':scope > li.is-hover').forEach((hovered) => hovered.classList.remove('is-hover'));

				if (childList) {
					item.classList.add('is-hover');
					openLayer(childList, item, 0);
				} else {
					closeAll();
				}
			});
		});

		menu.querySelectorAll('li').forEach((item) => {
			const childList = [...item.children].find((child) => child.tagName === 'UL');
			const toggle = [...item.children].find((child) => child.matches('a, .mod-jet-menu__heading, .mod-jet-menu__separator'));

			if (childList && toggle) {
				toggle.setAttribute('aria-haspopup', 'true');
				toggle.setAttribute('aria-expanded', 'false');

				toggle.addEventListener('click', (event) => {
					if (desktopQuery.matches) {
						return;
					}

					const isOpen = item.classList.contains('is-open');
					const href = toggle.getAttribute('href') || '';
					const isNavigableLink = toggle.tagName === 'A' && href !== '' && href !== '#';

					if (isOpen && isNavigableLink) {
						return;
					}

					event.preventDefault();

					[...item.parentElement.children].forEach((sibling) => {
						if (sibling !== item) {
							closeMobileItems(sibling);
						}
					});

					item.classList.toggle('is-open', !isOpen);
					toggle.setAttribute('aria-expanded', item.classList.contains('is-open') ? 'true' : 'false');
				});
			}
		});

		menu.addEventListener('mouseenter', cancelClose);
		menu.addEventListener('mouseleave', scheduleClose);
		menu.addEventListener('focusout', scheduleClose);
		window.addEventListener('resize', () => {
			closeAll();

			if (desktopQuery.matches) {
				closeMobileItems();
			}
		});

		desktopQuery.addEventListener('change', () => {
			closeAll();
			closeMobileItems();
		});
		window.addEventListener('scroll', closeAll, true);
		document.addEventListener('keydown', (event) => {
			if (event.key === 'Escape') {
				closeAll();
			}
		});
	});
});
