<?php

declare(strict_types=1);

namespace Joomla\Module\JetMenu\Site\Dispatcher;

use Joomla\CMS\Dispatcher\AbstractModuleDispatcher;
use Joomla\CMS\Helper\HelperFactoryAwareInterface;
use Joomla\CMS\Helper\HelperFactoryAwareTrait;

defined('_JEXEC') or die;

final class Dispatcher extends AbstractModuleDispatcher implements HelperFactoryAwareInterface
{
	use HelperFactoryAwareTrait;

	protected function getLayoutData(): array|false
	{
		$data       = parent::getLayoutData();
		$menuHelper = $this->getHelperFactory()->getHelper('MenuHelper');

		$data['list']       = $menuHelper->getItems($data['params'], $data['app']);
		$data['base']       = $menuHelper->getBaseItem($data['params'], $data['app']);
		$data['active']     = $menuHelper->getActiveItem($data['app']);
		$data['default']    = $menuHelper->getDefaultItem($data['app']);
		$data['active_id']  = $data['active']->id;
		$data['default_id'] = $data['default']->id;
		$data['path']       = $data['base']->tree;
		$data['showAll']    = (int) $data['params']->get('showAllChildren', 1);
		$data['class_sfx']  = htmlspecialchars((string) $data['params']->get('class_sfx', ''), ENT_COMPAT, 'UTF-8');

		return $data['list'] === [] ? false : $data;
	}
}
